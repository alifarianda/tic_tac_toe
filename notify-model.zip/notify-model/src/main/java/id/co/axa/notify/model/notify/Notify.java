package id.co.axa.notify.model.notify;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.notify.model.message.Message;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "appID", "transactionDTTM", "message" })
public class Notify {

	@JsonProperty("appID")
	private String appID;

	@JsonProperty("transactionDTTM")
	private String transactionDTTM;

	@JsonProperty("message")
	private Message message;

	@JsonProperty("data")
	private Object objectData;

	@JsonProperty("header")
	private Object objectHeader;
	
	@JsonProperty("status")
	private String status;

	public Notify() {

	}

	/**
	 * @param status
	 */
	public Notify(Object objectData, Object objectHeader) {
		this.objectData = objectData;
		this.objectHeader = objectHeader;
	}

	public static Notify status(Object objectData, Object objectHeader) {
		return new Notify(objectData, objectHeader);
	}

	/**
	 * @param status
	 */
	public Notify(String status) {
		this.status = status;
	}
	
	public static Notify statusApp(String status) {
		return new Notify(status);
	}

	@JsonProperty("appID")
	public String getAppID() {
		return appID;
	}

	@JsonProperty("appID")
	public void setAppID(String appID) {
		this.appID = appID;
	}

	@JsonProperty("transactionDTTM")
	public String getTransactionDTTM() {
		return transactionDTTM;
	}

	@JsonProperty("transactionDTTM")
	public void setTransactionDTTM(String transactionDTTM) {
		this.transactionDTTM = transactionDTTM;
	}

	@JsonProperty("message")
	public Message getMessage() {
		return message;
	}

	@JsonProperty("message")
	public void setMessage(Message message) {
		this.message = message;
	}

	public Object getObjectData() {
		return objectData;
	}

	public void setObjectData(Object objectData) {
		this.objectData = objectData;
	}

	public Object getObjectHeader() {
		return objectHeader;
	}

	public void setObjectHeader(Object objectHeader) {
		this.objectHeader = objectHeader;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}