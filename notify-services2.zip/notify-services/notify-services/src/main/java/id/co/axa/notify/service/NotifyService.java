package id.co.axa.notify.service;

import org.springframework.web.multipart.MultipartFile;

import id.co.axa.eip.model.response.Response;
import id.co.axa.notify.component.UserComponent;
import id.co.axa.notify.model.notify.Notify;


/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public interface NotifyService {
	
	/**
	 *
	 * @author Degi Herlambang
	 * date june 20, 2021
	 * @since 1.1
	 * @apiNote adding multipartfile for attachment email
	 *
	 */
	void sendMail(Notify notify, MultipartFile[] multipartFiles);
	
	Response sendSms(Notify notify,String entity,String source,String requestId);
	
	Response sendShortenUrl(UserComponent userComponent);
	
	boolean findApplicationName(String applicationName);	
}
