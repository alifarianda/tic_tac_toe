package id.co.axa.notify.email.configuration;

/**
 * 
 * @author Muhammad Mufqi
 * @since 1.0
 * AXA F2F Email
 * 
 */

import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Configuration
public class MailConfiguration {
	

	@Value("${spring.mail.host}")
	private String smtpHost;
	
	@Value("${spring.mail.port}")
	private Integer smtpPort;
	
	
	/* Uncomment this for cloud environment
	
	@Value("${app.user.aws}")
	private String userNameAws;
	
	@Value("${app.password.aws}")
	private String passAws; */
		
	@Bean
	public JavaMailSender getMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(smtpHost);
		mailSender.setPort(smtpPort);
		
	 /* Uncomment this for smtp cloud
		mailSender.setUsername(userNameAws);
		mailSender.setPassword(passAws); */
		
        Properties javaMailProperties = new Properties();

        javaMailProperties.put("mail.transport.protocol", "smtp");
        javaMailProperties.put("mail.debug", "true");
        javaMailProperties.put("mail.smtp.starttls.enable", "true");

        mailSender.setJavaMailProperties(javaMailProperties);
		return mailSender;
	}
}
