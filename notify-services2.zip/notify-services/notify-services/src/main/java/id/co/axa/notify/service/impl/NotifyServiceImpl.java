package id.co.axa.notify.service.impl;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import id.co.axa.commons.core.utils.GeneratorUtils;
import id.co.axa.eip.model.body.Body;
import id.co.axa.eip.model.customer.Customer;
import id.co.axa.eip.model.havecommunicatedmessage.HaveCommunicatedMessage;
import id.co.axa.eip.model.header.Header;
import id.co.axa.eip.model.request.Request;
import id.co.axa.eip.model.response.Response;
import id.co.axa.eip.model.securitycontext.SecurityContext;
import id.co.axa.middleware.model.util.ConstantMiddleware;
import id.co.axa.notify.component.UserComponent;
import id.co.axa.notify.helper.ConvertMultipartToFile;
import id.co.axa.notify.model.config.NotifyConfig;
import id.co.axa.notify.model.notify.Notify;
import id.co.axa.notify.repository.NotifyRepository;
import id.co.axa.notify.service.NotifyService;

/**
 * 
 * @author Muhammad Mufqi
 * @since 1.0
 * AXA Notify
 * 
 */

@Service
public class NotifyServiceImpl implements NotifyService {

	@Autowired
	JavaMailSender javaMainSender;
	
	@Autowired
	NotifyRepository notifyRepository;

	@Value("${app.user.app}")
	private String userApp;

	@Value("${app.password.app}")
	private String passwordApp;

	@Value("${app.base.url.messaging.eip}")
	private String baseMessagingUrl;

	@Autowired
	RestTemplate restTemplate;

	@Override
	
	/**
	 *
	 * @author Degi Herlambang
	 * date june 20, 2021
	 * @since 1.1
	 * @apiNote adding multipartfile for attachment email
	 *
	 */
	public void sendMail(Notify notify,MultipartFile[] multipartFiles) {
		MimeMessage mimeMessage = javaMainSender.createMimeMessage();
		try {
			MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
			mimeMessageHelper.setSubject(notify.getMessage().getSubject());
			mimeMessageHelper.setFrom(new InternetAddress(notify.getMessage().getFrom().getAddress(), notify.getMessage().getFrom().getName()));
			List<String> to = new ArrayList<String>();
			List<String> cc = new ArrayList<String>();
			List<String> bcc = new ArrayList<String>();

			if (notify.getMessage().getRecipient().getTo() != null) {

				for (int i = 0; i < notify.getMessage().getRecipient().getTo().size(); i++) {
					to.add(notify.getMessage().getRecipient().getTo().get(i).getAddress());
				}

				String[] multipleTo = new String[to.size()];
				to.toArray(multipleTo);

				mimeMessageHelper.setTo(multipleTo);
			}

			if (notify.getMessage().getRecipient().getCc() != null) {

				for (int i = 0; i < notify.getMessage().getRecipient().getCc().size(); i++) {
					cc.add(notify.getMessage().getRecipient().getCc().get(i).getAddress());
				}

				String[] multipleCc = new String[cc.size()];
				cc.toArray(multipleCc);

				mimeMessageHelper.setCc(multipleCc);
			}

			if (notify.getMessage().getRecipient().getBcc() != null) {

				for (int i = 0; i < notify.getMessage().getRecipient().getBcc().size(); i++) {
					bcc.add(notify.getMessage().getRecipient().getBcc().get(i).getAddress());
				}

				String[] multipleBcc = new String[bcc.size()];
				bcc.toArray(multipleBcc);

				mimeMessageHelper.setBcc(multipleBcc);
			}

			mimeMessageHelper.setText(notify.getMessage().getBody(),true);

			/**
			 *
			 * @author Degi Herlambang
			 * date june 20, 2021
			 * @since 1.1
			 * @apiNote loop for array files
			 *
			 */
			for (int i=0;i<multipartFiles.length;i++){
				MultipartFile multipartFile = multipartFiles[i];
				ConvertMultipartToFile con = new ConvertMultipartToFile();
				File file = con.convertMultiPartToFile(multipartFile);
				mimeMessageHelper.addAttachment(file.getName(), file);
			}

			javaMainSender.send(mimeMessageHelper.getMimeMessage());
		} catch (MessagingException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}

	@Override
	public Response sendSms(Notify notify, String entity, String source, String requestId) {
		HttpHeaders headers = new HttpHeaders();
		String msgReq = costructReqSms(notify, entity, source, requestId);
		
		headers = headers(headers);
		HttpEntity<String> httpEntity = new HttpEntity<>(msgReq, headers);
		
		Response response = restTemplate.postForObject(baseMessagingUrl, httpEntity, Response.class);
		return response;
	}

	@Override
	public Response sendShortenUrl(UserComponent userComponent) {
		HttpHeaders headers = new HttpHeaders();
		String msgReq = constructRequestUrl(userComponent);

		headers = headers(headers);
		HttpEntity<String> httpEntity = new HttpEntity<>(msgReq, headers);
	
		Response response = restTemplate.postForObject(baseMessagingUrl, httpEntity, Response.class);
		return response;
	}

	public String constructRequestUrl(UserComponent userComponent) {

		Body body = new Body();
		Customer customer = new Customer();

		// Set Body
		body.setTransactionId(GeneratorUtils.uniqueRandom(userComponent.getEntity()));
		body.setOperation(ConstantMiddleware.OPERATION_SHORTEN_URL_EIP);
		body.setAppID(ConstantMiddleware.APP_ID_SHORTEN_URL_EIP);
		body.setEntity(userComponent.getEntity());
		body.setService(ConstantMiddleware.SERVICE_MESSAGING_EIP);

		// Set HaveCommunicatedMessage
		List<HaveCommunicatedMessage> haveCommunicatedMessage = new ArrayList<HaveCommunicatedMessage>();
		haveCommunicatedMessage.add(new HaveCommunicatedMessage(userComponent.getContent(), userComponent.getUniqueId(),
				ConstantMiddleware.DELIVERY_URL_SHORTEN_URL_EIP));
		customer.setHaveCommunicatedMessage(haveCommunicatedMessage);

		body.setCustomer(customer);

		String msgReq = request(body);
		return msgReq;
	}

	private String costructReqSms(Notify notify, String entity, String source, String requestId) {

		Body body = new Body();
		Customer customer = new Customer();

		// Set Body
		body.setTransactionId(GeneratorUtils.uniqueRandom(entity));
		body.setOperation(ConstantMiddleware.OPERATION_SMS_EIP);
		body.setAppID(ConstantMiddleware.APP_ID_SMS_EIP);
		body.setEntity(entity);
		body.setService(ConstantMiddleware.SERVICE_MESSAGING_EIP);

		// Set Customer
		if (entity.equals("AMFS")) {
			for (int i = 0; i < notify.getMessage().getRecipient().getTo().size(); i++) {
				HaveCommunicatedMessage haveCommunicatedMessage = new HaveCommunicatedMessage();
				List<HaveCommunicatedMessage> haveCommunicatedMessageList = new ArrayList<HaveCommunicatedMessage>();

				haveCommunicatedMessage.setSender(ConstantMiddleware.SENDER_AMFS);
				haveCommunicatedMessage.setTarget(notify.getMessage().getRecipient().getTo().get(i).getAddress());
				haveCommunicatedMessage.setMessage(notify.getMessage().getBody());
				haveCommunicatedMessage.setBizDivisionX(notify.getAppID());
				haveCommunicatedMessage.setBatchName(ConstantMiddleware.BATCH_NAME);
				haveCommunicatedMessage.setTriggeredBy(ConstantMiddleware.TRIGGERED_BY);
				haveCommunicatedMessage.setChannelID(notify.getMessage().getMessageType());

				haveCommunicatedMessageList.add(haveCommunicatedMessage);
				customer.setHaveCommunicatedMessage(haveCommunicatedMessageList);
			}
		} else {
			for (int i = 0; i < notify.getMessage().getRecipient().getTo().size(); i++) {
				HaveCommunicatedMessage haveCommunicatedMessage = new HaveCommunicatedMessage();
				List<HaveCommunicatedMessage> haveCommunicatedMessageList = new ArrayList<HaveCommunicatedMessage>();

				haveCommunicatedMessage.setSender(ConstantMiddleware.SENDER_AFI);
				haveCommunicatedMessage.setTarget(notify.getMessage().getRecipient().getTo().get(i).getAddress());
				haveCommunicatedMessage.setMessage(notify.getMessage().getBody());
				haveCommunicatedMessage.setBizDivisionX(notify.getAppID());
				haveCommunicatedMessage.setBatchName(ConstantMiddleware.BATCH_NAME);
				haveCommunicatedMessage.setTriggeredBy(ConstantMiddleware.TRIGGERED_BY);
				haveCommunicatedMessage.setChannelID(notify.getMessage().getMessageType());

				haveCommunicatedMessageList.add(haveCommunicatedMessage);
				customer.setHaveCommunicatedMessage(haveCommunicatedMessageList);
			}
		}

		body.setCustomer(customer);
		String msgReq = request(body);
		return msgReq;
	}

	private Header header() {

		Header header = new Header();
		header.setSecurityContext(security());
		return header;
	}

	private SecurityContext security() {

		SecurityContext securityContext = new SecurityContext();
		securityContext.setUsername(userApp);
		securityContext.setPassword(passwordApp);
		return securityContext;
	}

	private String request(Body body) {

		Request request = new Request();

		request.setHeader(header());
		request.setBody(body);

		Gson gson = new GsonBuilder().create();
		String msgReq = gson.toJson(request);

		return msgReq;
	}

	private HttpHeaders headers(HttpHeaders headers) {
		headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
		headers.add(HttpHeaders.ACCEPT_CHARSET, StandardCharsets.UTF_8.name());
		return headers;
	}

	@Override
	public boolean findApplicationName(String applicationName) {
		NotifyConfig notifyConfig = notifyRepository.findByApplicationName(applicationName);
		if(notifyConfig == null) {
			return false;
		}
		return true;
	}
}
