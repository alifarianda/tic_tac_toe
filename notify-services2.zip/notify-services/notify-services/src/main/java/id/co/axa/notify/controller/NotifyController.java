package id.co.axa.notify.controller;

/**
 * 
 * @author Muhammad Mufqi
 * @since 1.0
 * AXA Controller Messaging
 * 
 */

import javax.transaction.Transactional;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

import id.co.axa.commons.core.payload.Status;
import id.co.axa.commons.core.utils.Constant;
import id.co.axa.commons.logging.model.LogAssistantModel;
import id.co.axa.commons.logging.response.ResponseLogging;
import id.co.axa.commons.logging.service.LogAssistantEndService;
import id.co.axa.commons.logging.service.LogAssistantStartService;
import id.co.axa.eip.model.response.Response;
import id.co.axa.middleware.model.util.ConstantMiddleware;
import id.co.axa.notify.component.UserComponent;
import id.co.axa.notify.model.notify.Notify;
import id.co.axa.notify.service.NotifyService;

@CrossOrigin(allowedHeaders = "*", origins = "*", exposedHeaders = "Access-Control-Allow-Origin")
@RestController
@RequestMapping("/notify")
public class NotifyController {

	@Autowired
	private NotifyService notifyService;

	@Autowired
	LogAssistantStartService loggingAssistantStartService;

	@Autowired
	LogAssistantEndService loggingAssistantEndService;

	private static final String SMS = "sms";

	/**
	 * 
	 * @param user
	 * @return HTTP Status Ok
	 * @apiNote This API for implementation sending email
	 */
	@Transactional
	@PostMapping(value = "/send", headers = ("content-type=multipart/form-data"))
	public ResponseEntity<Notify> sendEmail(@RequestHeader(name = "entity", required = true) String entity,
			@RequestHeader(name = "source", required = true) String source,
			@RequestHeader(name = "requestid", required = true) String requestid,
			@RequestParam(name = "notify", required = true) String content,
			@RequestParam(name = "file", required = false) MultipartFile[] file) {

		ResponseLogging responseLogging = new ResponseLogging();
		LogAssistantModel logging = new LogAssistantModel();

		HttpHeaders headers = new HttpHeaders();
		headers.add("entity", entity);
		headers.add("source", source);
		headers.add("requestid", requestid);

		try {
			boolean status = notifyService.findApplicationName(source);
			if (!status) {
				return new ResponseEntity<Notify>(Notify.statusApp(ConstantMiddleware.UNAUTHORIZED),
						headers, HttpStatus.OK);
			}
			ObjectMapper mapper = new ObjectMapper();
			Notify notify = mapper.readValue(content, Notify.class);
			
			// Start Logging
			logging.setClientID(source);
			logging.setContentType("application/json");
			logging.setMethod("POST");
			logging.setRequestID(requestid);

			if (notify.getMessage().getTransportType().equalsIgnoreCase(SMS)) {

				logging.setUrlPath("/send/sms");
				logging.setPayloadRq(notify);
				loggingAssistantStartService.loggingStart(logging);

				Response response = notifyService.sendSms(notify, entity, source, requestid);
				responseLogging = loggingAssistantEndService.loggingEnd(logging, new Notify(Constant.STATUS_SUCCESS));

				if (response.getBody().getException() != null) {
					
					logging.setHttpStatusCD(HttpStatus.OK);
					
					responseLogging = loggingAssistantEndService.loggingEnd(logging, response);

					return new ResponseEntity<Notify>(
							Notify.status(new Notify(Constant.STATUS_FAILED), responseLogging.getObjectHeader()),
							headers, HttpStatus.OK);
				}
			}

			else {
				logging.setUrlPath("/send/email");
				logging.setPayloadRq(notify);
				loggingAssistantStartService.loggingStart(logging);
				
				/**
				 *
				 * @author Degi Herlambang
				 * date june 20, 2021
				 * @since 1.1
				 * adding parameter file
				 *
				 */

				notifyService.sendMail(notify, file);
				
				logging.setHttpStatusCD(HttpStatus.OK);

				responseLogging = loggingAssistantEndService.loggingEnd(logging, new Notify(Constant.STATUS_SUCCESS));
			}

		} catch (Exception e) {

			logging.setHttpStatusCD(HttpStatus.OK);
			responseLogging = loggingAssistantEndService.loggingEnd(logging,
					new Status(Status.ERROR_CODE, Status.ERROR_DESC, e.getLocalizedMessage()));

			return new ResponseEntity<Notify>(
					Notify.status(new Notify(Constant.STATUS_FAILED), responseLogging.getObjectHeader()), headers,
					HttpStatus.OK);
		}
		return new ResponseEntity<Notify>(
				Notify.status(responseLogging.getObjectData(), responseLogging.getObjectHeader()), headers,
				HttpStatus.OK);
	}

	/**
	 * 
	 * @param user
	 * @return shorten url
	 * @apiNote This API for implementation create shorten url to EIP
	 */
	@PostMapping("/shortenurl")
	public ResponseEntity<JSONObject> createShortenUrl(@RequestBody UserComponent user) {
		Response response = notifyService.sendShortenUrl(user);
		return new ResponseEntity<JSONObject>(user.responseToJson(response), HttpStatus.OK);
	}
}
