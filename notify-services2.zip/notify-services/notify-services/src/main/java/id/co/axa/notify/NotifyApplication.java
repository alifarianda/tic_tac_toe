package id.co.axa.notify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EntityScan({"id.co.axa.eip.model","id.co.axa.notify.model","id.co.axa.commons.logging","id.co.axa.commons.core","id.co.axa.middleware.model"})
@ComponentScan(basePackages = {"id.co.axa.eip.model","id.co.axa.notify","id.co.axa.notify.model","id.co.axa.commons.logging","id.co.axa.commons.core","id.co.axa.middleware.model"})

public class NotifyApplication {
	public static void main(String[] args) {
		SpringApplication.run(NotifyApplication.class, args);
	}

}
