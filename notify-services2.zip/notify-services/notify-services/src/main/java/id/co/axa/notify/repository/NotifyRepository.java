package id.co.axa.notify.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import id.co.axa.notify.model.config.NotifyConfig;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@Repository
public interface NotifyRepository extends JpaRepository<NotifyConfig,String> {
	NotifyConfig findByApplicationName(String applicationName);

}
