package id.co.axa.notify.component;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;

/**
 * 
 * @author Muhammad Mufqi
 * @since 1.0
 * AXA Request For Messaging Service
 * 
 */
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import id.co.axa.eip.model.response.Response;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserComponent {
	
	@JsonProperty("content")
	private String content;
	
	@JsonProperty("entity")
	private String entity;
	
	@JsonProperty("uniqueid")
	private String uniqueId;
	

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public JSONObject responseToJson(Response responseJson) {
		Map <String,Object> resp = new HashMap<>();
		if (responseJson.getBody().getException() == null) {
			resp.put("shortenurl",responseJson.getBody().getCustomer().getHaveCommunicatedMessage().get(0).getReplyTo());
		}
		else {
			resp.put("status",responseJson.getBody().getException().getBackEndError());
		}
		JSONObject json = new JSONObject(resp);
		return json;
	}
}
