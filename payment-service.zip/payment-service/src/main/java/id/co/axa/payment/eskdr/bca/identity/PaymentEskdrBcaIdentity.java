package id.co.axa.payment.eskdr.bca.identity;

import java.io.Serializable;

import javax.persistence.Embeddable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author muhammadmufqi
 * @version 1.0
 * @since 1.0
 */

@Embeddable
public class PaymentEskdrBcaIdentity implements Serializable {

	private static final long serialVersionUID = 4103978192521027445L;

	@JsonProperty("request_id")
	private String requestId;

	@JsonProperty("policynumber")
	private String policyNumber;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

}
