package id.co.axa.payment.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */

@Entity
@Table(name="payment_config")
@JsonInclude
public class PaymentModel {
	
	@Id
    @Column(name = "applicationid",nullable = false)
    @JsonProperty("application_id")
	private String applicationId;
	
	@Column(name = "applicationname", length = 80)
    @JsonProperty("applicationname")
	private String applicationName;
	
    @JsonProperty("description")
	@Column(name = "description")
	private String description;

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
