package id.co.axa.payment.eskdr.bca.service;


import org.springframework.stereotype.Service;

import id.co.axa.middleware.model.body.BodyMiddleware;
import id.co.axa.payment.eskdr.bca.model.NotificationEskdrBcaModel;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */
@Service
public interface NotificationEskdrBcaService {

	boolean save (BodyMiddleware bodyMiddleware);
	
	NotificationEskdrBcaModel findByPolisNumber(String polisNumber);
	
	NotificationEskdrBcaModel findByRequestId(String requestId);
	
	NotificationEskdrBcaModel update(NotificationEskdrBcaModel eskdrBcaModel);
	
}
