package id.co.axa.payment.serviceimpl;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import id.co.axa.commons.core.exception.ApplicationException;
import id.co.axa.commons.core.exception.SystemsException;
import id.co.axa.commons.core.payload.Status;
import id.co.axa.commons.core.utils.GeneratorUtils;
import id.co.axa.eip.model.body.Body;
import id.co.axa.eip.model.canbeindividual.CanBeIndividual;
import id.co.axa.eip.model.customer.Customer;
import id.co.axa.eip.model.hasaddressesin.HasAddressesIn;
import id.co.axa.eip.model.hasbilling.HasBilling;
import id.co.axa.eip.model.hasnamevalue.HasNameValue;
import id.co.axa.eip.model.haspartyaccountdetailsin.HasPartyAccountDetailsIn;
import id.co.axa.eip.model.haspartydetailsin.HasPartyDetailsIn;
import id.co.axa.eip.model.haspaymenthistorydetail.HasPaymentHistoryDetail;
import id.co.axa.eip.model.hasplandetailsin.HasPlanDetailsIn;
import id.co.axa.eip.model.haspolicyaccount.HasPolicyAccount;
import id.co.axa.eip.model.header.Header;
import id.co.axa.eip.model.isassociatedwithlifeinsuranceproduct.IsAssociatedWithLifeInsuranceProduct;
import id.co.axa.eip.model.notification.Notification;
import id.co.axa.eip.model.request.Request;
import id.co.axa.eip.model.response.Response;
import id.co.axa.eip.model.securitycontext.SecurityContext;
import id.co.axa.eip.model.task.Task;
import id.co.axa.middleware.model.body.BodyMiddleware;
import id.co.axa.middleware.model.tokenapps.ResponseTokenApps;
import id.co.axa.middleware.model.tokenapps.ResponseTokenAppsDMTM;
import id.co.axa.middleware.model.util.ConstantMiddleware;
import id.co.axa.middleware.model.util.EnumMiddleware;
import id.co.axa.payment.dto.PaymentDTO;
import id.co.axa.payment.model.PaymentModel;
import id.co.axa.payment.repository.PaymentRepository;
import id.co.axa.payment.service.PaymentService;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */

@Service
public class PaymentServiceImpl implements PaymentService {

	@Value("${app.user.app}")
	private String userApp;

	@Value("${app.password.app}")
	private String passwordApp;

	@Value("${app.user.tokenapps}")
	private String userTokenApps;

	@Value("${app.password.tokenapps}")
	private String passTokenApps;

	@Value("${app.base.payment}")
	private String basePaymentUrl;

	@Value("${app.base.tokenapps}")
	private String baseTokenAppsUrl;

	@Autowired
	private PaymentRepository paymentRepository;

	@Autowired
	RestTemplate restTemplate;

//	RestTemplate restTemplate = new RestTemplate();

	public PaymentServiceImpl() {

	}

	@Override
	public BodyMiddleware payment(BodyMiddleware body, String entity, String target, String origin)
			throws ApplicationException, SystemsException {
		// TODO Auto-generated method stub
		Response response = new Response();
		BodyMiddleware responsePayment = new BodyMiddleware();
		HttpHeaders headers = new HttpHeaders();

		String jsonMsg = constructPaymentReq(body, entity, target, origin);

		try {
			headers = headers(headers);
			HttpEntity<String> httpEntity = new HttpEntity<>(jsonMsg, headers);
			response = restTemplate.postForObject(basePaymentUrl, httpEntity, Response.class);

			responsePayment = PaymentDTO.transaction(responsePayment, response);
		} catch (Exception e) {
			throw new ApplicationException(Status.ERROR_DESC, Status.ERROR_CODE, e.getLocalizedMessage());
		}
		return responsePayment;
	}

	@Override
	public BodyMiddleware orderStatus(String trxReference, String entity, String target, String origin,
			EnumMiddleware statusTransaction) throws ApplicationException, SystemsException {
		// TODO Auto-generated method stub
		Response response = new Response();
		BodyMiddleware responsePayment = new BodyMiddleware();
		HttpHeaders headers = new HttpHeaders();

		String jsonMsg = constructOrderStatus(trxReference, entity, target, origin, statusTransaction);

		try {
			headers = headers(headers);
			HttpEntity<String> httpEntity = new HttpEntity<>(jsonMsg, headers);
			response = restTemplate.postForObject(basePaymentUrl, httpEntity, Response.class);

			responsePayment = PaymentDTO.orderStatus(responsePayment, response);
		} catch (Exception e) {
			throw new ApplicationException(Status.ERROR_DESC, Status.ERROR_CODE, e.getLocalizedMessage());
		}
		return responsePayment;
	}

	@Override
	public BodyMiddleware registrasiPrivateCard(BodyMiddleware body, String entity, String target, String origin) {
		// TODO Auto-generated method stub
		ResponseTokenApps responseTokenApps = new ResponseTokenApps();
		ResponseTokenAppsDMTM responseTokenAppsDmtm = new ResponseTokenAppsDMTM();
		BodyMiddleware responseRegister = new BodyMiddleware();
		HttpHeaders headers = new HttpHeaders();

		String jsonMsg = constructRegistrasiCard(body, entity, target, origin);

		try {
			headers = headers(headers);
			HttpEntity<String> httpEntity = new HttpEntity<>(jsonMsg, headers);

			// When Request Policy RLS
			if (body.getCustomField3().contains(ConstantMiddleware.RLS_TYPE)) {
				responseTokenApps = restTemplate.postForObject(baseTokenAppsUrl, httpEntity, ResponseTokenApps.class);
				responseRegister = PaymentDTO.registerPrivateCard(responseRegister, responseTokenApps);
			}

			// When Request Policy DMTM
			else {
				responseTokenAppsDmtm = restTemplate.postForObject(baseTokenAppsUrl, httpEntity,
						ResponseTokenAppsDMTM.class);
				responseRegister = PaymentDTO.registerPrivateCardDMTM(responseRegister, responseTokenAppsDmtm);
			}

		} catch (Exception e) {
			throw new ApplicationException(Status.ERROR_DESC, Status.ERROR_CODE, e.getLocalizedMessage());
		}

		return responseRegister;
	}

	@Override
	public BodyMiddleware registrasiEskdrBca(BodyMiddleware body, String entity, String target, String origin) {
		// TODO Auto-generated method stub
		Response response = new Response();
		BodyMiddleware responseEskdrBca = new BodyMiddleware();
		HttpHeaders headers = new HttpHeaders();

		String jsonMsg = constructRegistrasiCard(body, entity, target, origin);

		try {
			headers = headers(headers);
			HttpEntity<String> httpEntity = new HttpEntity<>(jsonMsg, headers);

			response = restTemplate.postForObject(basePaymentUrl, httpEntity, Response.class);

			responseEskdrBca = PaymentDTO.registerBcaCard(responseEskdrBca, response);

		} catch (Exception e) {
			throw new ApplicationException(Status.ERROR_DESC, Status.ERROR_CODE, e.getLocalizedMessage());

		}

		return responseEskdrBca;
	}

	@Override
	public boolean findApplicationName(String applicationName) {
		PaymentModel paymentDb = paymentRepository.findByApplicationName(applicationName);
		if (paymentDb == null) {
			return false;
		}
		return true;
	}

	// Construct Request To EIP Payment Service
	private String constructPaymentReq(BodyMiddleware body, String entity, String target, String origin) {

		Body bodyEip = new Body();
		Customer customer = new Customer();
		CanBeIndividual canBeIndividual = new CanBeIndividual();
		HasAddressesIn hasAddressesIn = new HasAddressesIn();
		HasPartyAccountDetailsIn hasPartyAccountDetailsIn = new HasPartyAccountDetailsIn();
		HasPolicyAccount hasPolicyAccount = new HasPolicyAccount();
		HasPartyDetailsIn hasPartyDetailsIn = new HasPartyDetailsIn();
		HasBilling hasBilling = new HasBilling();

		// Set Body
		bodyEip.setTransactionId(GeneratorUtils.uniqueRandom(origin));
		bodyEip.setAppID(target);
		bodyEip.setEntity(entity);
		bodyEip.setService(ConstantMiddleware.SERVICE);
		bodyEip.setOperation(ConstantMiddleware.VSNAPTOKEN_OPERATION);

		// Set Element CanBeIndividual
		canBeIndividual.setFirstNM(body.getCustomer().getFirstNM());
		canBeIndividual.setLastNM(body.getCustomer().getLastNM());

		// Initialize List for set HasAddressIn
		List<HasAddressesIn> hasAddressesInList = new ArrayList<HasAddressesIn>();

		// Set Element HasAddressesIn
		hasAddressesIn.setEmailAddress(body.getCustomer().getEmailAddress());
		hasAddressesIn.setMobilePhoneNO(body.getCustomer().getPhoneNumber());

		// Add To List for object HasAddressesIn
		hasAddressesInList.add(hasAddressesIn);

		// Set HasAddressesIn to Object CanBeIndividual
		canBeIndividual.setHasAddressesIn(hasAddressesInList);

		// Set CanBeIndividual to Object Customer
		customer.setCanBeIndividual(canBeIndividual);

		// Set Element HasPartyAccountDetailsIn
		hasPartyAccountDetailsIn.setBankName(body.getPaymentDetails().getBank());

		// Set Object HasPartyAccountDetailsIn to Object CanBeIndividual
		CanBeIndividual canBeIndividualAccount = new CanBeIndividual();
		canBeIndividualAccount.setHasPartyAccountDetailsIn(hasPartyAccountDetailsIn);

		// Set object CanIndvidual to object HasPartyDetailsIn
		hasPartyDetailsIn.setCanBeIndividual(canBeIndividualAccount);

		// Initialize list for object HasPartyDetailsIn
		List<HasPartyDetailsIn> hasPartyDetailsInList = new ArrayList<HasPartyDetailsIn>();

		// Add To List for object HasPartyDetailsIn
		hasPartyDetailsInList.add(hasPartyDetailsIn);

		// Set object HasPartyDetailsIn to object HasPolicyAccount
		hasPolicyAccount.setHasPartyDetailsIn(hasPartyDetailsInList);

		// Set element from object HasBilling
		hasBilling.setTransactionReferenceNO(body.getTrxRefference());
		hasBilling.setGrossAmount(body.getGrossAmount());
		hasBilling.setEnabled_payments(body.getPaymentType());

		// Set object hasBilling to object hasPolicyAccount
		hasPolicyAccount.setHasBilling(hasBilling);

		// Initialize list for object IsAssociatedWithLifeInsuranceProduct
		List<IsAssociatedWithLifeInsuranceProduct> isAssociatedWithLifeInsuranceProductList = new ArrayList<IsAssociatedWithLifeInsuranceProduct>();

		// Looping value from Items and set To List IsAssociatedWithLifeInsuranceProduct
		if (body.getItems() != null) {
			for (int i = 0; i < body.getItems().size(); i++) {

				IsAssociatedWithLifeInsuranceProduct isAssociatedWithLifeInsuranceProduct = new IsAssociatedWithLifeInsuranceProduct();
				HasPlanDetailsIn hasPlanDetailsIn = new HasPlanDetailsIn();

				// Initialize list for object HasPlanDetailsIn
				List<HasPlanDetailsIn> hasPlanDetailsInList = new ArrayList<HasPlanDetailsIn>();

				// Set Element isAssociatedWithLifeInsuranceProduct
				isAssociatedWithLifeInsuranceProduct.setInsuranceProductCd(body.getItems().get(i).getId());
				isAssociatedWithLifeInsuranceProduct.setInsuranceProductRk(body.getItems().get(i).getName());
				isAssociatedWithLifeInsuranceProduct.setProductCategoryRk(body.getItems().get(i).getCategory());

				// Set Element HasPlanDetailsIn
				hasPlanDetailsIn.setPremium(body.getItems().get(i).getAmount());

				// Add To List for object hasPlanDetailsIn
				hasPlanDetailsInList.add(hasPlanDetailsIn);

				// Set Element isAssociatedWithLifeInsuranceProduct
				isAssociatedWithLifeInsuranceProduct.setHasPlanDetailsIn(hasPlanDetailsInList);
				isAssociatedWithLifeInsuranceProduct.setTotalRecordCount(body.getItems().get(i).getQuantity());

				// Add To List for object isAssociatedWithLifeInsuranceProductList
				isAssociatedWithLifeInsuranceProductList.add(isAssociatedWithLifeInsuranceProduct);
			}

			// Set object IsAssociatedWithLifeInsuranceProduct to object HasPolicyAccount
			hasPolicyAccount.setIsAssociatedWithLifeInsuranceProduct(isAssociatedWithLifeInsuranceProductList);
		}

		// Initialize list for object HasNameValue
		List<HasNameValue> hasNameValueList = new ArrayList<HasNameValue>();

		if (body.getPaymentDetails().getSecure() != null) {
			// Add each field name and value by request
			HasNameValue hasNameValueSecure = new HasNameValue();
			hasNameValueSecure.setName(ConstantMiddleware.SECURE);
			hasNameValueSecure.setValue(body.getPaymentDetails().getSecure());
			hasNameValueList.add(hasNameValueSecure);
		}

		if (body.getPaymentDetails().getFinish() != null) {
			HasNameValue hasNameValueFinish = new HasNameValue();
			hasNameValueFinish.setName(ConstantMiddleware.FINISH);
			hasNameValueFinish.setValue(body.getPaymentDetails().getFinish());
			hasNameValueList.add(hasNameValueFinish);
		}

		if (body.getPaymentDetails().getChannel() != null) {
			HasNameValue hasNameValueChannel = new HasNameValue();
			hasNameValueChannel.setName(ConstantMiddleware.CHANNEL);
			hasNameValueChannel.setValue(body.getPaymentDetails().getChannel());
			hasNameValueList.add(hasNameValueChannel);
		}

		if (body.getPaymentDetails().getSaveCard() != null) {
			HasNameValue hasNameValueCard = new HasNameValue();
			hasNameValueCard.setName(ConstantMiddleware.SAVE_CARD);
			hasNameValueCard.setValue(body.getPaymentDetails().getSaveCard());
			hasNameValueList.add(hasNameValueCard);
		}

		// Set object HasNameValue to object HasPolicyAccount
		hasPolicyAccount.setHasNameValue(hasNameValueList);

		// Initialize list for object HasNameValue Custom
		List<HasNameValue> hasNameValueListCustom = new ArrayList<HasNameValue>();

		// Add each field custom_name and value by request
		if (body.getCustomField1() != null) {
			HasNameValue hasNameCustomField1 = new HasNameValue();
			hasNameCustomField1.setName(ConstantMiddleware.CUSTOM_FIELD1);
			hasNameCustomField1.setValue(body.getCustomField1());
			hasNameValueListCustom.add(hasNameCustomField1);
		}

		if (body.getCustomField2() != null) {
			HasNameValue hasNameCustomField2 = new HasNameValue();
			hasNameCustomField2.setName(ConstantMiddleware.CUSTOM_FIELD2);
			hasNameCustomField2.setValue(body.getCustomField2());
			hasNameValueListCustom.add(hasNameCustomField2);
		}
		if (body.getCustomField3() != null) {
			HasNameValue hasNameCustomField3 = new HasNameValue();
			hasNameCustomField3.setName(ConstantMiddleware.CUSTOM_FIELD3);
			hasNameCustomField3.setValue(body.getCustomField3());
			hasNameValueListCustom.add(hasNameCustomField3);
		}

		// Set object HasNameValueCustom to object Customer
		customer.setHasNameValue(hasNameValueListCustom);

		// Initialize list for object HasNameValue
		List<HasPolicyAccount> hasPolicyAccountList = new ArrayList<HasPolicyAccount>();
		hasPolicyAccountList.add(hasPolicyAccount);

		// Set object HasPolicyAccount to object Customer
		customer.setHasPolicyAccount(hasPolicyAccountList);

		// Set Body for Request
		bodyEip.setCustomer(customer);

		String msgReq = request(bodyEip);
		return msgReq;
	}

	private String constructOrderStatus(String trxReference, String entity, String target, String origin,
			EnumMiddleware statusTransaction) {

		Body bodyEip = new Body();
		Customer customer = new Customer();
		HasPolicyAccount hasPolicyAccount = new HasPolicyAccount();
		HasBilling hasBilling = new HasBilling();

		// Set Body
		bodyEip.setTransactionId(GeneratorUtils.uniqueRandom(origin));
		bodyEip.setAppID(target);
		bodyEip.setEntity(entity);
		bodyEip.setService(ConstantMiddleware.DO_ORDER_STATUS_SERVICE);

		switch (statusTransaction) {
		case STATUS:
			bodyEip.setOperation(ConstantMiddleware.DO_ORDER_STATUS_OPERATION);
			break;
		case CANCEL:
			bodyEip.setOperation(ConstantMiddleware.DO_ORDER_CANCEL_OPERATION);
			break;
		}

		// Set element from object HasBilling
		hasBilling.setTransactionReferenceNO(trxReference);

		// Set object hasBilling to object hasPolicyAccount
		hasPolicyAccount.setHasBilling(hasBilling);

		// Initialize list for object HasNameValue
		List<HasPolicyAccount> hasPolicyAccountList = new ArrayList<HasPolicyAccount>();
		hasPolicyAccountList.add(hasPolicyAccount);

		// Set element from object Customer
		customer.setHasPolicyAccount(hasPolicyAccountList);

		// Set Body for Request
		bodyEip.setCustomer(customer);

		String msgReq = request(bodyEip);
		return msgReq;
	}

	private String constructRegistrasiCard(BodyMiddleware body, String entity, String target, String origin) {

		Body bodyEip = new Body();
		Notification notification = new Notification();
		Customer customer = new Customer();
		CanBeIndividual canBeIndividual = new CanBeIndividual();
		HasPolicyAccount hasPolicyAccount = new HasPolicyAccount();
		HasPaymentHistoryDetail hasPaymentHistoryDetail = new HasPaymentHistoryDetail();
		HasBilling hasBilling = new HasBilling();
		Task taskEip = new Task();
		Header header = new Header();
		SecurityContext securityContext = new SecurityContext();
		Request request = new Request();

		Gson gson = new GsonBuilder().create();
		String msgReq = "";

		// Set Request for notify tokenapps
		if (body.getPaymentType().equals(ConstantMiddleware.TASK_ID)) {
			securityContext.setUsername(userTokenApps);
			securityContext.setPassword(passTokenApps);

			// Set Header
			header.setSecurityContext(securityContext);

			// Set Body
			bodyEip.setOperation(ConstantMiddleware.NOTIFY_OPERATION);
			bodyEip.setTransactionId(GeneratorUtils.uniqueRandom(origin));
			bodyEip.setStatus(ConstantMiddleware.STATUS_NOTIFY);
			bodyEip.setEntity(entity);
			bodyEip.setService(ConstantMiddleware.NOTIFY_SERVICE);
			bodyEip.setAppID(ConstantMiddleware.APP_ID_NOTIFY);

			// Set Notification
			notification.setReferenceId(body.getTrxRefference());
			notification.setStatusDesc(body.getPaymentDetails().getStatusMessage());
			notification.setSourceChannel(origin);

			// Set Task EIP
			taskEip.setTaskId(ConstantMiddleware.TASK_ID);
			taskEip.setMessage(body.getPaymentDetails().getStatusMessage());
			taskEip.setStatus(ConstantMiddleware.STATUS_SUCCESS);

			// Set Has Name Value
			HasNameValue hasNameValueStatusCode = new HasNameValue();
			HasNameValue fraudStatus = new HasNameValue();
			HasNameValue trxTime = new HasNameValue();
			HasNameValue trxReference = new HasNameValue();
			HasNameValue customField1 = new HasNameValue();
			HasNameValue customField2 = new HasNameValue();
			HasNameValue customField3 = new HasNameValue();
			HasNameValue statusMessage = new HasNameValue();
			HasNameValue orderId = new HasNameValue();
			HasNameValue channelResponseMessage = new HasNameValue();
			HasNameValue transactionId = new HasNameValue();
			HasNameValue savedTokenId = new HasNameValue();
			HasNameValue currency = new HasNameValue();
			HasNameValue savedTokenIdExpiredAt = new HasNameValue();
			HasNameValue approvalCode = new HasNameValue();
			HasNameValue grossAmount = new HasNameValue();
			HasNameValue transactionStatus = new HasNameValue();
			HasNameValue maskedCard = new HasNameValue();
			HasNameValue cardType = new HasNameValue();
			HasNameValue bank = new HasNameValue();
			HasNameValue paymentType = new HasNameValue();

			List<HasNameValue> hasNameValueList = new ArrayList<HasNameValue>();

			// Set Element STATUS_CODE
			hasNameValueStatusCode.setName(ConstantMiddleware.STATUS_CODE);
			hasNameValueStatusCode.setValue(ConstantMiddleware.STATUS_CODE_VALUE);

			// Add STATUS_CODE to List
			hasNameValueList.add(hasNameValueStatusCode);

			// Set Element TRANSACTION_TIME
			trxTime.setName(ConstantMiddleware.TRANSACTION_TIME);
			trxTime.setValue(body.getPaymentDetails().getTransactionTime());

			// Add TRANSACTION_TIME to List
			hasNameValueList.add(trxTime);

			// Set Element trxReference
			trxReference.setName(ConstantMiddleware.SIGNATURE_KEY);
			trxReference.setValue(body.getTrxRefference());

			// Add trxReference to List
			hasNameValueList.add(trxReference);

			// Set Element fraudStatus
			fraudStatus.setName(ConstantMiddleware.FRAUD_STATUS);
			fraudStatus.setValue(ConstantMiddleware.FRAUD_STATUS_VALUE);

			// Add fraudStatus to List
			hasNameValueList.add(fraudStatus);

			// Set Element customField1
			customField1.setName(ConstantMiddleware.CUSTOM_FIELD1);
			customField1.setValue(body.getCustomField1());

			// Add customField1 to List
			hasNameValueList.add(customField1);

			// Set Element customField2
			customField2.setName(ConstantMiddleware.CUSTOM_FIELD2);
			customField2.setValue(body.getCustomField2());

			// Add customField2 to List
			hasNameValueList.add(customField2);

			// Check customfield3 because that elements optional
			if (body.getCustomField3() != null) {

				// Set Element customField2
				customField3.setName(ConstantMiddleware.CUSTOM_FIELD3);
				customField3.setValue(body.getCustomField3());

				// Add customField3 to List
				hasNameValueList.add(customField3);
			}

			// Set Element statusMessage
			statusMessage.setName(ConstantMiddleware.STATUS_MESSAGE);
			statusMessage.setValue(body.getPaymentDetails().getStatusMessage());

			// Add statusMessage to List
			hasNameValueList.add(statusMessage);

			// Set Element orderId
			orderId.setName(ConstantMiddleware.ORDER_ID);
			orderId.setValue(body.getTrxRefference());

			// Add orderId to List
			hasNameValueList.add(orderId);

			// Set Element channelResponseMessage
			channelResponseMessage.setName(ConstantMiddleware.CHANNEL_RESPONSE_MESSAGE);
			channelResponseMessage.setValue(ConstantMiddleware.CHANNEL_RESPONSE_MESSAGE_VALUE);

			// Add channelResponseMessage to List
			hasNameValueList.add(channelResponseMessage);

			// Set Element transactionId
			transactionId.setName(ConstantMiddleware.TRANSACTION_ID);
			transactionId.setValue(body.getTrxRefference());

			// Add transactionId to List
			hasNameValueList.add(transactionId);

			// Set Element savedTokenId
			savedTokenId.setName(ConstantMiddleware.SAVED_TOKEN_ID);
			savedTokenId.setValue(body.getPaymentDetails().getCcNo());

			// Add savedTokenId to List
			hasNameValueList.add(savedTokenId);

			// Set Element currency
			currency.setName(ConstantMiddleware.CURRENCY);
			currency.setValue(body.getCurrencyCd());

			// Add currency to List
			hasNameValueList.add(currency);

			// Set Element savedTokenIdExpiredAt
			savedTokenIdExpiredAt.setName(ConstantMiddleware.SAVED_TOKEN_ID_EXPIRED_AT);
			savedTokenIdExpiredAt.setValue(body.getPaymentDetails().getSavedTokenIdExpiredAt());

			// Add savedTokenIdExpiredAt to List
			hasNameValueList.add(savedTokenIdExpiredAt);

			// Set Element approvalCode
			approvalCode.setName(ConstantMiddleware.APPROVAL_CODE);
			approvalCode.setValue(body.getPaymentDetails().getCcNo());

			// Add approvalCode to List
			hasNameValueList.add(approvalCode);

			// Set Element grossAmount
			grossAmount.setName(ConstantMiddleware.GROSS_AMOUNT);
			grossAmount.setValue(body.getGrossAmount());

			// Add grossAmount to List
			hasNameValueList.add(grossAmount);

			// Set transactionStatus grossAmount
			transactionStatus.setName(ConstantMiddleware.TRANSACTION_STATUS);
			transactionStatus.setValue(ConstantMiddleware.TRANSACTION_STATUS_VALUE);

			// Add transactionStatus to List
			hasNameValueList.add(transactionStatus);

			// Set maskedCard grossAmount
			maskedCard.setName(ConstantMiddleware.MASKED_CARD);
			maskedCard.setValue(body.getPaymentDetails().getMaskedCard());

			// Add maskedCard to List
			hasNameValueList.add(maskedCard);

			// Set cardType grossAmount
			cardType.setName(ConstantMiddleware.CARD_TYPE);
			cardType.setValue(body.getPaymentDetails().getCardType());

			// Add cardType to List
			hasNameValueList.add(cardType);

			// Set bank grossAmount
			bank.setName(ConstantMiddleware.BANK);
			bank.setValue(body.getPaymentDetails().getBank());

			// Add bank to List
			hasNameValueList.add(bank);

			// Set bank paymentType
			paymentType.setName(ConstantMiddleware.PAYMENT_TYPE);
			paymentType.setValue(body.getPaymentType());

			// Add paymentType to List
			hasNameValueList.add(paymentType);

			// Set hasnamevalue to object task
			taskEip.setHasNameValue(hasNameValueList);

			List<Task> taskList = new ArrayList<Task>();

			// add object task to list
			taskList.add(taskEip);

			// add task to object notification
			notification.setTasks(taskList);

			// add notification to body
			bodyEip.setNotification(notification);

			// Set Request
			request.setHeader(header);
			request.setBody(bodyEip);

			msgReq = gson.toJson(request);
		}

		// Set Request for Eskdr Bca
		else {

			// Set Body
			bodyEip.setOperation(ConstantMiddleware.OPERATION_REGISTRASI_BCA);
			bodyEip.setTransactionId(body.getTrxRefference());
			bodyEip.setEntity(entity);
			bodyEip.setService(ConstantMiddleware.DO_ORDER_STATUS_SERVICE);
			bodyEip.setAppID(ConstantMiddleware.APP_ID_REG_BCA);

			// Set Customer
			customer.setCustomerID(body.getCustomField1());
			customer.setDocumentID(body.getCustomField2());
			customer.setSourceCInd(body.getPaymentDetails().getChannel());

			// Set Canbeindividual
			canBeIndividual.setFirstNM(body.getCustomer().getFirstNM());

			// Set CanBeIndividual to Customer
			customer.setCanBeIndividual(canBeIndividual);

			// Set hasPolicyAccount
			hasBilling.setAmount(body.getGrossAmount());
			hasBilling.setMethod(body.getCustomField3());

			// Set HasPaymentHistoryDetails
			hasPaymentHistoryDetail.setRedirect_Url(body.getPaymentDetails().getFinish());

			// Init HasPaymentHistoryDetailsList
			List<HasPaymentHistoryDetail> hasPaymentHistoryDetailList = new ArrayList<HasPaymentHistoryDetail>();
			hasPaymentHistoryDetailList.add(hasPaymentHistoryDetail);

			// Set HasPaymentHistoryDetailsList to HasBilling
			hasBilling.setHasPaymentHistoryDetails(hasPaymentHistoryDetailList);

			// Set HasPolicyAccount
			hasPolicyAccount.setHasBilling(hasBilling);

			// Init HasPolicyAccountList
			List<HasPolicyAccount> hasPolicyAccountList = new ArrayList<HasPolicyAccount>();

			// Set hasPolicyAccount to hasPolicyAccountList
			hasPolicyAccountList.add(hasPolicyAccount);

			// Set hasPolicyAccountList to Customer
			customer.setHasPolicyAccount(hasPolicyAccountList);

			// Set Body for Request
			bodyEip.setCustomer(customer);

			msgReq = request(bodyEip);
		}

		return msgReq;
	}

	private Header header() {

		Header header = new Header();
		header.setSecurityContext(security());
		return header;
	}

	private SecurityContext security() {

		SecurityContext securityContext = new SecurityContext();
		securityContext.setUsername(userApp);
		securityContext.setPassword(passwordApp);
		return securityContext;
	}

	private String request(Body body) {

		Request request = new Request();

		request.setHeader(header());
		request.setBody(body);

		Gson gson = new GsonBuilder().create();
		String msgReq = gson.toJson(request);

		return msgReq;
	}

	private HttpHeaders headers(HttpHeaders headers) {
		headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
		headers.add(HttpHeaders.ACCEPT_CHARSET, StandardCharsets.UTF_8.name());
		headers.add("Content-Type", "application/json");
		return headers;
	}
}
