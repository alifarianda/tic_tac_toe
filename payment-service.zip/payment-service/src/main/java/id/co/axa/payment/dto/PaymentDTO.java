package id.co.axa.payment.dto;

import java.util.ArrayList;
import java.util.List;

import id.co.axa.commons.core.exception.ApplicationException;
import id.co.axa.commons.core.payload.Status;
import id.co.axa.eip.model.response.Response;
import id.co.axa.middleware.model.body.BodyMiddleware;
import id.co.axa.middleware.model.customer.CustomerMiddleware;
import id.co.axa.middleware.model.item.ItemMiddleware;
import id.co.axa.middleware.model.paymentdetails.PaymentDetailsMiddleware;
import id.co.axa.middleware.model.tokenapps.ResponseTokenApps;
import id.co.axa.middleware.model.tokenapps.ResponseTokenAppsDMTM;
import id.co.axa.middleware.model.util.ConstantMiddleware;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public class PaymentDTO {

	/*
	 * Mapping response payment to payment gateway midtrans
	 */
	public static BodyMiddleware transaction(BodyMiddleware body, Response response) {

		try {
			body.setTrxRefference(response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
					.getTransactionReferenceNO());
			body.setGrossAmount(
					response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling().getGrossAmount());

			CustomerMiddleware customerMiddleware = new CustomerMiddleware();
			customerMiddleware.setFirstNM(response.getBody().getCustomer().getCanBeIndividual().getFirstNM());
			customerMiddleware.setLastNM(response.getBody().getCustomer().getCanBeIndividual().getLastNM());
			customerMiddleware.setEmailAddress(
					response.getBody().getCustomer().getCanBeIndividual().getHasAddressesIn().get(0).getEmailAddress());
			customerMiddleware.setPhoneNumber(response.getBody().getCustomer().getCanBeIndividual().getHasAddressesIn()
					.get(0).getMobilePhoneNO());

			body.setCustomer(customerMiddleware);

			if (response.getBody().getCustomer().getHasPolicyAccount().get(0)
					.getIsAssociatedWithLifeInsuranceProduct() != null) {
				ItemMiddleware itemMiddleware = new ItemMiddleware();
				itemMiddleware.setId(response.getBody().getCustomer().getHasPolicyAccount().get(0)
						.getIsAssociatedWithLifeInsuranceProduct().get(0).getInsuranceProductCd());
				itemMiddleware.setName(response.getBody().getCustomer().getHasPolicyAccount().get(0)
						.getIsAssociatedWithLifeInsuranceProduct().get(0).getInsuranceProductRk());
				itemMiddleware.setAmount(response.getBody().getCustomer().getHasPolicyAccount().get(0)
						.getIsAssociatedWithLifeInsuranceProduct().get(0).getHasPlanDetailsIn().get(0).getPremium());
				itemMiddleware.setQuantity(response.getBody().getCustomer().getHasPolicyAccount().get(0)
						.getIsAssociatedWithLifeInsuranceProduct().get(0).getTotalRecordCount());

				List<ItemMiddleware> itemMiddlewareList = new ArrayList<ItemMiddleware>();
				itemMiddlewareList.add(itemMiddleware);

				body.setItems(itemMiddlewareList);
			}

			body.setPaymentType(response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
					.getEnabledPayments().get(0));

			PaymentDetailsMiddleware paymentDetailsMiddleware = new PaymentDetailsMiddleware();
			paymentDetailsMiddleware.setBank(response.getBody().getCustomer().getHasPolicyAccount().get(0)
					.getHasPartyDetailsIn().get(0).getCanBeIndividual().getHasPartyAccountDetailsIn().getBankName());

			for (int i = 0; i < response.getBody().getCustomer().getHasNameValue().size(); i++) {

				if (response.getBody().getCustomer().getHasNameValue().get(i).getName()
						.equals(ConstantMiddleware.SECURE)) {
					paymentDetailsMiddleware
							.setSecure(response.getBody().getCustomer().getHasNameValue().get(i).getValue());
				}

				if (response.getBody().getCustomer().getHasNameValue().get(i).getName()
						.equals(ConstantMiddleware.FINISH)) {
					paymentDetailsMiddleware
							.setFinish(response.getBody().getCustomer().getHasNameValue().get(i).getValue());
				}

				if (response.getBody().getCustomer().getHasNameValue().get(i).getName()
						.equals(ConstantMiddleware.CHANNEL)) {
					paymentDetailsMiddleware
							.setChannel(response.getBody().getCustomer().getHasNameValue().get(i).getValue());
				}

				if (response.getBody().getCustomer().getHasNameValue().get(i).getName()
						.equals(ConstantMiddleware.SAVE_CARD)) {
					paymentDetailsMiddleware
							.setSaveCard(response.getBody().getCustomer().getHasNameValue().get(i).getValue());
				}
			}

			paymentDetailsMiddleware
					.setToken(response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasPartyDetailsIn()
							.get(0).getCanBeIndividual().getHasPartyAccountDetailsIn().getCardTokenNumber());
			paymentDetailsMiddleware.setRedirectUrl(response.getBody().getCustomer().getHasPolicyAccount().get(0)
					.getHasBilling().getHasPaymentHistoryDetails().get(0).getRedirect_Url());

			body.setPaymentDetails(paymentDetailsMiddleware);

			for (int i = 0; i < response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasNameValue()
					.size(); i++) {
				if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasNameValue().get(i).getName()
						.equals(ConstantMiddleware.CUSTOM_FIELD1)) {
					body.setCustomField1(response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasNameValue()
							.get(i).getValue());
				}
				if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasNameValue().get(i).getName()
						.equals(ConstantMiddleware.CUSTOM_FIELD2)) {
					body.setCustomField2(response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasNameValue()
							.get(i).getValue());
				}
				if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasNameValue().get(i).getName()
						.equals(ConstantMiddleware.CUSTOM_FIELD3)) {
					body.setCustomField3(response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasNameValue()
							.get(i).getValue());
				}
			}
		} catch (Exception e) {
			throw new ApplicationException(response.getBody().getException().getMessage(), Status.ERROR_CODE,
					e.getLocalizedMessage());
		}

		return body;
	}

	/*
	 * Mapping response get order id after payment to payment gateway midtrans
	 */
	public static BodyMiddleware orderStatus(BodyMiddleware body, Response response) {
		try {
			if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
					.getHasPaymentHistoryDetails().get(0).getStatusCode().equals(ConstantMiddleware.HTTP_NOT_FOUND)) {
				body.setTrxRefference(response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
						.getTransactionReferenceNO());

				PaymentDetailsMiddleware paymentDetailsMiddlewareNotFound = new PaymentDetailsMiddleware();

				paymentDetailsMiddlewareNotFound.setStatusMessage(response.getBody().getCustomer().getHasPolicyAccount()
						.get(0).getHasBilling().getHasPaymentHistoryDetails().get(0).getStatusMessage());

				paymentDetailsMiddlewareNotFound.setStatusCode(response.getBody().getCustomer().getHasPolicyAccount()
						.get(0).getHasBilling().getHasPaymentHistoryDetails().get(0).getStatusCode());
				body.setPaymentDetails(paymentDetailsMiddlewareNotFound);
			}

			else {
				body.setTrxRefference(response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
						.getTransactionReferenceNO());
				body.setGrossAmount(
						response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling().getGrossAmount());
				body.setCurrencyCd(response.getBody().getCustomer().getHasPolicyAccount().get(0).getCurrencyCD());

				PaymentDetailsMiddleware paymentDetailsMiddleware = new PaymentDetailsMiddleware();

				paymentDetailsMiddleware.setApprovalCode(response.getBody().getCustomer().getHasPolicyAccount().get(0)
						.getHasBilling().getHasPaymentHistoryDetails().get(0).getApprovalCode());
				paymentDetailsMiddleware.setTransactionTime(response.getBody().getCustomer().getHasPolicyAccount()
						.get(0).getHasBilling().getHasPaymentHistoryDetails().get(0).getTransactionTime());
				paymentDetailsMiddleware.setPaymentRefID(response.getBody().getCustomer().getHasPolicyAccount().get(0)
						.getHasBilling().getHasPaymentHistoryDetails().get(0).getPaymentRefID());
				paymentDetailsMiddleware.setTransactionStatus(response.getBody().getCustomer().getHasPolicyAccount()
						.get(0).getHasBilling().getHasPaymentHistoryDetails().get(0).getTransactionStatus());
				body.setPaymentType(response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
						.getHasPaymentHistoryDetails().get(0).getPaymentType());
				paymentDetailsMiddleware.setStatusMessage(response.getBody().getCustomer().getHasPolicyAccount().get(0)
						.getHasBilling().getHasPaymentHistoryDetails().get(0).getStatusMessage());

				paymentDetailsMiddleware.setStatusCode(response.getBody().getCustomer().getHasPolicyAccount().get(0)
						.getHasBilling().getHasPaymentHistoryDetails().get(0).getStatusCode());

				paymentDetailsMiddleware.setSaveTokenId(
						response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling().getSaveTokenId());

				for (int i = 0; i < response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
						.getHasPaymentHistoryDetails().get(0).getHasNameValue().size(); i++) {

					if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
							.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getName()
							.equals(ConstantMiddleware.CUSTOM_FIELD1)) {
						body.setCustomField1(
								response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
										.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getValue());
					}
					if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
							.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getName()
							.equals(ConstantMiddleware.CUSTOM_FIELD2)) {
						body.setCustomField2(
								response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
										.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getValue());
					}
					if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
							.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getName()
							.equals(ConstantMiddleware.CUSTOM_FIELD3)) {
						body.setCustomField3(
								response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
										.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getValue());
					}
					if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
							.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getName()
							.equals(ConstantMiddleware.SIGNATURE_KEY)) {
						paymentDetailsMiddleware.setSignatureKey(
								response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
										.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getValue());
					}
					if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
							.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getName()
							.equals(ConstantMiddleware.CHANNEL_RESPONSE_MESSAGE)) {
						paymentDetailsMiddleware.setChannelResponseMessage(
								response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
										.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getValue());
					}
					if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
							.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getName()
							.equals(ConstantMiddleware.CHANNEL_RESPONSE_CODE)) {
						paymentDetailsMiddleware.setChannelResponseCode(
								response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
										.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getValue());
					}
					if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
							.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getName()
							.equals(ConstantMiddleware.SAVED_TOKEN_ID_EXPIRED_AT)) {
						paymentDetailsMiddleware.setSavedTokenIdExpiredAt(
								response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
										.getHasPaymentHistoryDetails().get(0).getHasNameValue().get(i).getValue());
					}

				}

				if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
						.getHasPaymentHistoryDetails().get(0).getBank() != null) {
					paymentDetailsMiddleware.setBank(response.getBody().getCustomer().getHasPolicyAccount().get(0)
							.getHasBilling().getHasPaymentHistoryDetails().get(0).getBank());
				}

				if (response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling()
						.getHasPaymentHistoryDetails().get(0).getMaskedCard() != null) {
					paymentDetailsMiddleware.setMaskedCard(response.getBody().getCustomer().getHasPolicyAccount().get(0)
							.getHasBilling().getHasPaymentHistoryDetails().get(0).getMaskedCard());
				}

				paymentDetailsMiddleware.setStatusCode(response.getBody().getCustomer().getHasPolicyAccount().get(0)
						.getHasBilling().getHasPaymentHistoryDetails().get(0).getStatusCode());
				body.setPaymentDetails(paymentDetailsMiddleware);
			}
		} catch (Exception e) {
			throw new ApplicationException(response.getBody().getException().getMessage(), Status.ERROR_CODE,
					e.getLocalizedMessage());
		}
		return body;
	}

	/*
	 * Mapping response tokenize from tokenapps RLS
	 */
	public static BodyMiddleware registerPrivateCard(BodyMiddleware body, ResponseTokenApps responseTokenApps) {
		try {
			body.setInternalizedToken(responseTokenApps.getInternalizeTokenResponse().getInternalizedToken());
		} catch (Exception e) {
			throw new ApplicationException(Status.ERROR_CODE, Status.ERROR_DESC, e.getMessage());
		}
		return body;
	}
	
	/*
	 * Mapping response tokenize from tokenapps DMTM
	 */
	public static BodyMiddleware registerPrivateCardDMTM(BodyMiddleware body, ResponseTokenAppsDMTM responseTokenAppsDMTM) {
		try {
			body.setMessage(responseTokenAppsDMTM.getMessage());
		} catch (Exception e) {
			throw new ApplicationException(Status.ERROR_CODE, Status.ERROR_DESC, e.getMessage());
		}
		return body;
	}

	/*
	 * Mapping response eskdr bca from eip
	 */
	public static BodyMiddleware registerBcaCard(BodyMiddleware body, Response response) {
		try {

			if (response.getBody().getException() != null) {

				PaymentDetailsMiddleware paymentDetailsMiddlewareNotFound = new PaymentDetailsMiddleware();

				paymentDetailsMiddlewareNotFound.setStatusMessage(response.getBody().getException().getMessage());

				paymentDetailsMiddlewareNotFound.setStatusCode(response.getBody().getException().getCode());

				body.setPaymentDetails(paymentDetailsMiddlewareNotFound);
			}

			else {
				// Initialize CustomerMiddleware Object
				CustomerMiddleware customer = new CustomerMiddleware();

				// Set BodyMiddleware for response
				body.setTrxRefference(response.getBody().getTransactionId());
				body.setGrossAmount(
						response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling().getAmount());

				// Set CustomerMiddleware Response
				customer.setFirstNM(response.getBody().getCustomer().getCanBeIndividual().getFirstNM());

				// SetCustomerMiddleware to BodyMiddleware for response
				body.setCustomer(customer);

				body.setPaymentType(ConstantMiddleware.TASK_ID_BCA);

				// Set PaymentDetails for response
				PaymentDetailsMiddleware paymentDetailsMiddleware = new PaymentDetailsMiddleware();
				paymentDetailsMiddleware.setBank(ConstantMiddleware.APP_ID_REG_BCA);
				paymentDetailsMiddleware.setChannel(response.getBody().getCustomer().getSourceCInd());
				paymentDetailsMiddleware.setFinish(response.getBody().getCustomer().getHasPolicyAccount().get(0)
						.getHasBilling().getHasPaymentHistoryDetails().get(0).getRedirect_Url());
				paymentDetailsMiddleware.setTransactionTime(
						response.getBody().getCustomer().getHasPolicyAccount().get(0).getProcessedDttm());
				paymentDetailsMiddleware.setSavedTokenIdExpiredAt(
						response.getBody().getCustomer().getHasPolicyAccount().get(0).getPolicyExpirationDTTM());
				paymentDetailsMiddleware.setSaveTokenId(
						response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling().getSaveTokenId());
				paymentDetailsMiddleware.setSignatureKey(
						response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling().getRemark1());

				// Set PaymentDetails to BodyMiddleware for response
				body.setPaymentDetails(paymentDetailsMiddleware);

				body.setCustomField1(response.getBody().getCustomer().getCustomerID());
				body.setCustomField2(response.getBody().getCustomer().getDocumentID());
				body.setCustomField3(
						response.getBody().getCustomer().getHasPolicyAccount().get(0).getHasBilling().getMethod());
			}
		} catch (Exception e) {
			throw new ApplicationException(Status.ERROR_CODE, Status.ERROR_DESC, e.getMessage());
		}
		return body;
	}
}
