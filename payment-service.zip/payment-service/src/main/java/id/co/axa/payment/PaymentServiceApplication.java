package id.co.axa.payment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EntityScan({"id.co.axa.eip.model","id.co.axa.payment","id.co.axa.commons.logging","id.co.axa.commons.core"})
@ComponentScan(basePackages = {"id.co.axa.payment","id.co.axa.eip.model","id.co.axa.commons.logging","id.co.axa.commons.core"})
public class PaymentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentServiceApplication.class, args);
	}

}
