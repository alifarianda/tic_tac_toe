package id.co.axa.payment.service;

import id.co.axa.middleware.model.body.BodyMiddleware;
import id.co.axa.middleware.model.util.EnumMiddleware;


/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */
public interface PaymentService {
	BodyMiddleware payment(BodyMiddleware body,String entity,String target,String origin);
	
	BodyMiddleware orderStatus(String trxReference,String entity,String target,String origin,EnumMiddleware statusTransaction);
	
	BodyMiddleware registrasiPrivateCard(BodyMiddleware body,String entity,String target,String origin);
	
	BodyMiddleware registrasiEskdrBca(BodyMiddleware body,String entity,String target,String origin);
	
	boolean findApplicationName(String applicationName);
}
