package id.co.axa.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import id.co.axa.payment.model.PaymentModel;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@Repository
public interface PaymentRepository extends JpaRepository<PaymentModel, String> {	
	PaymentModel findByApplicationName(String applicationName);	
}
