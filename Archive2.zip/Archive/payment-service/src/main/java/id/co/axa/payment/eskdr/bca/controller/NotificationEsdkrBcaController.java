package id.co.axa.payment.eskdr.bca.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import id.co.axa.commons.logging.model.LogAssistantModel;
import id.co.axa.commons.logging.service.LogAssistantEndService;
import id.co.axa.commons.logging.service.LogAssistantStartService;
import id.co.axa.payment.eskdr.bca.dto.NotificationEskdrBcaDTO;
import id.co.axa.payment.eskdr.bca.model.NotificationEskdrBcaModel;
import id.co.axa.payment.eskdr.bca.service.NotificationEskdrBcaService;

/**
 * @author muhammadmufqi
 * @version 1.0
 * @since 1.0
 */

@CrossOrigin(allowedHeaders = "*", origins = "*", exposedHeaders = "Access-Control-Allow-Origin")
@RestController
@RequestMapping("")
public class NotificationEsdkrBcaController {

	@Autowired
	private NotificationEskdrBcaService notificationEskdrBcaService;

	@Autowired
	LogAssistantStartService loggingAssistantStartService;

	@Autowired
	LogAssistantEndService loggingAssistantEndService;

	// This field required for logging
	private static final String HEADER_TARGET = "NotificationBCA";
	private static final String HEADER_SOURCE = "BCA";

	// Set Response WS
	private static final String RESPONSE_WS_SUCCESS = "0";
	
	// Set Response WS
	private static final String RESPONSE_WS_FAILED = "1";

	@Transactional
	@PostMapping("/account-authorization/notification")
	public ResponseEntity<Object> notifybca(@Valid @RequestBody NotificationEskdrBcaModel notifyBca) {

		HttpHeaders headers = new HttpHeaders();
		headers.add("target", HEADER_TARGET);
		headers.add("source", HEADER_SOURCE);
		headers.add("requestid", notifyBca.getRequestId());

		LogAssistantModel logging = new LogAssistantModel();
		NotificationEskdrBcaModel notificationEskdrBcaModel = new NotificationEskdrBcaModel();

		try {
			// Start Logging
			logging.setClientID(HEADER_SOURCE);
			logging.setContentType("application/json");
			logging.setMethod("POST");
			logging.setUrlPath("/account-authorization/notification");
			logging.setRequestID(notifyBca.getRequestId());
			logging.setPayloadRq(notifyBca);

			// Logging Start
			loggingAssistantStartService.loggingStart(logging);

			// Update data from notify BCA
			notificationEskdrBcaService.update(notifyBca);

			// Set Response
			NotificationEskdrBcaDTO notificationEskdrBcaDTO = new NotificationEskdrBcaDTO(
					notificationEskdrBcaModel.getRequestId(), RESPONSE_WS_SUCCESS);

			// Set HTTP code for logging
			logging.setHttpStatusCD(HttpStatus.OK);

			// Start logging end
			loggingAssistantEndService.loggingEnd(logging, notificationEskdrBcaDTO);

		} catch (Exception e) {
			// Set HTTP code for logging
			logging.setHttpStatusCD(HttpStatus.OK);

			// Set response Failed
			NotificationEskdrBcaDTO notificationEskdrBcaDTOFailed = new NotificationEskdrBcaDTO(
					notificationEskdrBcaModel.getRequestId(), RESPONSE_WS_FAILED);

			// Start logging end
			loggingAssistantEndService.loggingEnd(logging, notificationEskdrBcaDTOFailed);

			return new ResponseEntity<Object>(
					NotificationEskdrBcaDTO.response(notificationEskdrBcaDTOFailed.getRequestId(), RESPONSE_WS_FAILED),
					HttpStatus.OK);
		}

		return new ResponseEntity<Object>(
				NotificationEskdrBcaDTO.response(notificationEskdrBcaModel.getRequestId(), RESPONSE_WS_SUCCESS),
				HttpStatus.OK);
	}

}
