package id.co.axa.payment.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import id.co.axa.commons.core.payload.Status;
import id.co.axa.commons.core.utils.Constant;
import id.co.axa.commons.logging.model.LogAssistantModel;
import id.co.axa.commons.logging.response.ResponseLogging;
import id.co.axa.commons.logging.service.LogAssistantEndService;
import id.co.axa.commons.logging.service.LogAssistantStartService;
import id.co.axa.middleware.model.body.BodyMiddleware;
import id.co.axa.middleware.model.util.ConstantMiddleware;
import id.co.axa.middleware.model.util.EnumMiddleware;
import id.co.axa.payment.eskdr.bca.service.NotificationEskdrBcaService;
import id.co.axa.payment.service.PaymentService;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */

@CrossOrigin(allowedHeaders = "*", origins = "*", exposedHeaders = "Access-Control-Allow-Origin")
@RestController
@RequestMapping("/api")
public class PaymentServiceController {

	@Autowired
	private PaymentService paymentService;

	@Autowired
	private NotificationEskdrBcaService notificationEskdrBcaService;

	@Autowired
	LogAssistantStartService loggingAssistantStartService;

	@Autowired
	LogAssistantEndService loggingAssistantEndService;

	@Transactional
	@PostMapping("/v1/transaction")
	public ResponseEntity<BodyMiddleware> transaction(@RequestHeader(name = "entity", required = true) String entity,
			@RequestHeader(name = "target", required = true) String target,
			@RequestHeader(name = "source", required = true) String source,
			@RequestHeader(name = "requestid", required = true) String requestid,
			@Valid @RequestBody BodyMiddleware body) {

		HttpHeaders headers = new HttpHeaders();
		headers.add("entity", entity);
		headers.add("target", target);
		headers.add("source", source);
		headers.add("requestid", requestid);

		ResponseLogging responseLogging = new ResponseLogging();
		LogAssistantModel logging = new LogAssistantModel();

		try {

			// Check permissions for access this service
			boolean status = paymentService.findApplicationName(source);
			if (!status) {
				return new ResponseEntity<BodyMiddleware>(BodyMiddleware.status(ConstantMiddleware.UNAUTHORIZED),
						headers, HttpStatus.OK);
			}

			// Start Logging
			logging.setClientID(source);
			logging.setContentType("application/json");
			logging.setMethod("POST");
			logging.setUrlPath("/api/v1/transaction");
			logging.setRequestID(requestid);
			logging.setPayloadRq(body);

			// Logging Start
			loggingAssistantStartService.loggingStart(logging);

			// Set Response
			BodyMiddleware responseEip = paymentService.payment(body, entity, target, source);

			// Set HTTP Code for Logging
			logging.setHttpStatusCD(HttpStatus.OK);

			// Set Response to Logging
			responseLogging = loggingAssistantEndService.loggingEnd(logging, responseEip);

		} catch (Exception e) {

			// Set HTTP Code for Logging
			logging.setHttpStatusCD(HttpStatus.OK);

			// Set Response Error to Logging
			responseLogging = loggingAssistantEndService.loggingEnd(logging,
					new Status(Status.ERROR_CODE, Status.ERROR_DESC, e.getMessage()));

			return new ResponseEntity<BodyMiddleware>(BodyMiddleware.response(
					new BodyMiddleware(Constant.STATUS_FAILED), responseLogging.getObjectHeader()), HttpStatus.OK);
		}
		return new ResponseEntity<BodyMiddleware>(
				BodyMiddleware.response(responseLogging.getObjectData(), responseLogging.getObjectHeader()), headers,
				HttpStatus.OK);
	}

	@Transactional
	@GetMapping("/v1/transaction/{trxReference}")
	public ResponseEntity<BodyMiddleware> getTransaction(@RequestHeader(name = "entity", required = true) String entity,
			@RequestHeader(name = "target", required = true) String target,
			@RequestHeader(name = "source", required = true) String source,
			@RequestHeader(name = "requestid", required = true) String requestid,
			@Valid @PathVariable String trxReference) {

		HttpHeaders headers = new HttpHeaders();
		headers.add("entity", entity);
		headers.add("target", target);
		headers.add("source", source);
		headers.add("requestid", requestid);

		ResponseLogging responseLogging = new ResponseLogging();
		LogAssistantModel logging = new LogAssistantModel();

		try {

			// Check permissions for access this service
			boolean status = paymentService.findApplicationName(source);
			if (!status) {
				return new ResponseEntity<BodyMiddleware>(BodyMiddleware.status(ConstantMiddleware.UNAUTHORIZED),
						headers, HttpStatus.OK);
			}

			// Start Logging
			logging.setClientID(source);
			logging.setContentType("application/json");
			logging.setMethod("GET");
			logging.setUrlPath("/api/v1/transaction/{transactionid}");
			logging.setRequestID(requestid);
			logging.setPayloadRq(trxReference);

			// Logging Start
			loggingAssistantStartService.loggingStart(logging);

			// Set Response
			BodyMiddleware response = paymentService.orderStatus(trxReference, entity, target, source,
					EnumMiddleware.STATUS);

			// Set HTTP Code for Logging
			logging.setHttpStatusCD(HttpStatus.OK);

			// Set Response to Logging
			responseLogging = loggingAssistantEndService.loggingEnd(logging, response);

		} catch (Exception e) {

			// Set HTTP Code for Logging
			logging.setHttpStatusCD(HttpStatus.OK);

			// Set Response Error to Logging
			responseLogging = loggingAssistantEndService.loggingEnd(logging,
					new Status(Status.ERROR_CODE, Status.ERROR_DESC, e.getLocalizedMessage()));

			return new ResponseEntity<BodyMiddleware>(BodyMiddleware.response(
					new BodyMiddleware(Constant.STATUS_FAILED), responseLogging.getObjectHeader()), HttpStatus.OK);
		}
		return new ResponseEntity<BodyMiddleware>(
				BodyMiddleware.response(responseLogging.getObjectData(), responseLogging.getObjectHeader()), headers,
				HttpStatus.OK);
	}

	@Transactional
	@DeleteMapping("/v1/transaction/{trxReference}")
	public ResponseEntity<BodyMiddleware> cancelTransaction(
			@RequestHeader(name = "entity", required = true) String entity,
			@RequestHeader(name = "target", required = true) String target,
			@RequestHeader(name = "source", required = true) String source,
			@RequestHeader(name = "requestid", required = true) String requestid,
			@Valid @PathVariable String trxReference) {

		HttpHeaders headers = new HttpHeaders();
		headers.add("entity", entity);
		headers.add("target", target);
		headers.add("source", source);
		headers.add("requestid", requestid);

		ResponseLogging responseLogging = new ResponseLogging();
		LogAssistantModel logging = new LogAssistantModel();

		try {

			// Check permissions for access this service
			boolean status = paymentService.findApplicationName(source);
			if (!status) {
				return new ResponseEntity<BodyMiddleware>(BodyMiddleware.status(ConstantMiddleware.UNAUTHORIZED),
						headers, HttpStatus.OK);
			}

			// Start Logging
			logging.setClientID(source);
			logging.setContentType("application/json");
			logging.setMethod("DELETE");
			logging.setUrlPath("/api/v1/transaction/{transactionid}");
			logging.setRequestID(requestid);
			logging.setPayloadRq(trxReference);

			// Logging Start
			loggingAssistantStartService.loggingStart(logging);

			// Set Response
			BodyMiddleware response = paymentService.orderStatus(trxReference, entity, target, source,
					EnumMiddleware.CANCEL);

			// Set HTTP Code for Logging
			logging.setHttpStatusCD(HttpStatus.OK);

			// Set Response to Logging
			responseLogging = loggingAssistantEndService.loggingEnd(logging, response);

		} catch (Exception e) {

			// Set HTTP Code for Logging
			logging.setHttpStatusCD(HttpStatus.OK);

			// Set Response Error to Logging
			responseLogging = loggingAssistantEndService.loggingEnd(logging,
					new Status(Status.ERROR_CODE, Status.ERROR_DESC, e.getLocalizedMessage()));

			return new ResponseEntity<BodyMiddleware>(BodyMiddleware.response(
					new BodyMiddleware(Constant.STATUS_FAILED), responseLogging.getObjectHeader()), HttpStatus.OK);
		}
		return new ResponseEntity<BodyMiddleware>(
				BodyMiddleware.response(responseLogging.getObjectData(), responseLogging.getObjectHeader()), headers,
				HttpStatus.OK);
	}

	@Transactional
	@PostMapping("/v1/paymentToken")
	public ResponseEntity<BodyMiddleware> paymentToken(@RequestHeader(name = "entity", required = true) String entity,
			@RequestHeader(name = "target", required = true) String target,
			@RequestHeader(name = "source", required = true) String source,
			@RequestHeader(name = "requestid", required = true) String requestid,
			@Valid @RequestBody BodyMiddleware body) {

		HttpHeaders headers = new HttpHeaders();
		headers.add("entity", entity);
		headers.add("target", target);
		headers.add("source", source);
		headers.add("requestid", requestid);

		ResponseLogging responseLogging = new ResponseLogging();
		LogAssistantModel logging = new LogAssistantModel();
		BodyMiddleware response = new BodyMiddleware();

		try {

			// Check permissions for access this service
			boolean status = paymentService.findApplicationName(source);
			if (!status) {
				return new ResponseEntity<BodyMiddleware>(BodyMiddleware.status(ConstantMiddleware.UNAUTHORIZED),
						headers, HttpStatus.OK);
			}

			// Start Logging
			logging.setClientID(source);
			logging.setContentType("application/json");
			logging.setMethod("POST");
			logging.setUrlPath("/api/v1/transaction/{transactionid}");
			logging.setRequestID(requestid);
			logging.setPayloadRq(body);

			loggingAssistantStartService.loggingStart(logging);

			// When request to TokenApps
			if (body.getPaymentType().equals(ConstantMiddleware.TASK_ID)) {
				response = paymentService.registrasiPrivateCard(body, entity, target, source);
			}

			// When request to E-SKDR BCA
			else {
				response = paymentService.registrasiEskdrBca(body, entity, target, source);

				// Save element to DB
				if (response.getPaymentDetails().getTransactionTime() != null) {
					notificationEskdrBcaService.save(response);
				}
			}

			// Set HTTP Code for Logging
			logging.setHttpStatusCD(HttpStatus.OK);

			// Set Response to Logging
			responseLogging = loggingAssistantEndService.loggingEnd(logging, response);

		} catch (Exception e) {

			// Set HTTP Code for Logging
			logging.setHttpStatusCD(HttpStatus.OK);

			// Set Response Error to Logging
			responseLogging = loggingAssistantEndService.loggingEnd(logging,
					new Status(Status.ERROR_CODE, Status.ERROR_DESC, e.getLocalizedMessage()));

			return new ResponseEntity<BodyMiddleware>(BodyMiddleware.response(
					new BodyMiddleware(Constant.STATUS_FAILED), responseLogging.getObjectHeader()), HttpStatus.OK);
		}
		return new ResponseEntity<BodyMiddleware>(
				BodyMiddleware.response(responseLogging.getObjectData(), responseLogging.getObjectHeader()), headers,
				HttpStatus.OK);
	}

}
