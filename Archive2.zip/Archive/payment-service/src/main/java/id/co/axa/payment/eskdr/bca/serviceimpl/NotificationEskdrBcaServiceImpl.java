package id.co.axa.payment.eskdr.bca.serviceimpl;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import id.co.axa.commons.core.exception.ApplicationException;
import id.co.axa.commons.core.utils.Constant;
import id.co.axa.commons.core.utils.DateUtils;
import id.co.axa.commons.core.utils.GeneratorUtils;
import id.co.axa.eip.model.body.Body;
import id.co.axa.eip.model.customer.Customer;
import id.co.axa.eip.model.hasaxaasiapartyaccount.HasAXAAsiaPartyAccount;
import id.co.axa.eip.model.hasaxaasiapolicypaymentaccount.HasAXAAsiaPolicyPaymentAccount;
import id.co.axa.eip.model.haspolicyaccount.HasPolicyAccount;
import id.co.axa.eip.model.header.Header;
import id.co.axa.eip.model.request.Request;
import id.co.axa.eip.model.response.Response;
import id.co.axa.eip.model.securitycontext.SecurityContext;
import id.co.axa.middleware.model.body.BodyMiddleware;
import id.co.axa.middleware.model.util.ConstantMiddleware;
import id.co.axa.payment.eskdr.bca.model.NotificationEskdrBcaModel;
import id.co.axa.payment.eskdr.bca.repository.NotificationBcaRepository;
import id.co.axa.payment.eskdr.bca.service.NotificationEskdrBcaService;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */
@Service
public class NotificationEskdrBcaServiceImpl implements NotificationEskdrBcaService {

	@Autowired
	private NotificationBcaRepository notificationBcaRepository;

	RestTemplate restTemplate = new RestTemplate();
	
	@Value("${app.user.customer}")
	private String userCustomer;

	@Value("${app.password.customer}")
	private String passwordCustomer;
	
	@Value("${app.base.customer}")
	private String baseCustomerUrl;
	
	//Unique Identifier to EIP
	private static final String DMTM_EIP_BCA = "AFIPAY";
	
	//Entity ESKDR BCA for AFI
	private static final String ENTITY_BCA_AFI = "AFI";
	
	//Status Success From EIP DMTM Activation Policy
	private static final String STATUS_EIP_DMTM = "1";

	@Override
	@Transactional
	public boolean save(BodyMiddleware bodyMiddleware) throws ApplicationException {

		try {
			if (bodyMiddleware.getCustomer() == null) {
				throw new ApplicationException(bodyMiddleware.getPaymentDetails().getStatusMessage());
			}
			// Find Policy Number on DB
			NotificationEskdrBcaModel eskdrDB = notificationBcaRepository
					.findByPolicyNumber(bodyMiddleware.getCustomField1());

			// Checking record by policy number
			if (eskdrDB != null) {
				return false;
			}

			// When policy number not exist then save to DB
			NotificationEskdrBcaModel eskdrBcaModel = new NotificationEskdrBcaModel();

			eskdrBcaModel.setPolicyNumber(bodyMiddleware.getCustomField1());
			eskdrBcaModel.setRequestId(bodyMiddleware.getPaymentDetails().getSaveTokenId());

			// Convert from response EIP to long
			long trxTime = Long.parseLong(bodyMiddleware.getPaymentDetails().getTransactionTime());
			long expiredTime = Long.parseLong(bodyMiddleware.getPaymentDetails().getSavedTokenIdExpiredAt());

			eskdrBcaModel.setCreatedDt(DateUtils.unixTimeStampToDate(trxTime));
			eskdrBcaModel.setExpiredDt(DateUtils.unixTimeStampToDate(expiredTime));

			eskdrBcaModel.setSendToCore(false);
			eskdrBcaModel.setEmailed(false);
			notificationBcaRepository.save(eskdrBcaModel);

		} catch (Exception e) {
			throw new ApplicationException(e.getCause());
		}

		return true;
	}

	@Override
	public NotificationEskdrBcaModel findByPolisNumber(String polisNumber) {
		return notificationBcaRepository.findByPolicyNumber(polisNumber);
	}

	@Transactional
	@Override
	public NotificationEskdrBcaModel update(NotificationEskdrBcaModel eskdrBcaModel) {
		NotificationEskdrBcaModel bcaModelDB = notificationBcaRepository
				.findByRequestId(eskdrBcaModel.getRequestId());
		
		//Get Response from EIP
		Response response = new Response();
		HttpHeaders headers = new HttpHeaders();

		try {
			// Checking record
			if (bcaModelDB == null) {
				throw new ApplicationException(Constant.STATUS_FAILED, "Update", eskdrBcaModel.getRequestId());
			} else {
				
				String jsonMsg = customerDMTM(bcaModelDB,eskdrBcaModel);
				headers = headers(headers);
				HttpEntity<String> httpEntity = new HttpEntity<>(jsonMsg, headers);
				
				//Hit to EIP DMTM Activation Policy
				response = restTemplate.postForObject(baseCustomerUrl, httpEntity, Response.class);
				
				//Check Response Success from EIP DMTM Activation Policy
				if(response.getBody().getStatus().equals(STATUS_EIP_DMTM)) {
					eskdrBcaModel.setPolicyNumber(bcaModelDB.getPolicyNumber());
					eskdrBcaModel.setSendToCore(true);
					eskdrBcaModel.setEmailed(true);
				}
				else {
					throw new ApplicationException(Constant.STATUS_FAILED, "Update", eskdrBcaModel.getRequestId());
				}
			}
		} catch (Exception e) {
			throw new ApplicationException(Constant.STATUS_FAILED, e.getCause());
		}
		return notificationBcaRepository.save(eskdrBcaModel);
	}

	@Override
	public NotificationEskdrBcaModel findByRequestId(String requestId) {
		return notificationBcaRepository.findByRequestId(requestId);
	}
	
	//Construct request to EIP Customer DMTM
	private String customerDMTM (NotificationEskdrBcaModel eskdrBcaDB, NotificationEskdrBcaModel eskdrBcaModel) {
		Body bodyEip = new Body();
		Customer customer = new Customer();
		HasPolicyAccount hasPolicyAccount = new HasPolicyAccount();
		HasAXAAsiaPolicyPaymentAccount hasAXAAsiaPolicyPaymentAccount = new HasAXAAsiaPolicyPaymentAccount();
		HasAXAAsiaPartyAccount hasAXAAsiaPartyAccount = new HasAXAAsiaPartyAccount();
		
		//Set Body EIP
		bodyEip.setTransactionId(GeneratorUtils.uniqueRandom(DMTM_EIP_BCA));
		bodyEip.setOperation(ConstantMiddleware.COLLECTION_ACTIVATION_OPERATION);
		bodyEip.setAppID(ConstantMiddleware.DMTM_SOURCE);
		bodyEip.setEntity(ENTITY_BCA_AFI);
		bodyEip.setService(ConstantMiddleware.SERVICE_COLLECTION_ACTIVATION_EIP);
		
		//Initialize List HasAXAAsiaPartyAccount EIP
		List<HasAXAAsiaPartyAccount> hasAXAAsiaPartyAccountList = new ArrayList<HasAXAAsiaPartyAccount>();
		
		//Set HasAXAAsiaPartyAccount 
		hasAXAAsiaPartyAccount.setAccountNO(eskdrBcaModel.getDbAccountNo());
		hasAXAAsiaPartyAccount.setPartyAccountNM(eskdrBcaModel.getCustomerName());
		
		//Add hasAXAAsiaPartyAccount to List HasAXAAsiaPartyAccount
		hasAXAAsiaPartyAccountList.add(hasAXAAsiaPartyAccount);
		
		//Set HasAXAAsiaPolicyPaymentAccount
		hasAXAAsiaPolicyPaymentAccount.setHasAXAAsiaPartyAccount(hasAXAAsiaPartyAccountList);
		
		//Initialize List HasAXAAsiaPolicyPaymentAccount
		List<HasAXAAsiaPolicyPaymentAccount> hasAXAAsiaPolicyPaymentAccountList = new ArrayList<HasAXAAsiaPolicyPaymentAccount>();

		//Add HasAXAAsiaPolicyPaymentAccount to List HasAXAAsiaPolicyPaymentAccount
		hasAXAAsiaPolicyPaymentAccountList.add(hasAXAAsiaPolicyPaymentAccount);
		
		//Initialize List HasPolicyAccount EIP
		List<HasPolicyAccount> hasPolicyAccountList = new ArrayList<HasPolicyAccount>();
		
		//Set HasPolicyAccount
		hasPolicyAccount.setPolicyNO(eskdrBcaDB.getPolicyNumber());
		
		//Add HasPolicyAccount to List HasPolicyAccount
		hasPolicyAccountList.add(hasPolicyAccount);
		
		//Set HasAXAAsiaPolicyPaymentAccountList to HasPolicyAccount
		hasPolicyAccount.setHasAXAAsiaPolicyPaymentAccount(hasAXAAsiaPolicyPaymentAccountList);

		//Set HasPolicyAccount to Customer
		customer.setHasPolicyAccount(hasPolicyAccountList);
		
		//Set Customer to Body
		bodyEip.setCustomer(customer);
		
		String msgReq = request(bodyEip);
		return msgReq;
	}
	
	private Header header() {

		Header header = new Header();
		header.setSecurityContext(security());
		return header;
	}

	private SecurityContext security() {

		SecurityContext securityContext = new SecurityContext();
		securityContext.setUsername(userCustomer);
		securityContext.setPassword(passwordCustomer);
		return securityContext;
	}

	private String request(Body body) {

		Request request = new Request();

		request.setHeader(header());
		request.setBody(body);

		Gson gson = new GsonBuilder().create();
		String msgReq = gson.toJson(request);

		return msgReq;
	}

	private HttpHeaders headers(HttpHeaders headers) {
		headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
		headers.add(HttpHeaders.ACCEPT_CHARSET, StandardCharsets.UTF_8.name());
		headers.add("Content-Type", "application/json");
		return headers;
	}
}
