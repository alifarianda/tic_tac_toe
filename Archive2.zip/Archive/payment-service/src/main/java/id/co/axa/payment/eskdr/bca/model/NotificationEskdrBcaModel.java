package id.co.axa.payment.eskdr.bca.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import id.co.axa.payment.eskdr.bca.identity.PaymentEskdrBcaIdentity;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */

@Entity
@Table(name = "bca_notify")
@JsonInclude
@Component
@IdClass(PaymentEskdrBcaIdentity.class)
public class NotificationEskdrBcaModel implements Serializable {

	private static final long serialVersionUID = -2820403983868276612L;

	@Id
	@Column(name = "request_id", nullable = false, length = 40)
	@JsonProperty("request_id")
	private String requestId;

	@Id
	@Column(name = "policynumber", nullable = false, length = 30)
	@JsonProperty("policyNumber")
	private String policyNumber;

	@Column(name = "customerName", length = 50)
	@JsonProperty("customer_name")
	private String customerName;

	@Column(name = "db_account_no", length = 30)
	@JsonProperty("db_account_no")
	private String dbAccountNo;

	@Column(name = "status")
	@JsonProperty("status")
	private String status;

	@Column(name = "emailAddress")
	@JsonProperty("emailAddress")
	private String emailAddress;

	@Column(name = "created_dt", columnDefinition = "DATETIME")
	@JsonProperty("created_dt")
	private Date createdDt;

	@Column(name = "expired_dt", columnDefinition = "DATETIME")
	@JsonProperty("expired_dt")
	private Date expiredDt;

	@Column(name = "active_dt", columnDefinition = "DATETIME")
	@JsonProperty("active_dt")
	private Date activeDt;

	@Column(name = "failed_dt", columnDefinition = "DATETIME")
	@JsonProperty("failed_dt")
	private Date failedDt;

	@Column(name = "isSendToCore")
	@JsonProperty("isSendToCore")
	private boolean isSendToCore;

	@Column(name = "isEmailed")
	@JsonProperty("isEmailed")
	private boolean isEmailed;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getDbAccountNo() {
		return dbAccountNo;
	}

	public void setDbAccountNo(String dbAccountNo) {
		this.dbAccountNo = dbAccountNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public Date getExpiredDt() {
		return expiredDt;
	}

	public void setExpiredDt(Date expiredDt) {
		this.expiredDt = expiredDt;
	}

	public Date getActiveDt() {
		return activeDt;
	}

	public void setActiveDt(Date activeDt) {
		this.activeDt = activeDt;
	}

	public Date getFailedDt() {
		return failedDt;
	}

	public void setFailedDt(Date failedDt) {
		this.failedDt = failedDt;
	}

	public boolean isSendToCore() {
		return isSendToCore;
	}

	public void setSendToCore(boolean isSendToCore) {
		this.isSendToCore = isSendToCore;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public boolean isEmailed() {
		return isEmailed;
	}

	public void setEmailed(boolean isEmailed) {
		this.isEmailed = isEmailed;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

}
