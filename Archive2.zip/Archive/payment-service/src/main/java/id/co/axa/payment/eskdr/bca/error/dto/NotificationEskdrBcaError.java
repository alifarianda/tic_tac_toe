package id.co.axa.payment.eskdr.bca.error.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @version 1.0
 * @since 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "error_code", "error_message" })
public class NotificationEskdrBcaError {

	private static final String ERROR_INDONESIAN = "Request id tidak ditemukan";
	private static final String ERROR_ENGLISH = "Cannot find request id";

	@JsonProperty("error_code")
	private String errorCode;

	@JsonProperty("error_message")
	private NotificationEskdrBcaErrorMessage errorMessage;

	/**
	 * 
	 */
	public NotificationEskdrBcaError() {

	}

	/**
	 * @param errorCode
	 * @param errorMessage
	 */
	public NotificationEskdrBcaError(String errorCode, NotificationEskdrBcaErrorMessage errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public static NotificationEskdrBcaError response(String errorCode, NotificationEskdrBcaErrorMessage errorMessage) {
		return new NotificationEskdrBcaError(errorCode, errorMessage);
	}

	@JsonProperty("error_code")
	public String getErrorCode() {
		return errorCode;
	}

	@JsonProperty("error_code")
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	@JsonProperty("error_message")
	public NotificationEskdrBcaErrorMessage getErrorMessage() {
		return errorMessage;
	}

	@JsonProperty("error_message")
	public void setErrorMessage(NotificationEskdrBcaErrorMessage errorMessage) {
		this.errorMessage = errorMessage;
	}

	// Set Response for error message
	public static NotificationEskdrBcaErrorMessage responseErrorMessage() {

		NotificationEskdrBcaErrorMessage bcaErrorMessage = new NotificationEskdrBcaErrorMessage();

		bcaErrorMessage.setIndonesian(ERROR_INDONESIAN);
		bcaErrorMessage.setEnglish(ERROR_ENGLISH);

		return bcaErrorMessage;
	}

}
