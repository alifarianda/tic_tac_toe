package id.co.axa.payment.eskdr.bca.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 * @apiNote This model use for request to Notify BCA
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "request_id", "response_ws" })
public class NotificationEskdrBcaDTO {

	@JsonProperty("request_id")
	private String requestId;

	@JsonProperty("response_ws")
	private String responseWs;

	/**
	 * 
	 */
	public NotificationEskdrBcaDTO() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param requestId
	 * @param responseWs
	 */
	public NotificationEskdrBcaDTO(String requestId, String responseWs) {
		this.requestId = requestId;
		this.responseWs = responseWs;
	}

	public static NotificationEskdrBcaDTO response(String requestId, String responseWs) {
		return new NotificationEskdrBcaDTO(requestId, responseWs);
	}

	@JsonProperty("request_id")
	public String getRequestId() {
		return requestId;
	}

	@JsonProperty("request_id")
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	@JsonProperty("response_ws")
	public String getResponseWs() {
		return responseWs;
	}

	@JsonProperty("response_ws")
	public void setResponseWs(String responseWs) {
		this.responseWs = responseWs;
	}
}
