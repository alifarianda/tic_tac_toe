package id.co.axa.payment.eskdr.bca.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import id.co.axa.payment.eskdr.bca.model.NotificationEskdrBcaModel;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.05
 */
@Repository
public interface NotificationBcaRepository extends JpaRepository<NotificationEskdrBcaModel, String> {
	
	NotificationEskdrBcaModel findByPolicyNumber(String policyNumber);
	
	NotificationEskdrBcaModel findByRequestId(String requestId);

	
}
