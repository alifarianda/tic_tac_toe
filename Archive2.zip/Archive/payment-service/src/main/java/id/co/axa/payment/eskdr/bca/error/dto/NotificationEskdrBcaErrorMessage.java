package id.co.axa.payment.eskdr.bca.error.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @version 1.0
 * @since 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "indonesian", "english" })
public class NotificationEskdrBcaErrorMessage {
	
	@JsonProperty("indonesian")
	private String indonesian;
	
	@JsonProperty("english")
	private String english;

	@JsonProperty("indonesian")
	public String getIndonesian() {
		return indonesian;
	}

	@JsonProperty("indonesian")
	public void setIndonesian(String indonesian) {
		this.indonesian = indonesian;
	}

	@JsonProperty("english")
	public String getEnglish() {
		return english;
	}

	@JsonProperty("english")
	public void setEnglish(String english) {
		this.english = english;
	}

}
