/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.request;

import id.co.axa.eip.model.body.Body;
import id.co.axa.eip.model.header.Header;

import org.springframework.stereotype.Component;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@Component("request")
public class Request {

	private Header Header;
	private Body Body;

	/**
	 * 
	 */
	public Request() {

	}

	/**
	 * @param header
	 * @param body
	 */
	public Request(Header header, Body body) {
		Header = header;
		Body = body;
	}

	public Header getHeader() {
		return Header;
	}

	public void setHeader(Header Header) {
		this.Header = Header;
	}

	public Request withHeader(Header Header) {
		this.Header = Header;
		return this;
	}

	public Body getBody() {
		return Body;
	}

	public void setBody(Body Body) {
		this.Body = Body;
	}

	public Request withBody(Body Body) {
		this.Body = Body;
		return this;
	}

}
