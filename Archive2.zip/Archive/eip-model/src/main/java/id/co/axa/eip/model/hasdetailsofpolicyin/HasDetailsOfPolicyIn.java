/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.hasdetailsofpolicyin;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "gdbValue", "dividendAmt", "futurePremiumDpIntTypeCode", "loanRepaymentAmt", "futurePremiumDpAmt",
		"loanIntTypeCd", "dividendTypeCD" })
@Component
public class HasDetailsOfPolicyIn {

	@JsonProperty("gdbValue")
	private String gdbValue;

	@JsonProperty("dividendAmt")
	private String dividendAmt;

	@JsonProperty("futurePremiumDpIntTypeCode")
	private String futurePremiumDpIntTypeCode;

	@JsonProperty("loanRepaymentAmt")
	private String loanRepaymentAmt;

	@JsonProperty("futurePremiumDpAmt")
	private String futurePremiumDpAmt;

	@JsonProperty("loanIntTypeCd")
	private String loanIntTypeCd;

	@JsonProperty("dividendTypeCD")
	private String dividendTypeCD;

	public HasDetailsOfPolicyIn() {

	}

	/**
	 * @param gdbValue
	 * @param dividendAmt
	 * @param futurePremiumDpIntTypeCode
	 * @param loanRepaymentAmt
	 * @param futurePremiumDpAmt
	 * @param loanIntTypeCd
	 * @param dividendTypeCD
	 */
	public HasDetailsOfPolicyIn(String gdbValue, String dividendAmt, String futurePremiumDpIntTypeCode,
			String loanRepaymentAmt, String futurePremiumDpAmt, String loanIntTypeCd, String dividendTypeCD) {
		this.gdbValue = gdbValue;
		this.dividendAmt = dividendAmt;
		this.futurePremiumDpIntTypeCode = futurePremiumDpIntTypeCode;
		this.loanRepaymentAmt = loanRepaymentAmt;
		this.futurePremiumDpAmt = futurePremiumDpAmt;
		this.loanIntTypeCd = loanIntTypeCd;
		this.dividendTypeCD = dividendTypeCD;
	}

	@JsonProperty("gdbValue")
	public String getGdbValue() {
		return gdbValue;
	}

	@JsonProperty("gdbValue")
	public void setGdbValue(String gdbValue) {
		this.gdbValue = gdbValue;
	}

	@JsonProperty("dividendAmt")
	public String getDividendAmt() {
		return dividendAmt;
	}

	@JsonProperty("dividendAmt")
	public void setDividendAmt(String dividendAmt) {
		this.dividendAmt = dividendAmt;
	}

	@JsonProperty("futurePremiumDpIntTypeCode")
	public String getFuturePremiumDpIntTypeCode() {
		return futurePremiumDpIntTypeCode;
	}

	@JsonProperty("futurePremiumDpIntTypeCode")
	public void setFuturePremiumDpIntTypeCode(String futurePremiumDpIntTypeCode) {
		this.futurePremiumDpIntTypeCode = futurePremiumDpIntTypeCode;
	}

	@JsonProperty("loanRepaymentAmt")
	public String getLoanRepaymentAmt() {
		return loanRepaymentAmt;
	}

	@JsonProperty("loanRepaymentAmt")
	public void setLoanRepaymentAmt(String loanRepaymentAmt) {
		this.loanRepaymentAmt = loanRepaymentAmt;
	}

	@JsonProperty("futurePremiumDpAmt")
	public String getFuturePremiumDpAmt() {
		return futurePremiumDpAmt;
	}

	@JsonProperty("futurePremiumDpAmt")
	public void setFuturePremiumDpAmt(String futurePremiumDpAmt) {
		this.futurePremiumDpAmt = futurePremiumDpAmt;
	}

	@JsonProperty("loanIntTypeCd")
	public String getLoanIntTypeCd() {
		return loanIntTypeCd;
	}

	@JsonProperty("loanIntTypeCd")
	public void setLoanIntTypeCd(String loanIntTypeCd) {
		this.loanIntTypeCd = loanIntTypeCd;
	}

	@JsonProperty("dividendTypeCD")
	public String getDividendTypeCD() {
		return dividendTypeCD;
	}

	@JsonProperty("dividendTypeCD")
	public void setDividendTypeCD(String dividendTypeCD) {
		this.dividendTypeCD = dividendTypeCD;
	}
}
