/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.haspersonaldetailsin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.hasaddressesin.HasAddressesIn;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "genderCD", "hasAddressesIn", "lastNM", "middleNM", "firstNM", "birthPlace", "birthDT" })
@Component
public class HasPersonalDetailsIn {

	@JsonProperty("genderCD")
	private String genderCD;

	@JsonProperty("hasAddressesIn")
	private List<HasAddressesIn> hasAddressesIn = null;

	@JsonProperty("lastNM")
	private String lastNM;

	@JsonProperty("middleNM")
	private String middleNM;

	@JsonProperty("firstNM")
	private String firstNM;

	@JsonProperty("birthPlace")
	private String birthPlace;

	@JsonProperty("birthDT")
	private String birthDT;

	public HasPersonalDetailsIn() {

	}

	/**
	 * @param genderCD
	 * @param hasAddressesIn
	 * @param lastNM
	 * @param middleNM
	 * @param firstNM
	 * @param birthPlace
	 * @param birthDT
	 * @param additionalProperties
	 */
	public HasPersonalDetailsIn(String genderCD, List<HasAddressesIn> hasAddressesIn, String lastNM, String middleNM,
			String firstNM, String birthPlace, String birthDT, Map<String, Object> additionalProperties) {
		this.genderCD = genderCD;
		this.hasAddressesIn = hasAddressesIn;
		this.lastNM = lastNM;
		this.middleNM = middleNM;
		this.firstNM = firstNM;
		this.birthPlace = birthPlace;
		this.birthDT = birthDT;
		this.additionalProperties = additionalProperties;
	}

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("genderCD")
	public String getGenderCD() {
		return genderCD;
	}

	@JsonProperty("genderCD")
	public void setGenderCD(String genderCD) {
		this.genderCD = genderCD;
	}

	@JsonProperty("hasAddressesIn")
	public List<HasAddressesIn> getHasAddressesIn() {
		return hasAddressesIn;
	}

	@JsonProperty("hasAddressesIn")
	public void setHasAddressesIn(List<HasAddressesIn> hasAddressesIn) {
		this.hasAddressesIn = hasAddressesIn;
	}

	@JsonProperty("lastNM")
	public String getLastNM() {
		return lastNM;
	}

	@JsonProperty("lastNM")
	public void setLastNM(String lastNM) {
		this.lastNM = lastNM;
	}

	@JsonProperty("middleNM")
	public String getMiddleNM() {
		return middleNM;
	}

	@JsonProperty("middleNM")
	public void setMiddleNM(String middleNM) {
		this.middleNM = middleNM;
	}

	@JsonProperty("firstNM")
	public String getFirstNM() {
		return firstNM;
	}

	@JsonProperty("firstNM")
	public void setFirstNM(String firstNM) {
		this.firstNM = firstNM;
	}

	@JsonProperty("birthPlace")
	public String getBirthPlace() {
		return birthPlace;
	}

	@JsonProperty("birthPlace")
	public void setBirthPlace(String birthPlace) {
		this.birthPlace = birthPlace;
	}

	@JsonProperty("birthDT")
	public String getBirthDT() {
		return birthDT;
	}

	@JsonProperty("birthDT")
	public void setBirthDT(String birthDT) {
		this.birthDT = birthDT;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
