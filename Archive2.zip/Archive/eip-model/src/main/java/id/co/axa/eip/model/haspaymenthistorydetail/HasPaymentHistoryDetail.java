/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.haspaymenthistorydetail;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.hasnamevalue.HasNameValue;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "redirect_url", "statusCode", "hasNameValue", "transactionTime", "paymentRefID", "paymentType",
		"bank", "approvalCode", "maskedCard", "transactionStatus", "fraudStatus", "statusMessage" })
@Component
public class HasPaymentHistoryDetail {

	@JsonProperty("redirect_url")
	private String redirect_url;

	@JsonProperty("statusCode")
	private String statusCode;

	@JsonProperty("hasNameValue")
	private List<HasNameValue> hasNameValue = null;

	@JsonProperty("transactionTime")
	private String transactionTime;

	@JsonProperty("paymentRefID")
	private String paymentRefID;

	@JsonProperty("paymentType")
	private String paymentType;

	@JsonProperty("bank")
	private String bank;

	@JsonProperty("maskedCard")
	private String maskedCard;

	@JsonProperty("fraudStatus")
	private String fraudStatus;

	@JsonProperty("approvalCode")
	private String approvalCode;

	@JsonProperty("transactionStatus")
	private String transactionStatus;

	@JsonProperty("statusMessage")
	private String statusMessage;

	/**
	 * 
	 */
	public HasPaymentHistoryDetail() {

	}

	/**
	 * @param redirectUrl
	 * @param statusCode
	 * @param hasNameValue
	 * @param transactionTime
	 * @param paymentRefID
	 * @param paymentType
	 * @param bank
	 * @param maskedCard
	 * @param fraudStatus
	 * @param approvalCode
	 * @param transactionStatus
	 * @param statusMessage
	 */
	public HasPaymentHistoryDetail(String redirect_url, String statusCode, List<HasNameValue> hasNameValue,
			String transactionTime, String paymentRefID, String paymentType, String bank, String maskedCard,
			String fraudStatus, String approvalCode, String transactionStatus, String statusMessage) {
		this.redirect_url = redirect_url;
		this.statusCode = statusCode;
		this.hasNameValue = hasNameValue;
		this.transactionTime = transactionTime;
		this.paymentRefID = paymentRefID;
		this.paymentType = paymentType;
		this.bank = bank;
		this.maskedCard = maskedCard;
		this.fraudStatus = fraudStatus;
		this.approvalCode = approvalCode;
		this.transactionStatus = transactionStatus;
		this.statusMessage = statusMessage;
	}

	@JsonProperty("redirect_url")
	public String getRedirect_Url() {
		return redirect_url;
	}

	@JsonProperty("redirect_url")
	public void setRedirect_Url(String redirect_url) {
		this.redirect_url = redirect_url;
	}

	@JsonProperty("statusCode")
	public String getStatusCode() {
		return statusCode;
	}

	@JsonProperty("statusCode")
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	@JsonProperty("hasNameValue")
	public List<HasNameValue> getHasNameValue() {
		return hasNameValue;
	}

	@JsonProperty("hasNameValue")
	public void setHasNameValue(List<HasNameValue> hasNameValue) {
		this.hasNameValue = hasNameValue;
	}

	@JsonProperty("transactionTime")
	public String getTransactionTime() {
		return transactionTime;
	}

	@JsonProperty("transactionTime")
	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	@JsonProperty("paymentRefID")
	public String getPaymentRefID() {
		return paymentRefID;
	}

	@JsonProperty("paymentRefID")
	public void setPaymentRefID(String paymentRefID) {
		this.paymentRefID = paymentRefID;
	}

	@JsonProperty("paymentType")
	public String getPaymentType() {
		return paymentType;
	}

	@JsonProperty("paymentType")
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	@JsonProperty("approvalCode")
	public String getApprovalCode() {
		return approvalCode;
	}

	@JsonProperty("approvalCode")
	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}

	@JsonProperty("transactionStatus")
	public String getTransactionStatus() {
		return transactionStatus;
	}

	@JsonProperty("transactionStatus")
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	@JsonProperty("statusMessage")
	public String getStatusMessage() {
		return statusMessage;
	}

	@JsonProperty("statusMessage")
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	@JsonProperty("bank")
	public String getBank() {
		return bank;
	}

	@JsonProperty("bank")
	public void setBank(String bank) {
		this.bank = bank;
	}

	@JsonProperty("maskedCard")
	public String getMaskedCard() {
		return maskedCard;
	}

	@JsonProperty("maskedCard")
	public void setMaskedCard(String maskedCard) {
		this.maskedCard = maskedCard;
	}

	@JsonProperty("fraudStatus")
	public String getFraudStatus() {
		return fraudStatus;
	}

	@JsonProperty("fraudStatus")
	public void setFraudStatus(String fraudStatus) {
		this.fraudStatus = fraudStatus;
	}
}