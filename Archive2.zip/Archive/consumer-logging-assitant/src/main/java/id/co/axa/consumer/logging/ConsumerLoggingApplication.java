package id.co.axa.consumer.logging;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EntityScan({"id.co.axa.consumer.logging","id.co.axa.commons.core"})
@ComponentScan(basePackages = {"id.co.axa.consumer.logging","id.co.axa.commons.core"})
public class ConsumerLoggingApplication {
	
	public static void main(String[] args) {
		 SpringApplication.run(ConsumerLoggingApplication.class, args);
	}
}
