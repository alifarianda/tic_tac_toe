package id.co.axa.consumer.logging.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "COMMONS_LOGGING")
public class LogAssistantModel {

	@Id
	@Column(name = "txnlogid", nullable = false)
	@JsonProperty("txnLogID")
	private String txnLogId;

	@Column(name = "requestid")
	@JsonProperty("requestID")
	private String requestID;

	@Column(name = "clientid")
	@JsonProperty("clientID")
	private String clientID;

	@Column(name = "contenttype")
	@JsonProperty("contentType")
	private String contentType;

	@Column(name = "method")
	@JsonProperty("method")
	private String method;

	@Column(name = "urlpath")
	@JsonProperty("urlPath")
	private String urlPath;

	@Column(name = "httpstatuscd")
	@JsonProperty("httpStatus_CD")
	private String httpStatus_CD;

	@Lob
	@Column(name = "payloadrq", length = 200000)
	@JsonProperty("payloadRq")
	private String payloadRq;

	@Lob
	@Column(name = "payloadrs", length = 200000)
	@JsonProperty("payloadRs")
	private String payloadRs;

	@Column(name = "processingtime")
	@JsonProperty("processingTime")
	private long processingTime;

	@Column(name = "hostname")
	@JsonProperty("hostname")
	private String hostname;

	@Column(name = "trxrqdt")
	@JsonProperty("trxRqDT")
	private Date trxRqDT;

	@Column(name = "trxrsdt")
	@JsonProperty("trxRsDT")
	private Date trxRsDT;

	@JsonProperty("requestID")
	public String getRequestID() {
		return requestID;
	}

	@JsonProperty("requestID")
	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	@JsonProperty("clientID")
	public String getClientID() {
		return clientID;
	}

	@JsonProperty("clientID")
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	@JsonProperty("contentType")
	public String getContentType() {
		return contentType;
	}

	@JsonProperty("contentType")
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	@JsonProperty("method")
	public String getMethod() {
		return method;
	}

	@JsonProperty("method")
	public void setMethod(String method) {
		this.method = method;
	}

	@JsonProperty("urlPath")
	public String getUrlPath() {
		return urlPath;
	}

	@JsonProperty("urlPath")
	public void setUrlPath(String urlPath) {
		this.urlPath = urlPath;
	}

	public String getHttpStatus_CD() {
		return httpStatus_CD;
	}

	public void setHttpStatus_CD(String httpStatus_CD) {
		this.httpStatus_CD = httpStatus_CD;
	}

	public Object getPayloadRq() {
		return payloadRq;
	}

	public String getPayloadRs() {
		return payloadRs;
	}

	public void setPayloadRs(String payloadRs) {
		this.payloadRs = payloadRs;
	}

	public void setPayloadRq(String payloadRq) {
		this.payloadRq = payloadRq;
	}

	public String getTxnLogId() {
		return txnLogId;
	}

	public void setTxnLogId(String txnLogId) {
		this.txnLogId = txnLogId;
	}

	public long getProcessingTime() {
		return processingTime;
	}

	public void setProcessingTime(long processingTime) {
		this.processingTime = processingTime;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public Date getTrxRqDT() {
		return trxRqDT;
	}

	public void setTrxRqDT(Date trxRqDT) {
		this.trxRqDT = trxRqDT;
	}

	public Date getTrxRsDT() {
		return trxRsDT;
	}

	public void setTrxRsDT(Date trxRsDT) {
		this.trxRsDT = trxRsDT;
	}
}