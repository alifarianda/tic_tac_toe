package id.co.axa.consumer.logging.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import id.co.axa.consumer.logging.model.LogAssistantModel;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@Repository
public interface ConsumerRepository extends JpaRepository<LogAssistantModel, String> {
	
}
