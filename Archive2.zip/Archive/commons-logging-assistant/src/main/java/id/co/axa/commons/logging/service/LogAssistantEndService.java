package id.co.axa.commons.logging.service;

import id.co.axa.commons.logging.model.LogAssistantModel;
import id.co.axa.commons.logging.response.ResponseLogging;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */

public interface LogAssistantEndService {

	ResponseLogging loggingEnd(LogAssistantModel logAssistantModel, Object object);
}
