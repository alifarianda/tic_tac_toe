package id.co.axa.commons.logging.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "data", "header" })
public class ResponseLogging {

	/**
	 * 
	 */
	public ResponseLogging() {

	}

	@JsonProperty("data")
	private Object objectData;

	@JsonProperty("header")
	private Object objectHeader;

	/**
	 * @param data
	 * @param header
	 */
	public ResponseLogging(Object objectData, Object objectHeader) {
		this.objectData = objectData;
		this.objectHeader = objectHeader;
	}

	public Object getObjectData() {
		return objectData;
	}

	public void setObjectData(Object objectData) {
		this.objectData = objectData;
	}

	public Object getObjectHeader() {
		return objectHeader;
	}

	public void setObjectHeader(Object objectHeader) {
		this.objectHeader = objectHeader;
	}

}
