package id.co.axa.commons.logging.serviceimpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import id.co.axa.commons.logging.kafka.configuration.ProducerService;
import id.co.axa.commons.logging.model.LogAssistantModel;
import id.co.axa.commons.logging.response.ResponseLogging;
import id.co.axa.commons.logging.service.LogAssistantEndService;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */

@Service
public class LogAssistantEndServiceImpl implements LogAssistantEndService {

	public static String DATE_PATTERN_TRX = "yyyy-MM-dd HH:mm:ss.SSS";
	protected static String LOG_TXN_LOG_ID = "txnLogID";
	protected static String LOG_TRX_RS_DT = "trxRsDT";
	protected static String LOG_TRX_RQ_DT = "trxRqDT";
	protected static String LOG_PROCESSING_TIME = "processingTime";
	protected static String LOG_PAYLOAD_RS = "payloadRs";
	protected static String LOG_KEY = "logkey";
	protected static String LOG_HTTP_STATUS = "httpStatus_CD";

	protected static String RESP_HEADER = "header";
	protected static String RESP_DATA = "data";

	@Autowired
	private KafkaTemplate<String, Object> kafkaTemplate;

	@Override
	public ResponseLogging loggingEnd(LogAssistantModel logAssistantModel, Object obj) {
		// TODO Auto-generated method stub
		ResponseLogging objResp = constructLoggingEndObject(logAssistantModel, obj);
		return objResp;
	}

//	@Override
//	public ResponseLogging loggingEnd(LogAssistantModel logAssistantModel, JSONObject object) {
//		// TODO Auto-generated method stub
//		ResponseLogging objResp = constructLoggingEndJSONObject(logAssistantModel,object);
//		return objResp;
//	}

	private ResponseLogging constructLoggingEndObject(LogAssistantModel logAssistantModel, Object obj) {

		// Construct and Collect Logging End
		Map<String, Object> generateLogEnd = logAssistantModel.getListObject();

		// Construct For Response to Agent
		Map<String, Object> sendResp = new HashMap<>();

		// Construct Header for response to agent
		Map<String, Object> header = new HashMap<>();

		SimpleDateFormat sdf = new SimpleDateFormat(DATE_PATTERN_TRX);
		long trxDateRq;
		long trxDateResp;
		String setTrxDateResp;

		try {

			setTrxDateResp = sdf.format(Calendar.getInstance().getTime());

			// Get time for response
			trxDateResp = sdf.parse(setTrxDateResp).getTime();

			// Put time for transaction response to LogEnd
			generateLogEnd.put(LOG_TRX_RS_DT, setTrxDateResp);

			// Get request time
			trxDateRq = sdf.parse(generateLogEnd.get(LOG_TRX_RQ_DT).toString()).getTime();

			// Put processing time for transaction response - request to LogEnd and agent
			generateLogEnd.put(LOG_PROCESSING_TIME, trxDateResp - trxDateRq);

			ObjectMapper mapper = new ObjectMapper();

			// Convert object to string JSON Response
			String jsonResp = mapper.writeValueAsString(obj);

			// Convert string JSON response to JSONObject Class
			JSONObject convertedObject = new Gson().fromJson(jsonResp, JSONObject.class);

			// Put Payload Response to LogEnd
			generateLogEnd.put(LOG_PAYLOAD_RS, convertedObject);

			// Put HTTP Status Code
			generateLogEnd.put(LOG_HTTP_STATUS, logAssistantModel.getHttpStatusCD());

			// Set Object Response To Messaging
			JSONObject sendLogEnd = new JSONObject(generateLogEnd);
			
			//Send Message To Kafka MessageBroker
			ProducerService kafkaProducer = new ProducerService(kafkaTemplate);
			kafkaProducer.sendMessage(sendLogEnd);

			// Put Header for response
			header.put(LOG_TXN_LOG_ID, generateLogEnd.get(LOG_TXN_LOG_ID));
			header.put(LOG_PROCESSING_TIME, generateLogEnd.get(LOG_PROCESSING_TIME));

			// Construct response to agent
			sendResp.put(RESP_HEADER, header);
			sendResp.put(RESP_DATA, generateLogEnd.get(LOG_PAYLOAD_RS));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Set construct response to JSON for agent
		JSONObject constructResponse = new JSONObject(sendResp);

		ResponseLogging responseLogging = new ResponseLogging();
		responseLogging.setObjectData(constructResponse.get(RESP_DATA));
		responseLogging.setObjectHeader(constructResponse.get(RESP_HEADER));
		return responseLogging;
	}
}
