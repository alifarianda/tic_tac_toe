package id.co.axa.middleware.model.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.body.Body;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"Body"
})
public class Data {

	@JsonProperty("Body")
	private Body body;
	
	@JsonProperty("Body")
	public Body getBody() {
		return body;
	}
	
	@JsonProperty("Body")
	public void setBody(Body body) {
		this.body = body;
	}
}
