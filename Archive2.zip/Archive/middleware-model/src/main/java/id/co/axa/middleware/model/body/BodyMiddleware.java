package id.co.axa.middleware.model.body;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.middleware.model.customer.CustomerMiddleware;
import id.co.axa.middleware.model.item.ItemMiddleware;
import id.co.axa.middleware.model.paymentdetails.PaymentDetailsMiddleware;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "trxRefference", "grossAmount", "customer", "paymentType", "paymentDetails", "order_id", "items",
		"currencyCd", "custom_field1", "custom_field2", "custom_field3" })
public class BodyMiddleware {

	@NotNull
	@JsonProperty("trxRefference")
	private String trxRefference;

	@NotNull
	@JsonProperty("grossAmount")
	private String grossAmount;

	@JsonProperty("customer")
	private CustomerMiddleware customer;

	@JsonProperty("items")
	private List<ItemMiddleware> items = null;

	@NotNull
	@JsonProperty("paymentType")
	private String paymentType;

	@NotNull
	@JsonProperty("paymentDetails")
	private PaymentDetailsMiddleware paymentDetails;

	@JsonProperty("order_id")
	private String orderId;

	@JsonProperty("currencyCd")
	private String currencyCd;

	@JsonProperty("custom_field1")
	private String customField1;

	@JsonProperty("custom_field2")
	private String customField2;

	@JsonProperty("custom_field3")
	private String customField3;

	@JsonProperty("internalizedToken")
	private String internalizedToken;

	@JsonProperty("Message")
	private String message;

	private String status;

	@JsonProperty("data")
	private Object objectData;

	@JsonProperty("header")
	private Object objectHeader;

	/**
	 * 
	 */
	public BodyMiddleware() {

	}

	/**
	 * 
	 */
	public BodyMiddleware(String status) {
		this.status = status;
	}

	/**
	 * @param jsonObject
	 */
	public BodyMiddleware(Object objectData, Object objectHeader) {
		this.objectData = objectData;
		this.objectHeader = objectHeader;
	}

	public static BodyMiddleware status(String status) {
		return new BodyMiddleware(status);
	}

	public static BodyMiddleware response(Object objectData, Object objectHeader) {
		return new BodyMiddleware(objectData, objectHeader);
	}

	@JsonProperty("trxRefference")
	public String getTrxRefference() {
		return trxRefference;
	}

	@JsonProperty("trxRefference")
	public void setTrxRefference(String trxRefference) {
		this.trxRefference = trxRefference;
	}

	@JsonProperty("grossAmount")
	public String getGrossAmount() {
		return grossAmount;
	}

	@JsonProperty("grossAmount")
	public void setGrossAmount(String grossAmount) {
		this.grossAmount = grossAmount;
	}

	@JsonProperty("customer")
	public CustomerMiddleware getCustomer() {
		return customer;
	}

	@JsonProperty("customer")
	public void setCustomer(CustomerMiddleware customer) {
		this.customer = customer;
	}

	@JsonProperty("items")
	public List<ItemMiddleware> getItems() {
		return items;
	}

	@JsonProperty("items")
	public void setItems(List<ItemMiddleware> items) {
		this.items = items;
	}

	@JsonProperty("paymentType")
	public String getPaymentType() {
		return paymentType;
	}

	@JsonProperty("paymentType")
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	@JsonProperty("paymentDetails")
	public PaymentDetailsMiddleware getPaymentDetails() {
		return paymentDetails;
	}

	@JsonProperty("paymentDetails")
	public void setPaymentDetails(PaymentDetailsMiddleware paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	@JsonProperty("order_id")
	public String getOrderId() {
		return orderId;
	}

	@JsonProperty("order_id")
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	@JsonProperty("currencyCd")
	public String getCurrencyCd() {
		return currencyCd;
	}

	@JsonProperty("currencyCd")
	public void setCurrencyCd(String currencyCd) {
		this.currencyCd = currencyCd;
	}

	@JsonProperty("custom_field1")
	public String getCustomField1() {
		return customField1;
	}

	@JsonProperty("custom_field1")
	public void setCustomField1(String customField1) {
		this.customField1 = customField1;
	}

	@JsonProperty("custom_field2")
	public String getCustomField2() {
		return customField2;
	}

	@JsonProperty("custom_field2")
	public void setCustomField2(String customField2) {
		this.customField2 = customField2;
	}

	@JsonProperty("custom_field3")
	public String getCustomField3() {
		return customField3;
	}

	@JsonProperty("custom_field3")
	public void setCustomField3(String customField3) {
		this.customField3 = customField3;
	}

	public String getInternalizedToken() {
		return internalizedToken;
	}

	public void setInternalizedToken(String internalizedToken) {
		this.internalizedToken = internalizedToken;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getObjectData() {
		return objectData;
	}

	public void setObjectData(Object objectData) {
		this.objectData = objectData;
	}

	public Object getObjectHeader() {
		return objectHeader;
	}

	public void setObjectHeader(Object objectHeader) {
		this.objectHeader = objectHeader;
	}
}
