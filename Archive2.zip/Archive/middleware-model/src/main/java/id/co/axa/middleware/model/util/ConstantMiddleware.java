package id.co.axa.middleware.model.util;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public class ConstantMiddleware {

	// Service EIP
	public static final String SERVICE = "getToken";
	public static final String DO_ORDER_STATUS_SERVICE = "doOrder";
	public static final String NOTIFY_SERVICE = "receive";
	public static final String POLICY_DETAILS_SERVICE = "getPolicyDetails";
	public static final String DMTM_AFI_SERVICE = "DMTM";
	public static final String SERVICE_MESSAGING_EIP = "sendCommunicationMessage";
	public static final String SERVICE_COLLECTION_ACTIVATION_EIP = "modifyPolicyDetails";

	// Operation EIP
	public static final String VSNAPTOKEN_OPERATION = "VSNAPTOKEN";
	public static final String DO_ORDER_STATUS_OPERATION = "status";
	public static final String DO_ORDER_CANCEL_OPERATION = "cancel";
	public static final String NOTIFY_OPERATION = "notify";
	public static final String APPLICATION_DETAIL_OPERATION = "application DETAIL";
	public static final String POLICY_DETAILS_OPERATION = "policy DETAILS";
	public static final String REG_DETAILS_OPERATION = "getRegPolicyNo";
	public static final String OPERATION_SMS_EIP = "Basic";
	public static final String OPERATION_SHORTEN_URL_EIP = "createNewUrl";
	public static final String OPERATION_REGISTRASI_BCA = "accountAuthorizationRegistration";
	public static final String COLLECTION_ACTIVATION_OPERATION = "collectionActivation";


	// Element for schema request and response
	public static final String SECURE = "secure";
	public static final String FINISH = "finish";
	public static final String CHANNEL = "channel";
	public static final String SAVE_CARD = "save_card";
	public static final String CUSTOM_FIELD1 = "custom_field1";
	public static final String CUSTOM_FIELD2 = "custom_field2";
	public static final String CUSTOM_FIELD3 = "custom_field3";
	public static final String HTTP_NOT_FOUND = "404";
	public static final String SIGNATURE_KEY = "signature_key";
	public static final String CHANNEL_RESPONSE_MESSAGE = "channel_response_message";
	public static final String CHANNEL_RESPONSE_CODE = "channel_response_code";
	public static final String SAVED_TOKEN_ID_EXPIRED_AT = "saved_token_id_expired_at";
	public static final String SAVED_TOKEN_ID = "saved_token_id";

	public static final String UNAUTHORIZED = "You are not authorized for this service";

	// Set Variable for Notify Service TokenApps and Register to BCA
	public static final String TASK_ID = "credit_card";
	public static final String TASK_ID_BCA = "bca_debit";
	public static final String APP_ID_NOTIFY = "PRE";
	public static final String STATUS_NOTIFY = "1";
	public static final String STATUS_SUCCESS = "success";
	public static final String STATUS_CODE = "status_code";
	public static final String STATUS_CODE_VALUE = "200";
	public static final String FRAUD_STATUS = "fraud_status";
	public static final String FRAUD_STATUS_VALUE = "accept";
	public static final String TRANSACTION_TIME = "transaction_time";
	public static final String ECI_NOTIFY = "eci";
	public static final String ECI_NOTIFY_VALUE = "05";
	public static final String STATUS_MESSAGE = "status_message";
	public static final String ORDER_ID = "order_id";
	public static final String CHANNEL_RESPONSE_MESSAGE_VALUE = "Approved";
	public static final String TRANSACTION_ID = "transaction_id";
	public static final String CURRENCY = "currency";
	public static final String APPROVAL_CODE = "approval_code";
	public static final String GROSS_AMOUNT = "gross_amount";
	public static final String TRANSACTION_STATUS = "transaction_status";
	public static final String TRANSACTION_STATUS_VALUE = "cancel";
	public static final String MASKED_CARD = "masked_card";
	public static final String CARD_TYPE = "card_type";
	public static final String BANK = "bank";
	public static final String PAYMENT_TYPE = "payment_type";
	public static final String APP_ID_REG_BCA = "BCA";

	public static final String DMTM_SOURCE = "DMTM_API";
	public static final String KEY_STORE_AFIPAY = "AFIPAY.jks";
	public static final String KEY_STORE_AFIPAY_PASSWORD = "afipay123";

	public static final String APP_ID_SMS_EIP = "Mobile";
	public static final String APP_ID_SHORTEN_URL_EIP = "T2MIO";

	public static final String SENDER_AMFS = "AXA_MANDIRI";
	public static final String SENDER_AFI = "AXA_FIN_IND";

	public static final String BATCH_NAME = "batch name";
	public static final String TRIGGERED_BY = "upload/executed by";
	public static final String CHANNEL_ID = "1";

	public static final String DELIVERY_URL_SHORTEN_URL_EIP = "310";
	public static final String RLS_TYPE = "RLS";
	public static final String DMTM_TYPE = "DMTM";
}
