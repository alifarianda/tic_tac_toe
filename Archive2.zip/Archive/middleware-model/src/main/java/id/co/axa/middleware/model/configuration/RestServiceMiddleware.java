package id.co.axa.middleware.model.configuration;


import java.nio.charset.StandardCharsets;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import id.co.axa.commons.core.exception.ApplicationException;
import id.co.axa.commons.core.payload.Status;
import id.co.axa.middleware.model.response.ResponseMiddleware;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */

public class RestServiceMiddleware {
	
	public  ResponseMiddleware sendReq (Object object,String url) {
		ResponseMiddleware response = new ResponseMiddleware();
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
			headers.add(HttpHeaders.ACCEPT_CHARSET, StandardCharsets.UTF_8.name());
		    HttpEntity<Object> entity = new HttpEntity<>(object,headers);
		    response = restTemplate.postForObject(url, entity, ResponseMiddleware.class);
		} catch(Exception e) {
            throw new ApplicationException(Status.ERROR_CODE, Status.ERROR_DESC, e.getLocalizedMessage());
		}
	    return response;
	    
	}

}
