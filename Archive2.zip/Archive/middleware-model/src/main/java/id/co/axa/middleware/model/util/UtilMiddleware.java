package id.co.axa.middleware.model.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public class UtilMiddleware {
	
		//Generate Unique Random for req to EIP PolicyManagement
		public String uniqueRandom(String uniqueIdentifier){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
			StringBuilder addRandomNum = new StringBuilder();
			Date date = new Date();
			String formatTrxid = sdf.format(date);
			addRandomNum.append(uniqueIdentifier);
			addRandomNum.append("-");
			addRandomNum.append(formatTrxid);
			return addRandomNum.toString();
		}
}
