package id.co.axa.middleware.model.tokenapps;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.middleware.model.internalizetokenresponse.InternalizeTokenResponse;
import id.co.axa.middleware.model.returntokenapps.Return;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "internalizeTokenResponse", "return" })
public class ResponseTokenApps {

	@JsonProperty("internalizeTokenResponse")
	private InternalizeTokenResponse internalizeTokenResponse;

	@JsonProperty("return")
	private Return _return;

	@JsonProperty("internalizeTokenResponse")
	public InternalizeTokenResponse getInternalizeTokenResponse() {
		return internalizeTokenResponse;
	}

	@JsonProperty("internalizeTokenResponse")
	public void setInternalizeTokenResponse(InternalizeTokenResponse internalizeTokenResponse) {
		this.internalizeTokenResponse = internalizeTokenResponse;
	}

	@JsonProperty("return")
	public Return getReturn() {
		return _return;
	}

	@JsonProperty("return")
	public void setReturn(Return _return) {
		this._return = _return;
	}

}
