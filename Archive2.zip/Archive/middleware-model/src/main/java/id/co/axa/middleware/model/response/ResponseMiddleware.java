package id.co.axa.middleware.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.middleware.model.data.Data;
import id.co.axa.middleware.model.header.Header;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "data", "header" })
public class ResponseMiddleware {

	/**
	 * 
	 */
	public ResponseMiddleware() {

	}

	@JsonProperty("data")
	private Data data;

	@JsonProperty("header")
	private Header header;

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

}
