package id.co.axa.middleware.model.header;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"txnLogID",
"processingTime"
})
public class Header {

	@JsonProperty("txnLogID")
	private String txnLogID;
	
	@JsonProperty("processingTime")
	private Integer processingTime;
	
	@JsonProperty("txnLogID")
	public String getTxnLogID() {
		return txnLogID;
	}
	
	@JsonProperty("txnLogID")
	public void setTxnLogID(String txnLogID) {
		this.txnLogID = txnLogID;
	}
	
	@JsonProperty("processingTime")
	public Integer getProcessingTime() {
		return processingTime;
	}
	
	@JsonProperty("processingTime")
	public void setProcessingTime(Integer processingTime) {
		this.processingTime = processingTime;
	}
}
