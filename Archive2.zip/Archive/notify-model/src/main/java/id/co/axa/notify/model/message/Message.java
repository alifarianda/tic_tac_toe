package id.co.axa.notify.model.message;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.notify.model.attachment.Attachment;
import id.co.axa.notify.model.from.From;
import id.co.axa.notify.model.recipient.Recipient;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "messageType", "scheduledTime", "transportType", "subject", "from", "recipient", "body",
		"attachment" })
public class Message {

	@JsonProperty("messageType")
	private String messageType;

	@JsonProperty("transportType")
	private String transportType;

	@JsonProperty("scheduledTime")
	private String scheduledTime;

	@JsonProperty("subject")
	private String subject;

	@JsonProperty("from")
	private From from;

	@JsonProperty("recipient")
	private Recipient recipient;

	@JsonProperty("body")
	private String body;

	@JsonProperty("attachment")
	private List<Attachment> attachment = null;

	public Message() {

	}

	/**
	 * @param messageType
	 * @param transportType
	 * @param scheduledTime
	 * @param subject
	 * @param from
	 * @param recipient
	 * @param body
	 * @param attachment
	 */
	public Message(String messageType, String transportType, String scheduledTime, String subject, From from,
			Recipient recipient, String body, List<Attachment> attachment) {
		this.messageType = messageType;
		this.transportType = transportType;
		this.scheduledTime = scheduledTime;
		this.subject = subject;
		this.from = from;
		this.recipient = recipient;
		this.body = body;
		this.attachment = attachment;
	}

	@JsonProperty("messageType")
	public String getMessageType() {
		return messageType;
	}

	@JsonProperty("messageType")
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	@JsonProperty("transportType")
	public String getTransportType() {
		return transportType;
	}

	@JsonProperty("transportType")
	public void setTransportType(String transportType) {
		this.transportType = transportType;
	}

	@JsonProperty("from")
	public From getFrom() {
		return from;
	}

	@JsonProperty("from")
	public void setFrom(From from) {
		this.from = from;
	}

	@JsonProperty("recipient")
	public Recipient getRecipient() {
		return recipient;
	}

	@JsonProperty("recipient")
	public void setRecipient(Recipient recipient) {
		this.recipient = recipient;
	}

	@JsonProperty("body")
	public String getBody() {
		return body;
	}

	@JsonProperty("body")
	public void setBody(String body) {
		this.body = body;
	}

	@JsonProperty("attachment")
	public List<Attachment> getAttachment() {
		return attachment;
	}

	@JsonProperty("attachment")
	public void setAttachment(List<Attachment> attachment) {
		this.attachment = attachment;
	}

	@JsonProperty("subject")
	public String getSubject() {
		return subject;
	}

	@JsonProperty("subject")
	public void setSubject(String subject) {
		this.subject = subject;
	}

	@JsonProperty("scheduledTime")
	public String getScheduledTime() {
		return scheduledTime;
	}

	@JsonProperty("scheduledTime")
	public void setScheduledTime(String scheduledTime) {
		this.scheduledTime = scheduledTime;
	}

}