package id.co.axa.notify.model.recipient;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.notify.model.bcc.Bcc;
import id.co.axa.notify.model.cc.Cc;
import id.co.axa.notify.model.to.To;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "to", "cc", "bcc" })
public class Recipient {

	@JsonProperty("to")
	private List<To> to = null;

	@JsonProperty("cc")
	private List<Cc> cc = null;

	@JsonProperty("bcc")
	private List<Bcc> bcc = null;

	/**
	 * 
	 */
	public Recipient() {

	}

	/**
	 * @param to
	 * @param cc
	 * @param bcc
	 */
	public Recipient(List<To> to, List<Cc> cc, List<Bcc> bcc) {

		this.to = to;
		this.cc = cc;
		this.bcc = bcc;
	}

	@JsonProperty("to")
	public List<To> getTo() {
		return to;
	}

	@JsonProperty("to")
	public void setTo(List<To> to) {
		this.to = to;
	}

	@JsonProperty("cc")
	public List<Cc> getCc() {
		return cc;
	}

	@JsonProperty("cc")
	public void setCc(List<Cc> cc) {
		this.cc = cc;
	}

	@JsonProperty("bcc")
	public List<Bcc> getBcc() {
		return bcc;
	}

	@JsonProperty("bcc")
	public void setBcc(List<Bcc> bcc) {
		this.bcc = bcc;
	}
}
