package id.co.axa.notify.model.attachment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "fileName", "contentType" })
public class Attachment {

	@JsonProperty("fileName")
	private String fileName;

	@JsonProperty("contentType")
	private String contentType;

	/**
	 * 
	 */
	public Attachment() {

	}

	/**
	 * @param fileName
	 * @param contentType
	 */
	public Attachment(String fileName, String contentType) {
		this.fileName = fileName;
		this.contentType = contentType;
	}

	@JsonProperty("fileName")
	public String getFileName() {
		return fileName;
	}

	@JsonProperty("fileName")
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@JsonProperty("contentType")
	public String getContentType() {
		return contentType;
	}

	@JsonProperty("contentType")
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
}
