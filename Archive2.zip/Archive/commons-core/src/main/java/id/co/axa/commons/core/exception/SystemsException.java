package id.co.axa.commons.core.exception;

import id.co.axa.commons.core.payload.Status;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public class SystemsException extends BaseException {

	private static final long serialVersionUID = 8466729017575594336L;

	public SystemsException() {
		this.type = "SYSTEMS ERROR";
	}

	public SystemsException(String message) {
		super(message);
		this.type = "SYSTEMS ERROR";
	}

	public SystemsException(String message, Throwable cause) {
		super(message, cause);
		this.type = "SYSTEMS ERROR";
	}

	public SystemsException(Throwable cause) {
		super(cause);
		this.type = "SYSTEMS ERROR";
	}

	public SystemsException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		this.type = "SYSTEMS ERROR";
	}

	public SystemsException(String key, String moduleName, String parameter) {
		super(String.format("%s not found with %s : '%s'", key, moduleName, parameter));
		this.key = key;
		this.moduleName = moduleName;
		this.parameter = parameter;
		this.type = "SYSTEMS ERROR";
	}

	public SystemsException(Status status) {
		super(status.getResponsemessage());
		this.status = status;
		this.type = "SYSTEMS ERROR";
	}

}
