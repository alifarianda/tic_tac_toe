package id.co.axa.commons.core.model;

import id.co.axa.commons.core.base.BaseInterface;

public interface Model extends BaseInterface {

}
