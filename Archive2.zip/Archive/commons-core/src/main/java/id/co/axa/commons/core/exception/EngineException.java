/**
 * 
 */
package id.co.axa.commons.core.exception;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */
public class EngineException extends BaseException {

	private static final long serialVersionUID = -8638612623997005088L;

	public EngineException() {
		this.type = "ENGINE ERROR";
	}

}
