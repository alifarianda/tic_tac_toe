package id.co.axa.commons.core.utils;

import java.util.Random;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public class PasswordGenerator {

	public static String alphaNumericString(int len) {
	    String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	    Random rnd = new Random();

	    StringBuilder sb = new StringBuilder(len);
	    for (int i = 0; i < len; i++) {
	        sb.append(AB.charAt(rnd.nextInt(AB.length())));
	    }
	    return sb.toString();
	}
}
