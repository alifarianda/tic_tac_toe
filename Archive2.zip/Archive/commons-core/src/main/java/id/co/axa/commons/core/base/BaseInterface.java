package id.co.axa.commons.core.base;

import java.io.Serializable;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public interface BaseInterface extends Serializable {

}
