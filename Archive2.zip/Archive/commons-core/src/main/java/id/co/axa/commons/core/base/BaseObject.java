/**
 * 
 */
package id.co.axa.commons.core.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author muhammadmufqi
 *
 */

@JsonIgnoreProperties(value = { "created_date", "updated_date", "hibernateLazyInitializer", "handler",
		"detail" }, allowGetters = true, ignoreUnknown = true)
public abstract class BaseObject implements BaseInterface {

	private static final long serialVersionUID = -3463012513188099468L;

}
