package id.co.axa.commons.core.exception;

import id.co.axa.commons.core.payload.Status;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */

public abstract class BaseException extends RuntimeException {

	private static final long serialVersionUID = -6624542494063679867L;
	protected static final String TYPE_APPLICATION = "APPLICATION ERROR";
	protected static final String TYPE_SYSTEMS = "SYSTEMS ERROR";
	protected static final String TYPE_ENGINE = "ENGINE ERROR";
	protected String type;
	protected String key;
	protected String moduleName;
	protected String parameter;
	protected Status status;

	/**
	 * 
	 */
	public BaseException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public BaseException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public BaseException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public BaseException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public BaseException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public String getType() {
		return type;
	}

	public String getKey() {
		return key;
	}

	public String getModuleName() {
		return moduleName;
	}

	public String getParameter() {
		return parameter;
	}

	public Status getStatus() {
		return this.status;
	}

}
