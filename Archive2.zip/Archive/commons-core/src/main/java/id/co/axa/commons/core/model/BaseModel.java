package id.co.axa.commons.core.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import id.co.axa.commons.core.base.BaseObject;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@MappedSuperclass
@EntityListeners({ AuditingEntityListener.class })
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class BaseModel extends BaseObject implements Model {

	private static final long serialVersionUID = 4476367320894047124L;

	@Column(name = "createdby")
	@JsonProperty("createdby")
	@JsonIgnore
	private String createdBy;
	@Column(name = "createddate", nullable = false, updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@CreatedDate
	@JsonProperty("createddate")
	
	@JsonIgnore
	private Date createdDate;
	@Column(name = "updatedby")
	@JsonProperty("updatedby")
	
	@JsonIgnore
	private String updatedBy;
	@Column(name = "updateddate")
	@Temporal(TemporalType.TIMESTAMP)
	@JsonProperty("updateddate")
	
	@JsonIgnore
	private Date updatedDate;

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return this.updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

}
