/**
 * 
 */
package id.co.axa.commons.core.payload;

import id.co.axa.commons.core.base.BaseInterface;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */
public interface Response<T> extends BaseInterface {

	Status getStatus();

	void setStatus(Status status);

	T getResult();

	void setResult(T result);

}
