package id.co.axa.commons.core.exception;

import id.co.axa.commons.core.payload.Status;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public class ApplicationException extends BaseException {

	private static final long serialVersionUID = -8621842394715786673L;

	public ApplicationException() {
		this.type = "APPLICATION ERROR";
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public ApplicationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		this.type = "APPLICATION ERROR";
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ApplicationException(String message, Throwable cause) {
		super(message, cause);
		this.type = "APPLICATION ERROR";
	}

	/**
	 * @param message
	 */
	public ApplicationException(String message) {
		super(message);
		this.type = "APPLICATION ERROR";
	}

	/**
	 * @param cause
	 */
	public ApplicationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ApplicationException(String key, String moduleName, String parameter) {
		super(String.format("%s not found with %s : '%s'", key, moduleName, parameter));
		this.key = key;
		this.moduleName = moduleName;
		this.parameter = parameter;
		this.type = "APPLICATION ERROR";
	}

	public ApplicationException(Status status) {
		super(status.getResponsemessage());
		this.status = status;
		this.type = "APPLICATION ERROR";
	}
}
