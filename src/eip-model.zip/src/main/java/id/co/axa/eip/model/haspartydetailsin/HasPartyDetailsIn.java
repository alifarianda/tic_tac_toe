/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.haspartydetailsin;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.canbeexternalorg.CanBeExternalOrg;
import id.co.axa.eip.model.canbeindividual.CanBeIndividual;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "partyCD", "servicingCD", "canBeIndividual", "canBeExternalOrg" })
@Component
public class HasPartyDetailsIn {

	@JsonProperty("partyCD")
	private String partyCD;

	@JsonProperty("servicingCD")
	private String servicingCD;

	@JsonProperty("canBeIndividual")
	private CanBeIndividual canBeIndividual;

	@JsonProperty("canBeExternalOrg")
	private CanBeExternalOrg canBeExternalOrg;

	public HasPartyDetailsIn() {

	}

	/**
	 * @param partyCD
	 * @param servicingCD
	 * @param canBeIndividual
	 */
	public HasPartyDetailsIn(String partyCD, String servicingCD, CanBeIndividual canBeIndividual) {
		this.partyCD = partyCD;
		this.servicingCD = servicingCD;
		this.canBeIndividual = canBeIndividual;
	}

	@JsonProperty("partyCD")
	public String getPartyCD() {
		return partyCD;
	}

	@JsonProperty("partyCD")
	public void setPartyCD(String partyCD) {
		this.partyCD = partyCD;
	}

	@JsonProperty("servicingCD")
	public String getServicingCD() {
		return servicingCD;
	}

	@JsonProperty("servicingCD")
	public void setServicingCD(String servicingCD) {
		this.servicingCD = servicingCD;
	}

	@JsonProperty("canBeIndividual")
	public CanBeIndividual getCanBeIndividual() {
		return canBeIndividual;
	}

	@JsonProperty("canBeIndividual")
	public void setCanBeIndividual(CanBeIndividual canBeIndividual) {
		this.canBeIndividual = canBeIndividual;
	}

	@JsonProperty("canBeExternalOrg")
	public CanBeExternalOrg getCanBeExternalOrg() {
		return canBeExternalOrg;
	}

	@JsonProperty("canBeExternalOrg")
	public void setCanBeExternalOrg(CanBeExternalOrg canBeExternalOrg) {
		this.canBeExternalOrg = canBeExternalOrg;
	}
}
