/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.haslifepolicychangetransdetailsin;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "startPremiumHolidayDT", "endPremiumHolidayDT" })
@Component
public class HasLifePolicyChangeTransDetailsIn {

	@JsonProperty("startPremiumHolidayDT")
	private String startPremiumHolidayDT;

	@JsonProperty("endPremiumHolidayDT")
	private String endPremiumHolidayDT;

	public HasLifePolicyChangeTransDetailsIn() {

	}

	/**
	 * @param startPremiumHolidayDT
	 * @param endPremiumHolidayDT
	 */
	public HasLifePolicyChangeTransDetailsIn(String startPremiumHolidayDT, String endPremiumHolidayDT) {
		this.startPremiumHolidayDT = startPremiumHolidayDT;
		this.endPremiumHolidayDT = endPremiumHolidayDT;
	}

	@JsonProperty("startPremiumHolidayDT")
	public String getStartPremiumHolidayDT() {
		return startPremiumHolidayDT;
	}

	@JsonProperty("startPremiumHolidayDT")
	public void setStartPremiumHolidayDT(String startPremiumHolidayDT) {
		this.startPremiumHolidayDT = startPremiumHolidayDT;
	}

	@JsonProperty("endPremiumHolidayDT")
	public String getEndPremiumHolidayDT() {
		return endPremiumHolidayDT;
	}

	@JsonProperty("endPremiumHolidayDT")
	public void setEndPremiumHolidayDT(String endPremiumHolidayDT) {
		this.endPremiumHolidayDT = endPremiumHolidayDT;
	}
}