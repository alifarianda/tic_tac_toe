/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */
package id.co.axa.eip.model.task;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.hasnamevalue.HasNameValue;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "taskId", "message", "status", "hasNameValue" })
public class Task {

	@JsonProperty("taskId")
	private String taskId;

	@JsonProperty("message")
	private String message;

	@JsonProperty("status")
	private String status;

	@JsonProperty("hasNameValue")
	private List<HasNameValue> hasNameValue = null;

	/**
	 * 
	 */
	public Task() {

	}

	/**
	 * @param taskId
	 * @param message
	 * @param status
	 * @param hasNameValue
	 */
	public Task(String taskId, String message, String status, List<HasNameValue> hasNameValue) {
		this.taskId = taskId;
		this.message = message;
		this.status = status;
		this.hasNameValue = hasNameValue;
	}

	@JsonProperty("taskId")
	public String getTaskId() {
		return taskId;
	}

	@JsonProperty("taskId")
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	@JsonProperty("message")
	public String getMessage() {
		return message;
	}

	@JsonProperty("message")
	public void setMessage(String message) {
		this.message = message;
	}

	@JsonProperty("status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("hasNameValue")
	public List<HasNameValue> getHasNameValue() {
		return hasNameValue;
	}

	@JsonProperty("hasNameValue")
	public void setHasNameValue(List<HasNameValue> hasNameValue) {
		this.hasNameValue = hasNameValue;
	}
}
