/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.body;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.customer.Customer;
import id.co.axa.eip.model.exception.Exception;
import id.co.axa.eip.model.notification.Notification;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "transactionId", "operation", "appID", "entity", "service", "Customer", "status", "exception",
		"notification" })

@Component("body")
public class Body {

	@JsonProperty("transactionId")
	private String transactionId;

	@JsonProperty("operation")
	private String operation;

	@JsonProperty("appID")
	private String appID;

	@JsonProperty("entity")
	private String entity;

	@JsonProperty("service")
	private String service;

	@JsonProperty("Customer")
	private Customer Customer;

	@JsonProperty("status")
	private String status;

	@JsonProperty("exception")
	private Exception exception;

	@JsonProperty("notification")
	private Notification notification;

	/**
	 * 
	 */
	public Body() {

	}

	/**
	 * @param transactionId
	 * @param operation
	 * @param appID
	 * @param entity
	 * @param service
	 * @param customer
	 * @param status
	 * @param exception
	 */
	public Body(String transactionId, String operation, String appID, String entity, String service, Customer customer,
			String status, Exception exception) {
		this.transactionId = transactionId;
		this.operation = operation;
		this.appID = appID;
		this.entity = entity;
		this.service = service;
		Customer = customer;
		this.status = status;
		this.exception = exception;
	}

	@JsonProperty("transactionId")
	public String getTransactionId() {
		return transactionId;
	}

	@JsonProperty("transactionId")
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	@JsonProperty("operation")
	public String getOperation() {
		return operation;
	}

	@JsonProperty("operation")
	public void setOperation(String operation) {
		this.operation = operation;
	}

	@JsonProperty("appID")
	public String getAppID() {
		return appID;
	}

	@JsonProperty("appID")
	public void setAppID(String appID) {
		this.appID = appID;
	}

	@JsonProperty("entity")
	public String getEntity() {
		return entity;
	}

	@JsonProperty("entity")
	public void setEntity(String entity) {
		this.entity = entity;
	}

	@JsonProperty("service")
	public String getService() {
		return service;
	}

	@JsonProperty("service")
	public void setService(String service) {
		this.service = service;
	}

	@JsonProperty("Customer")
	public Customer getCustomer() {
		return Customer;
	}

	@JsonProperty("Customer")
	public void setCustomer(Customer Customer) {
		this.Customer = Customer;
	}

	@JsonProperty("status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("exception")
	public Exception getException() {
		return exception;
	}

	@JsonProperty("exception")
	public void setException(Exception exception) {
		this.exception = exception;
	}

	@JsonProperty("notification")
	public Notification getNotification() {
		return notification;
	}

	@JsonProperty("notification")
	public void setNotification(Notification notification) {
		this.notification = notification;
	}

}
