/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.hasdetailsofriskin;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.haspersonaldetailsin.HasPersonalDetailsIn;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "insuredID", "hasPersonalDetailsIn" })
@Component
public class HasDetailsOfRisksIn {

	@JsonProperty("insuredID")
	private String insuredID;

	@JsonProperty("hasPersonalDetailsIn")
	private List<HasPersonalDetailsIn> hasPersonalDetailsIn = null;

	public HasDetailsOfRisksIn() {

	}

	/**
	 * @param insuredID
	 * @param hasPersonalDetailsIn
	 */
	public HasDetailsOfRisksIn(String insuredID, List<HasPersonalDetailsIn> hasPersonalDetailsIn) {
		this.insuredID = insuredID;
		this.hasPersonalDetailsIn = hasPersonalDetailsIn;
	}

	@JsonProperty("insuredID")
	public String getInsuredID() {
		return insuredID;
	}

	@JsonProperty("insuredID")
	public void setInsuredID(String insuredID) {
		this.insuredID = insuredID;
	}

	@JsonProperty("hasPersonalDetailsIn")
	public List<HasPersonalDetailsIn> getHasPersonalDetailsIn() {
		return hasPersonalDetailsIn;
	}

	@JsonProperty("hasPersonalDetailsIn")
	public void setHasPersonalDetailsIn(List<HasPersonalDetailsIn> hasPersonalDetailsIn) {
		this.hasPersonalDetailsIn = hasPersonalDetailsIn;
	}
}
