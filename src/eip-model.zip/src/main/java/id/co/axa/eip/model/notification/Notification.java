/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */
package id.co.axa.eip.model.notification;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.task.Task;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "referenceId", "statusDesc", "sourceChannel", "tasks" })
public class Notification {

	@JsonProperty("referenceId")
	private String referenceId;

	@JsonProperty("statusDesc")
	private String statusDesc;

	@JsonProperty("sourceChannel")
	private String sourceChannel;

	@JsonProperty("tasks")
	private List<Task> tasks = null;

	/**
	 * 
	 */
	public Notification() {

	}

	/**
	 * @param referenceId
	 * @param statusDesc
	 * @param sourceChannel
	 * @param tasks
	 */
	public Notification(String referenceId, String statusDesc, String sourceChannel, List<Task> tasks) {
		this.referenceId = referenceId;
		this.statusDesc = statusDesc;
		this.sourceChannel = sourceChannel;
		this.tasks = tasks;
	}

	@JsonProperty("referenceId")
	public String getReferenceId() {
		return referenceId;
	}

	@JsonProperty("referenceId")
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	@JsonProperty("statusDesc")
	public String getStatusDesc() {
		return statusDesc;
	}

	@JsonProperty("statusDesc")
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	@JsonProperty("sourceChannel")
	public String getSourceChannel() {
		return sourceChannel;
	}

	@JsonProperty("sourceChannel")
	public void setSourceChannel(String sourceChannel) {
		this.sourceChannel = sourceChannel;
	}

	@JsonProperty("tasks")
	public List<Task> getTasks() {
		return tasks;
	}

	@JsonProperty("tasks")
	public void setTasks(List<Task> tasks) {
		this.tasks = tasks;
	}

}
