package id.co.axa.commons.logging.serviceimpl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import id.co.axa.commons.logging.model.LogAssistantModel;
import id.co.axa.commons.logging.service.LogAssistantStartService;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */

@Service
public class LogAssistantStartServiceImpl implements LogAssistantStartService {

	protected static String DATE_PATTERN_TRX = "yyyy-MM-dd HH:mm:ss.SSS";
	protected static String LOG_TXN_LOG_ID = "txnLogID";
	protected static String LOG_HOSTNAME = "hostname";
	protected static String LOG_TRX_RQ_DT = "trxRqDT";
	protected static String LOG_REQUEST_ID = "requestID";
	protected static String LOG_CLIENT_ID = "clientID";
	protected static String LOG_CONTENT_TYPE = "contentType";
	protected static String LOG_METHOD = "method";
	protected static String LOG_URL_PATH = "urlPath";
	protected static String LOG_PAYLOAD_RQ = "payloadRq";
	protected static String LOG_KEY = "logkey";

	@Override
	public String loggingStart(LogAssistantModel logging) {
		loggingStartConstruct(logging);
		return null;
	}

	private JSONObject loggingStartConstruct(LogAssistantModel logging) {

		String logId = getLogId();
		String txnLogId = "";

		// Construct for Logging Start
		Map<String, Object> logGenerateStart = new HashMap<>();

		txnLogId = logId;

		// Put TxnLogID Unique ID
		String logGenerate;
		if (logGenerateStart.get(LOG_TXN_LOG_ID) != null) {
			logGenerate = logGenerateStart.get(LOG_TXN_LOG_ID).toString();
			logGenerateStart.put(LOG_TXN_LOG_ID, logGenerate);
		} else {
			logGenerateStart.put(LOG_TXN_LOG_ID, txnLogId);
		}

		// Populate for logging start
		InetAddress inetAddress;
		String hostName;
		try {
			inetAddress = InetAddress.getLocalHost();
			hostName = inetAddress.getHostName();
			
			logGenerateStart.put(LOG_HOSTNAME, hostName);
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		logGenerateStart.put(LOG_REQUEST_ID, logging.getRequestID());
		logGenerateStart.put(LOG_PAYLOAD_RQ, logging.getPayloadRq());
		logGenerateStart.put(LOG_CLIENT_ID, logging.getClientID());
		logGenerateStart.put(LOG_CONTENT_TYPE, logging.getContentType());
		logGenerateStart.put(LOG_METHOD, logging.getMethod());
		logGenerateStart.put(LOG_URL_PATH, logging.getUrlPath());

		ObjectMapper mapper = new ObjectMapper();

		// Convert object to string JSON Response
		String jsonResp;
		try {
			jsonResp = mapper.writeValueAsString(logging.getPayloadRq());

			// Convert string JSON response to JSONObject Class
			JSONObject convertedObject = new Gson().fromJson(jsonResp, JSONObject.class);

			logGenerateStart.put(LOG_PAYLOAD_RQ, convertedObject);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			logGenerateStart.put(LOG_PAYLOAD_RQ, logging.getPayloadRq());
		}

		SimpleDateFormat sdf = new SimpleDateFormat(DATE_PATTERN_TRX);

		// Get time from request
		logGenerateStart.put(LOG_TRX_RQ_DT, sdf.format(Calendar.getInstance().getTime()));

		// Set map List for Logging End
		logging.setListObject(logGenerateStart);
		return null;
	}

	/**
	 * 
	 * @return Date + UUID
	 * @apiNote TxnID for Log
	 */
	private String getLogId() {
		Date date = Calendar.getInstance().getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		return sdf.format(date) + "-" + UUID.randomUUID();
	}
}
