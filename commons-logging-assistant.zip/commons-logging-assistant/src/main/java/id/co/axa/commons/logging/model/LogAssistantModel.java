package id.co.axa.commons.logging.model;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "requestID", "clientID", "contentType", "method", "urlPath", "httpStatus_CD", "payloadRq",
		"PayloadRs" })
@Component
public class LogAssistantModel {

	private JSONObject jsonObject;

	Map<String, Object> listObject = new HashMap<>();

	@JsonProperty("requestID")
	private String requestID;

	@JsonProperty("clientID")
	private String clientID;

	@JsonProperty("contentType")
	private String contentType;

	@JsonProperty("method")
	private String method;

	@JsonProperty("urlPath")
	private String urlPath;

	@JsonProperty("httpStatus_CD")
	private HttpStatus httpStatusCD;

	@JsonProperty("payloadRq")
	private Object payloadRq;

	@JsonProperty("payloadRs")
	private String payloadRs;

	@JsonProperty("requestID")
	public String getRequestID() {
		return requestID;
	}

	@JsonProperty("requestID")
	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	@JsonProperty("clientID")
	public String getClientID() {
		return clientID;
	}

	@JsonProperty("clientID")
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	@JsonProperty("contentType")
	public String getContentType() {
		return contentType;
	}

	@JsonProperty("contentType")
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	@JsonProperty("method")
	public String getMethod() {
		return method;
	}

	@JsonProperty("method")
	public void setMethod(String method) {
		this.method = method;
	}

	@JsonProperty("urlPath")
	public String getUrlPath() {
		return urlPath;
	}

	@JsonProperty("urlPath")
	public void setUrlPath(String urlPath) {
		this.urlPath = urlPath;
	}

	public HttpStatus getHttpStatusCD() {
		return httpStatusCD;
	}

	public void setHttpStatusCD(HttpStatus httpStatusCD) {
		this.httpStatusCD = httpStatusCD;
	}

	public Object getPayloadRq() {
		return payloadRq;
	}

	public void setPayloadRq(Object payloadRq) {
		this.payloadRq = payloadRq;
	}

	@JsonProperty("PayloadRs")
	public String getPayloadRs() {
		return payloadRs;
	}

	@JsonProperty("PayloadRs")
	public void setPayloadRs(String payloadRs) {
		this.payloadRs = payloadRs;
	}

	public JSONObject getJsonObject() {
		return jsonObject;
	}

	public void setJsonObject(JSONObject jsonObject) {
		this.jsonObject = jsonObject;
	}

	public Map<String, Object> getListObject() {
		return listObject;
	}

	public void setListObject(Map<String, Object> listObject) {
		this.listObject = listObject;
	}
}
