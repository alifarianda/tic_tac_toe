package id.co.axa.commons.logging.kafka.configuration;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@Service
public class ProducerService {
	
	private final String topicName = "commons-logging";

	@Autowired
	private KafkaTemplate<String, Object> kafkaTemplate;

	public ProducerService(KafkaTemplate<String, Object> kafkaTemplate) {
		this.kafkaTemplate = kafkaTemplate;
	}

	public void sendMessage(JSONObject jsonObject) {
		kafkaTemplate.send(topicName, jsonObject);
	}

}
