package id.co.axa.commons.logging.service;

import id.co.axa.commons.logging.model.LogAssistantModel;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */

public interface LogAssistantStartService {
	String loggingStart(LogAssistantModel logging);

}
