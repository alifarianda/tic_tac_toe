package id.co.axa.middleware.model.paymentdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "bank", "finish", "secure", "channel", "saveCard", "token", "redirect_url", "masked_card",
		"card_type", "transactionTime", "paymentRefID", "approvalCode", "transaction_status", "signature_key",
		"channel_response_message", "channel_response_code", "statusCode", "statusMessage", "enable_callback",
		"expired_date", "ccNo", "fraudStatus", "save_token_id", "saved_token_id_expired_at" })
public class PaymentDetailsMiddleware {

	@JsonProperty("bank")
	private String bank;

	@JsonProperty("statusCode")
	private String statusCode;

	@JsonProperty("statusMessage")
	private String statusMessage;

	@JsonProperty("fraudStatus")
	private String fraudStatus;

	@JsonProperty("masked_card")
	private String maskedCard;

	@JsonProperty("card_type")
	private String cardType;

	@JsonProperty("transactionTime")
	private String transactionTime;

	@JsonProperty("paymentRefID")
	private String paymentRefID;

	@JsonProperty("enable_callback")
	private String enableCallBack;

	@JsonProperty("ccNo")
	private String ccNo;

	@JsonProperty("approvalCode")
	private String approvalCode;

	@JsonProperty("transaction_status")
	private String transactionStatus;

	@JsonProperty("signature_key")
	private String signatureKey;

	@JsonProperty("channel_response_message")
	private String channelResponseMessage;

	@JsonProperty("channel_response_code")
	private String channelResponseCode;

	@JsonProperty("finish")
	private String finish;

	@JsonProperty("secure")
	private String secure;

	@JsonProperty("channel")
	private String channel;

	@JsonProperty("saveCard")
	private String saveCard;

	@JsonProperty("token")
	private String token;

	@JsonProperty("redirect_url")
	private String redirectUrl;

	@JsonProperty("save_token_id")
	private String saveTokenId;

	@JsonProperty("saved_token_id_expired_at")
	private String savedTokenIdExpiredAt;

	@JsonProperty("finish")
	public String getFinish() {
		return finish;
	}

	@JsonProperty("finish")
	public void setFinish(String finish) {
		this.finish = finish;
	}

	@JsonProperty("secure")
	public String getSecure() {
		return secure;
	}

	@JsonProperty("secure")
	public void setSecure(String secure) {
		this.secure = secure;
	}

	@JsonProperty("channel")
	public String getChannel() {
		return channel;
	}

	@JsonProperty("channel")
	public void setChannel(String channel) {
		this.channel = channel;
	}

	@JsonProperty("saveCard")
	public String getSaveCard() {
		return saveCard;
	}

	@JsonProperty("saveCard")
	public void setSaveCard(String saveCard) {
		this.saveCard = saveCard;
	}

	@JsonProperty("token")
	public String getToken() {
		return token;
	}

	@JsonProperty("token")
	public void setToken(String token) {
		this.token = token;
	}

	@JsonProperty("redirect_url")
	public String getRedirectUrl() {
		return redirectUrl;
	}

	@JsonProperty("redirect_url")
	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

	@JsonProperty("masked_card")
	public String getMaskedCard() {
		return maskedCard;
	}

	@JsonProperty("masked_card")
	public void setMaskedCard(String maskedCard) {
		this.maskedCard = maskedCard;
	}

	@JsonProperty("bank")
	public String getBank() {
		return bank;
	}

	@JsonProperty("bank")
	public void setBank(String bank) {
		this.bank = bank;
	}

	@JsonProperty("card_type")
	public String getCardType() {
		return cardType;
	}

	@JsonProperty("card_type")
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	@JsonProperty("transactionTime")
	public String getTransactionTime() {
		return transactionTime;
	}

	@JsonProperty("transactionTime")
	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	@JsonProperty("paymentRefID")
	public String getPaymentRefID() {
		return paymentRefID;
	}

	@JsonProperty("paymentRefID")
	public void setPaymentRefID(String paymentRefID) {
		this.paymentRefID = paymentRefID;
	}

	@JsonProperty("approvalCode")
	public String getApprovalCode() {
		return approvalCode;
	}

	@JsonProperty("approvalCode")
	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}

	@JsonProperty("transaction_status")
	public String getTransactionStatus() {
		return transactionStatus;
	}

	@JsonProperty("transaction_status")
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	@JsonProperty("signature_key")
	public String getSignatureKey() {
		return signatureKey;
	}

	@JsonProperty("signature_key")
	public void setSignatureKey(String signatureKey) {
		this.signatureKey = signatureKey;
	}

	@JsonProperty("channel_response_message")
	public String getChannelResponseMessage() {
		return channelResponseMessage;
	}

	@JsonProperty("channel_response_message")
	public void setChannelResponseMessage(String channelResponseMessage) {
		this.channelResponseMessage = channelResponseMessage;
	}

	@JsonProperty("channel_response_code")
	public String getChannelResponseCode() {
		return channelResponseCode;
	}

	@JsonProperty("channel_response_code")
	public void setChannelResponseCode(String channelResponseCode) {
		this.channelResponseCode = channelResponseCode;
	}

	@JsonProperty("statusCode")
	public String getStatusCode() {
		return statusCode;
	}

	@JsonProperty("statusCode")
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	@JsonProperty("statusMessage")
	public String getStatusMessage() {
		return statusMessage;
	}

	@JsonProperty("statusMessage")
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	@JsonProperty("fraudStatus")
	public String getFraudStatus() {
		return fraudStatus;
	}

	@JsonProperty("fraudStatus")
	public void setFraudStatus(String fraudStatus) {
		this.fraudStatus = fraudStatus;
	}

	@JsonProperty("enable_callback")
	public String getEnableCallBack() {
		return enableCallBack;
	}

	@JsonProperty("enable_callback")
	public void setEnableCallBack(String enableCallBack) {
		this.enableCallBack = enableCallBack;
	}

	@JsonProperty("ccNo")
	public String getCcNo() {
		return ccNo;
	}

	@JsonProperty("ccNo")
	public void setCcNo(String ccNo) {
		this.ccNo = ccNo;
	}

	@JsonProperty("save_token_id")
	public String getSaveTokenId() {
		return saveTokenId;
	}

	@JsonProperty("save_token_id")
	public void setSaveTokenId(String saveTokenId) {
		this.saveTokenId = saveTokenId;
	}

	@JsonProperty("saved_token_id_expired_at")
	public String getSavedTokenIdExpiredAt() {
		return savedTokenIdExpiredAt;
	}

	@JsonProperty("saved_token_id_expired_at")
	public void setSavedTokenIdExpiredAt(String savedTokenIdExpiredAt) {
		this.savedTokenIdExpiredAt = savedTokenIdExpiredAt;
	}

}
