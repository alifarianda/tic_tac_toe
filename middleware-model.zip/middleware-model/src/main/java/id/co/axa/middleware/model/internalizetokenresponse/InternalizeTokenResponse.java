package id.co.axa.middleware.model.internalizetokenresponse;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "internalizedToken" })
public class InternalizeTokenResponse {

	@JsonProperty("internalizedToken")
	private String internalizedToken;

	@JsonProperty("internalizedToken")
	public String getInternalizedToken() {
		return internalizedToken;
	}

	@JsonProperty("internalizedToken")
	public void setInternalizedToken(String internalizedToken) {
		this.internalizedToken = internalizedToken;
	}
}
