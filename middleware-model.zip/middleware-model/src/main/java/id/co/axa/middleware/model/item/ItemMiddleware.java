package id.co.axa.middleware.model.item;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"id",
"name",
"category",
"amount",
"quantity"
})
public class ItemMiddleware {

	@JsonProperty("id")
	private String id;
	
	@JsonProperty("name")
	private String name;
	
	@JsonProperty("category")
	private String category;
	
	@JsonProperty("amount")
	private String amount;
	
	@JsonProperty("quantity")
	private String quantity;
	
	@JsonProperty("id")
	public String getId() {
		return id;
	}
	
	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}
	
	@JsonProperty("name")
	public String getName() {
		return name;
	}
	
	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}
	
	@JsonProperty("category")
	public String getCategory() {
		return category;
	}
	
	@JsonProperty("category")
	public void setCategory(String category) {
		this.category = category;
	}
	
	@JsonProperty("amount")
	public String getAmount() {
		return amount;
	}
	
	@JsonProperty("amount")
	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	@JsonProperty("quantity")
	public String getQuantity() {
		return quantity;
	}
	
	@JsonProperty("quantity")
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
}
