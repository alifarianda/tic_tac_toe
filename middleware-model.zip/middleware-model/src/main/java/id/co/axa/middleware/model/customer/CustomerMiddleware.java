package id.co.axa.middleware.model.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"firstNM",
"lastNM",
"emailAddress",
"phoneNumber"
})
public class CustomerMiddleware {

	@JsonProperty("firstNM")
	private String firstNM;
	
	@JsonProperty("lastNM")
	private String lastNM;
	
	@JsonProperty("emailAddress")
	private String emailAddress;
	
	@JsonProperty("phoneNumber")
	private String phoneNumber;
	
	@JsonProperty("firstNM")
	public String getFirstNM() {
		return firstNM;
	}
	
	@JsonProperty("firstNM")
	public void setFirstNM(String firstNM) {
		this.firstNM = firstNM;
	}
	
	@JsonProperty("lastNM")
	public String getLastNM() {
		return lastNM;
	}
	
	@JsonProperty("lastNM")
	public void setLastNM(String lastNM) {
		this.lastNM = lastNM;
	}
	
	@JsonProperty("emailAddress")
	public String getEmailAddress() {
		return emailAddress;
	}
	
	@JsonProperty("emailAddress")
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	@JsonProperty("phoneNumber")
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	@JsonProperty("phoneNumber")
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
}
