package id.co.axa.middleware.model.util;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public enum EnumMiddleware {
	STATUS,
	CANCEL
}
