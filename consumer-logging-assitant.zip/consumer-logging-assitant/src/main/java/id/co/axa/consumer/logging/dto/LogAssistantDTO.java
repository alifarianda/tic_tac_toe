package id.co.axa.consumer.logging.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public class LogAssistantDTO {

	@JsonProperty("txnLogID")
	private String txnLogID;

	@JsonProperty("requestID")
	private String requestID;

	@JsonProperty("clientID")
	private String clientID;

	@JsonProperty("contentType")
	private String contentType;

	@JsonProperty("method")
	private String method;

	@JsonProperty("urlPath")
	private String urlPath;

	@JsonProperty("httpStatus_CD")
	private String httpStatus_CD;

	@JsonProperty("payloadRq")
	private Object payloadRq;

	@JsonProperty("payloadRs")
	private Object payloadRs;

	@JsonProperty("processingTime")
	private long processingTime;

	@JsonProperty("hostname")
	private String hostname;

	@JsonProperty("trxRqDT")
	private String trxRqDT;

	@JsonProperty("trxRsDT")
	private String trxRsDT;

	public String getTxnLogID() {
		return txnLogID;
	}

	public void setTxnLogID(String txnLogID) {
		this.txnLogID = txnLogID;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getUrlPath() {
		return urlPath;
	}

	public void setUrlPath(String urlPath) {
		this.urlPath = urlPath;
	}

	public String getHttpStatus_CD() {
		return httpStatus_CD;
	}

	public void setHttpStatus_CD(String httpStatus_CD) {
		this.httpStatus_CD = httpStatus_CD;
	}

	public Object getPayloadRq() {
		return payloadRq;
	}

	public void setPayloadRq(Object payloadRq) {
		this.payloadRq = payloadRq;
	}

	public Object getPayloadRs() {
		return payloadRs;
	}

	public void setPayloadRs(Object payloadRs) {
		this.payloadRs = payloadRs;
	}

	public long getProcessingTime() {
		return processingTime;
	}

	public void setProcessingTime(long processingTime) {
		this.processingTime = processingTime;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getTrxRqDT() {
		return trxRqDT;
	}

	public void setTrxRqDT(String trxRqDT) {
		this.trxRqDT = trxRqDT;
	}

	public String getTrxRsDT() {
		return trxRsDT;
	}

	public void setTrxRsDT(String trxRsDT) {
		this.trxRsDT = trxRsDT;
	}

}
