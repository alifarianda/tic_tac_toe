package id.co.axa.consumer.logging.service;

import javax.transaction.Transactional;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;

import id.co.axa.commons.core.utils.DateUtils;
import id.co.axa.consumer.logging.dto.LogAssistantDTO;
import id.co.axa.consumer.logging.kafka.configuration.ProducerService;
import id.co.axa.consumer.logging.model.LogAssistantModel;
import id.co.axa.consumer.logging.repository.ConsumerRepository;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@Component
public class ConsumerKafka {

	private static final String TOPIC = "commons-logging";
	private final String GROUP_ID = "group_id";
	
	@Autowired
	private ConsumerRepository consumerRepository;

	@Autowired
	private KafkaTemplate<String, Object> kafkaTemplate;

	Logger logger = LoggerFactory.getLogger(ConsumerKafka.class);

	public ConsumerKafka(KafkaTemplate<String, Object> kafkaTemplate) {
		this.kafkaTemplate = kafkaTemplate;
	}

	@Transactional
	@KafkaListener(topics = TOPIC, groupId = GROUP_ID)
	public void consume(JSONObject jsonObject) {

		logger.info((String.format("$$$$ => Consumed message: %s", jsonObject)));

		try {
			Gson gson = new Gson();
			String logToJson = gson.toJson(jsonObject);

			LogAssistantDTO logAssistantdto = gson.fromJson(logToJson, LogAssistantDTO.class);

			LogAssistantModel logAssistantModel = new LogAssistantModel();

			logAssistantModel.setTxnLogId(logAssistantdto.getTxnLogID());
			logAssistantModel.setClientID(logAssistantdto.getClientID());
			logAssistantModel.setContentType(logAssistantdto.getContentType());
			logAssistantModel.setHostname(logAssistantdto.getHostname());
			logAssistantModel.setHttpStatus_CD(logAssistantdto.getHttpStatus_CD());;
			logAssistantModel.setMethod(logAssistantdto.getMethod());
			logAssistantModel.setPayloadRq(logAssistantdto.getPayloadRq().toString());
			logAssistantModel.setPayloadRs(logAssistantdto.getPayloadRs().toString());
			logAssistantModel.setProcessingTime(logAssistantdto.getProcessingTime());
			logAssistantModel.setRequestID(logAssistantdto.getRequestID());
			logAssistantModel.setTrxRqDT(DateUtils.toDate(logAssistantdto.getTrxRqDT()));
			logAssistantModel.setTrxRsDT(DateUtils.toDate(logAssistantdto.getTrxRsDT()));
			logAssistantModel.setUrlPath(logAssistantdto.getUrlPath());

			consumerRepository.save(logAssistantModel);
		} catch (Exception e) {
			ProducerService kafkaProducer = new ProducerService(kafkaTemplate);
			kafkaProducer.sendMessage(jsonObject);
		}
	}

}
