/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.exception;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@Component("exception")
public class Exception {

	@JsonProperty("message")
	private String message;

	@JsonProperty("backEndError")
	private String backEndError;

	@JsonProperty("code")
	private String code;

	public Exception() {

	}

	/**
	 * @param message
	 * @param backEndError
	 * @param code
	 */
	public Exception(String message, String backEndError, String code) {
		this.message = message;
		this.backEndError = backEndError;
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Exception withMessage(String message) {
		this.message = message;
		return this;
	}

	public String getBackEndError() {
		return backEndError;
	}

	public void setBackEndError(String backEndError) {
		this.backEndError = backEndError;
	}

	public Exception withBackEndError(String backEndError) {
		this.backEndError = backEndError;
		return this;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Exception withCode(String code) {
		this.code = code;
		return this;
	}
}
