/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.customer;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.canbeindividual.CanBeIndividual;
import id.co.axa.eip.model.hasnamevalue.HasNameValue;
import id.co.axa.eip.model.haspolicyaccount.HasPolicyAccount;
import id.co.axa.eip.model.havecommunicatedmessage.HaveCommunicatedMessage;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "hasPolicyAccount", "haveCommunicatedMessage", "canBeIndividual", "customerID", "documentID",
		"sourceCInd" })
@Component("customer")
public class Customer {

	@JsonProperty("hasPolicyAccount")
	private List<HasPolicyAccount> hasPolicyAccount;

	@JsonProperty("canBeIndividual")
	private CanBeIndividual canBeIndividual;

	@JsonProperty("hasNameValue")
	private List<HasNameValue> hasNameValue;

	@JsonProperty("customerID")
	private String customerID;

	@JsonProperty("documentID")
	private String documentID;

	@JsonProperty("sourceCInd")
	private String sourceCInd;

	public Customer() {

	}

	/**
	 * @param hasPolicyAccount
	 * @param canBeIndividual
	 * @param hasNameValue
	 * @param haveCommunicatedMessage
	 * @param customerID
	 * @param documentID
	 * @param sourceCInd
	 */
	public Customer(List<HasPolicyAccount> hasPolicyAccount, CanBeIndividual canBeIndividual,
			List<HasNameValue> hasNameValue, List<HaveCommunicatedMessage> haveCommunicatedMessage, String customerID,
			String documentID, String sourceCInd) {
		this.hasPolicyAccount = hasPolicyAccount;
		this.canBeIndividual = canBeIndividual;
		this.hasNameValue = hasNameValue;
		this.haveCommunicatedMessage = haveCommunicatedMessage;
		this.customerID = customerID;
		this.documentID = documentID;
		this.sourceCInd = sourceCInd;

	}

	@JsonProperty("canBeIndividual")
	public CanBeIndividual getCanBeIndividual() {
		return canBeIndividual;
	}

	@JsonProperty("canBeIndividual")
	public void setCanBeIndividual(CanBeIndividual canBeIndividual) {
		this.canBeIndividual = canBeIndividual;
	}

	@JsonProperty("hasPolicyAccount")
	public List<HasPolicyAccount> getHasPolicyAccount() {
		return hasPolicyAccount;
	}

	@JsonProperty("hasPolicyAccount")
	public void setHasPolicyAccount(List<HasPolicyAccount> hasPolicyAccount) {
		this.hasPolicyAccount = hasPolicyAccount;
	}

	@JsonProperty("haveCommunicatedMessage")
	private List<HaveCommunicatedMessage> haveCommunicatedMessage;

	@JsonProperty("haveCommunicatedMessage")
	public List<HaveCommunicatedMessage> getHaveCommunicatedMessage() {
		return haveCommunicatedMessage;
	}

	@JsonProperty("haveCommunicatedMessage")
	public void setHaveCommunicatedMessage(List<HaveCommunicatedMessage> haveCommunicatedMessage) {
		this.haveCommunicatedMessage = haveCommunicatedMessage;
	}

	public Customer withHaveCommunicatedMessage(List<HaveCommunicatedMessage> haveCommunicatedMessage) {
		this.haveCommunicatedMessage = haveCommunicatedMessage;
		return this;
	}

	@JsonProperty("hasNameValue")
	public List<HasNameValue> getHasNameValue() {
		return hasNameValue;
	}

	@JsonProperty("hasNameValue")
	public void setHasNameValue(List<HasNameValue> hasNameValue) {
		this.hasNameValue = hasNameValue;
	}

	@JsonProperty("customerID")
	public String getCustomerID() {
		return customerID;
	}

	@JsonProperty("customerID")
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	@JsonProperty("documentID")
	public String getDocumentID() {
		return documentID;
	}

	@JsonProperty("documentID")
	public void setDocumentID(String documentID) {
		this.documentID = documentID;
	}

	@JsonProperty("sourceCInd")
	public String getSourceCInd() {
		return sourceCInd;
	}

	@JsonProperty("sourceCInd")
	public void setSourceCInd(String sourceCInd) {
		this.sourceCInd = sourceCInd;
	}
}
