/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.haspolicyaccount;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.hasapplicationdetailsin.HasApplicationDetailsIn;
import id.co.axa.eip.model.hasaxaasiapolicypaymentaccount.HasAXAAsiaPolicyPaymentAccount;
import id.co.axa.eip.model.hasbilling.HasBilling;
import id.co.axa.eip.model.hasdetailsofpolicyin.HasDetailsOfPolicyIn;
import id.co.axa.eip.model.hasdetailsofriskin.HasDetailsOfRisksIn;
import id.co.axa.eip.model.haslifepolicychangetransdetailsin.HasLifePolicyChangeTransDetailsIn;
import id.co.axa.eip.model.haslifepolicytransactiondetailsin.HasLifePolicyTransactionDetailsIn;
import id.co.axa.eip.model.hasnamevalue.HasNameValue;
import id.co.axa.eip.model.haspartydetailsin.HasPartyDetailsIn;
import id.co.axa.eip.model.isassociatedwithlifeinsuranceproduct.IsAssociatedWithLifeInsuranceProduct;

import java.util.List;

import org.springframework.stereotype.Component;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "policyEffectiveDTTM", "paymentMethodCD", "policyExpirationDTTM", "initialLumpsumPremiumAMT",
		"hasLifePolicyChangeTransDetailsIn", "policyReserveAmt", "hasNameValue", "hasApplicationDetailsIn", "paidToDT",
		"hasDetailsOfPolicyIn", "ePolicy", "issueDt", "sourceChannelCD", "hasLifePolicyTransactionDetailsIn",
		"policyRK", "hasPartyDetailsIn", "currencyCD", "isAssociatedWithLifeInsuranceProduct", "policyStatusCD",
		"topupRegularModalPremium", "statusChangeDT", "terminationDt", "policyNO", "policyDueDt", "premiumAMT",
		"paymentModeCD", "hasDetailsOfRisksIn", "processedDttm", "hasBilling", "hasAXAAsiaPolicyPaymentAccount" })
@Component
public class HasPolicyAccount {

	@JsonProperty("processedDttm")
	private String processedDttm;

	@JsonProperty("policyEffectiveDTTM")
	private String policyEffectiveDTTM;

	@JsonProperty("paymentMethodCD")
	private String paymentMethodCD;

	@JsonProperty("policyExpirationDTTM")
	private String policyExpirationDTTM;

	@JsonProperty("initialLumpsumPremiumAMT")
	private String initialLumpsumPremiumAMT;

	@JsonProperty("hasLifePolicyChangeTransDetailsIn")
	private List<HasLifePolicyChangeTransDetailsIn> hasLifePolicyChangeTransDetailsIn;

	@JsonProperty("hasBilling")
	private HasBilling hasBilling;

	@JsonProperty("policyReserveAmt")
	private String policyReserveAmt;

	@JsonProperty("hasApplicationDetailsIn")
	private List<HasApplicationDetailsIn> hasApplicationDetailsIn;

	@JsonProperty("paidToDT")
	private String paidToDT;

	@JsonProperty("hasDetailsOfPolicyIn")
	private List<HasDetailsOfPolicyIn> hasDetailsOfPolicyIn;

	@JsonProperty("ePolicy")
	private String ePolicy;

	@JsonProperty("issueDt")
	private String issueDt;

	@JsonProperty("sourceChannelCD")
	private String sourceChannelCD;

	@JsonProperty("hasLifePolicyTransactionDetailsIn")
	private List<HasLifePolicyTransactionDetailsIn> hasLifePolicyTransactionDetailsIn;

	@JsonProperty("hasNameValue")
	private List<HasNameValue> hasNameValue;

	@JsonProperty("policyRK")
	private String policyRK;

	@JsonProperty("policyStatusRk")
	private String policyStatusRk;

	@JsonProperty("hasPartyDetailsIn")
	private List<HasPartyDetailsIn> hasPartyDetailsIn;

	@JsonProperty("currencyCD")
	private String currencyCD;

	@JsonProperty("isAssociatedWithLifeInsuranceProduct")
	private List<IsAssociatedWithLifeInsuranceProduct> isAssociatedWithLifeInsuranceProduct;

	@JsonProperty("policyStatusCD")
	private String policyStatusCD;

	@JsonProperty("topupRegularModalPremium")
	private String topupRegularModalPremium;

	@JsonProperty("statusChangeDT")
	private String statusChangeDT;

	@JsonProperty("terminationDt")
	private String terminationDt;

	@JsonProperty("policyNO")
	private String policyNO;

	@JsonProperty("policyDueDt")
	private String policyDueDt;

	@JsonProperty("premiumAMT")
	private String premiumAMT;

	@JsonProperty("paymentModeCD")
	private String paymentModeCD;

	@JsonProperty("hasDetailsOfRisksIn")
	private List<HasDetailsOfRisksIn> hasDetailsOfRisksIn;

	@JsonProperty("hasAXAAsiaPolicyPaymentAccount")
	private List<HasAXAAsiaPolicyPaymentAccount> hasAXAAsiaPolicyPaymentAccount;

	/**
	 * @param policyNO
	 */
	public HasPolicyAccount(String policyNO) {
		this.policyNO = policyNO;
	}

	public HasPolicyAccount() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param policyEffectiveDTTM
	 * @param paymentMethodCD
	 * @param policyExpirationDTTM
	 * @param initialLumpsumPremiumAMT
	 * @param hasLifePolicyChangeTransDetailsIn
	 * @param hasBilling
	 * @param policyReserveAmt
	 * @param hasApplicationDetailsIn
	 * @param paidToDT
	 * @param hasDetailsOfPolicyIn
	 * @param ePolicy
	 * @param issueDt
	 * @param sourceChannelCD
	 * @param hasLifePolicyTransactionDetailsIn
	 * @param hasNameValue
	 * @param policyRK
	 * @param policyStatusRk
	 * @param hasPartyDetailsIn
	 * @param currencyCD
	 * @param isAssociatedWithLifeInsuranceProduct
	 * @param policyStatusCD
	 * @param topupRegularModalPremium
	 * @param statusChangeDT
	 * @param terminationDt
	 * @param policyNO
	 * @param policyDueDt
	 * @param premiumAMT
	 * @param paymentModeCD
	 * @param processedDttm
	 * @param hasDetailsOfRisksIn
	 * @param hasAXAAsiaPolicyPaymentAccount
	 */
	public HasPolicyAccount(String policyEffectiveDTTM, String paymentMethodCD, String policyExpirationDTTM,
			String initialLumpsumPremiumAMT, List<HasLifePolicyChangeTransDetailsIn> hasLifePolicyChangeTransDetailsIn,
			HasBilling hasBilling, String policyReserveAmt, List<HasApplicationDetailsIn> hasApplicationDetailsIn,
			String paidToDT, List<HasDetailsOfPolicyIn> hasDetailsOfPolicyIn, String ePolicy, String issueDt,
			String sourceChannelCD, List<HasLifePolicyTransactionDetailsIn> hasLifePolicyTransactionDetailsIn,
			List<HasNameValue> hasNameValue, String policyRK, String policyStatusRk,
			List<HasPartyDetailsIn> hasPartyDetailsIn, String currencyCD,
			List<IsAssociatedWithLifeInsuranceProduct> isAssociatedWithLifeInsuranceProduct, String policyStatusCD,
			String topupRegularModalPremium, String statusChangeDT, String terminationDt, String policyNO,
			String policyDueDt, String premiumAMT, String paymentModeCD, String processedDttm,
			List<HasDetailsOfRisksIn> hasDetailsOfRisksIn,
			List<HasAXAAsiaPolicyPaymentAccount> hasAXAAsiaPolicyPaymentAccount) {
		this.policyEffectiveDTTM = policyEffectiveDTTM;
		this.paymentMethodCD = paymentMethodCD;
		this.policyExpirationDTTM = policyExpirationDTTM;
		this.initialLumpsumPremiumAMT = initialLumpsumPremiumAMT;
		this.hasLifePolicyChangeTransDetailsIn = hasLifePolicyChangeTransDetailsIn;
		this.hasBilling = hasBilling;
		this.policyReserveAmt = policyReserveAmt;
		this.hasApplicationDetailsIn = hasApplicationDetailsIn;
		this.paidToDT = paidToDT;
		this.hasDetailsOfPolicyIn = hasDetailsOfPolicyIn;
		this.ePolicy = ePolicy;
		this.issueDt = issueDt;
		this.sourceChannelCD = sourceChannelCD;
		this.hasLifePolicyTransactionDetailsIn = hasLifePolicyTransactionDetailsIn;
		this.hasNameValue = hasNameValue;
		this.policyRK = policyRK;
		this.policyStatusRk = policyStatusRk;
		this.hasPartyDetailsIn = hasPartyDetailsIn;
		this.currencyCD = currencyCD;
		this.isAssociatedWithLifeInsuranceProduct = isAssociatedWithLifeInsuranceProduct;
		this.policyStatusCD = policyStatusCD;
		this.topupRegularModalPremium = topupRegularModalPremium;
		this.statusChangeDT = statusChangeDT;
		this.terminationDt = terminationDt;
		this.policyNO = policyNO;
		this.policyDueDt = policyDueDt;
		this.premiumAMT = premiumAMT;
		this.paymentModeCD = paymentModeCD;
		this.processedDttm = processedDttm;
		this.hasDetailsOfRisksIn = hasDetailsOfRisksIn;
		this.hasAXAAsiaPolicyPaymentAccount = hasAXAAsiaPolicyPaymentAccount;
	}

	@JsonProperty("processedDttm")
	public String getProcessedDttm() {
		return processedDttm;
	}

	@JsonProperty("processedDttm")
	public void setProcessedDttm(String processedDttm) {
		this.processedDttm = processedDttm;
	}

	@JsonProperty("policyEffectiveDTTM")
	public String getPolicyEffectiveDTTM() {
		return policyEffectiveDTTM;
	}

	@JsonProperty("policyEffectiveDTTM")
	public void setPolicyEffectiveDTTM(String policyEffectiveDTTM) {
		this.policyEffectiveDTTM = policyEffectiveDTTM;
	}

	@JsonProperty("paymentMethodCD")
	public String getPaymentMethodCD() {
		return paymentMethodCD;
	}

	@JsonProperty("paymentMethodCD")
	public void setPaymentMethodCD(String paymentMethodCD) {
		this.paymentMethodCD = paymentMethodCD;
	}

	@JsonProperty("policyExpirationDTTM")
	public String getPolicyExpirationDTTM() {
		return policyExpirationDTTM;
	}

	@JsonProperty("policyExpirationDTTM")
	public void setPolicyExpirationDTTM(String policyExpirationDTTM) {
		this.policyExpirationDTTM = policyExpirationDTTM;
	}

	@JsonProperty("initialLumpsumPremiumAMT")
	public String getInitialLumpsumPremiumAMT() {
		return initialLumpsumPremiumAMT;
	}

	@JsonProperty("initialLumpsumPremiumAMT")
	public void setInitialLumpsumPremiumAMT(String initialLumpsumPremiumAMT) {
		this.initialLumpsumPremiumAMT = initialLumpsumPremiumAMT;
	}

	@JsonProperty("hasLifePolicyChangeTransDetailsIn")
	public List<HasLifePolicyChangeTransDetailsIn> getHasLifePolicyChangeTransDetailsIn() {
		return hasLifePolicyChangeTransDetailsIn;
	}

	@JsonProperty("hasLifePolicyChangeTransDetailsIn")
	public void setHasLifePolicyChangeTransDetailsIn(
			List<HasLifePolicyChangeTransDetailsIn> hasLifePolicyChangeTransDetailsIn) {
		this.hasLifePolicyChangeTransDetailsIn = hasLifePolicyChangeTransDetailsIn;
	}

	@JsonProperty("policyReserveAmt")
	public String getPolicyReserveAmt() {
		return policyReserveAmt;
	}

	@JsonProperty("policyReserveAmt")
	public void setPolicyReserveAmt(String policyReserveAmt) {
		this.policyReserveAmt = policyReserveAmt;
	}

	@JsonProperty("hasApplicationDetailsIn")
	public List<HasApplicationDetailsIn> getHasApplicationDetailsIn() {
		return hasApplicationDetailsIn;
	}

	@JsonProperty("hasApplicationDetailsIn")
	public void setHasApplicationDetailsIn(List<HasApplicationDetailsIn> hasApplicationDetailsIn) {
		this.hasApplicationDetailsIn = hasApplicationDetailsIn;
	}

	@JsonProperty("paidToDT")
	public String getPaidToDT() {
		return paidToDT;
	}

	@JsonProperty("paidToDT")
	public void setPaidToDT(String paidToDT) {
		this.paidToDT = paidToDT;
	}

	@JsonProperty("hasDetailsOfPolicyIn")
	public List<HasDetailsOfPolicyIn> getHasDetailsOfPolicyIn() {
		return hasDetailsOfPolicyIn;
	}

	@JsonProperty("hasDetailsOfPolicyIn")
	public void setHasDetailsOfPolicyIn(List<HasDetailsOfPolicyIn> hasDetailsOfPolicyIn) {
		this.hasDetailsOfPolicyIn = hasDetailsOfPolicyIn;
	}

	@JsonProperty("ePolicy")
	public String getEPolicy() {
		return ePolicy;
	}

	@JsonProperty("ePolicy")
	public void setEPolicy(String ePolicy) {
		this.ePolicy = ePolicy;
	}

	@JsonProperty("issueDt")
	public String getIssueDt() {
		return issueDt;
	}

	@JsonProperty("issueDt")
	public void setIssueDt(String issueDt) {
		this.issueDt = issueDt;
	}

	@JsonProperty("sourceChannelCD")
	public String getSourceChannelCD() {
		return sourceChannelCD;
	}

	@JsonProperty("sourceChannelCD")
	public void setSourceChannelCD(String sourceChannelCD) {
		this.sourceChannelCD = sourceChannelCD;
	}

	@JsonProperty("hasLifePolicyTransactionDetailsIn")
	public List<HasLifePolicyTransactionDetailsIn> getHasLifePolicyTransactionDetailsIn() {
		return hasLifePolicyTransactionDetailsIn;
	}

	@JsonProperty("hasLifePolicyTransactionDetailsIn")
	public void setHasLifePolicyTransactionDetailsIn(
			List<HasLifePolicyTransactionDetailsIn> hasLifePolicyTransactionDetailsIn) {
		this.hasLifePolicyTransactionDetailsIn = hasLifePolicyTransactionDetailsIn;
	}

	@JsonProperty("policyRK")
	public String getPolicyRK() {
		return policyRK;
	}

	@JsonProperty("policyRK")
	public void setPolicyRK(String policyRK) {
		this.policyRK = policyRK;
	}

	@JsonProperty("hasPartyDetailsIn")
	public List<HasPartyDetailsIn> getHasPartyDetailsIn() {
		return hasPartyDetailsIn;
	}

	@JsonProperty("hasPartyDetailsIn")
	public void setHasPartyDetailsIn(List<HasPartyDetailsIn> hasPartyDetailsIn) {
		this.hasPartyDetailsIn = hasPartyDetailsIn;
	}

	@JsonProperty("currencyCD")
	public String getCurrencyCD() {
		return currencyCD;
	}

	@JsonProperty("currencyCD")
	public void setCurrencyCD(String currencyCD) {
		this.currencyCD = currencyCD;
	}

	@JsonProperty("isAssociatedWithLifeInsuranceProduct")
	public List<IsAssociatedWithLifeInsuranceProduct> getIsAssociatedWithLifeInsuranceProduct() {
		return isAssociatedWithLifeInsuranceProduct;
	}

	@JsonProperty("isAssociatedWithLifeInsuranceProduct")
	public void setIsAssociatedWithLifeInsuranceProduct(
			List<IsAssociatedWithLifeInsuranceProduct> isAssociatedWithLifeInsuranceProduct) {
		this.isAssociatedWithLifeInsuranceProduct = isAssociatedWithLifeInsuranceProduct;
	}

	@JsonProperty("policyStatusCD")
	public String getPolicyStatusCD() {
		return policyStatusCD;
	}

	@JsonProperty("policyStatusCD")
	public void setPolicyStatusCD(String policyStatusCD) {
		this.policyStatusCD = policyStatusCD;
	}

	@JsonProperty("topupRegularModalPremium")
	public String getTopupRegularModalPremium() {
		return topupRegularModalPremium;
	}

	@JsonProperty("topupRegularModalPremium")
	public void setTopupRegularModalPremium(String topupRegularModalPremium) {
		this.topupRegularModalPremium = topupRegularModalPremium;
	}

	@JsonProperty("statusChangeDT")
	public String getStatusChangeDT() {
		return statusChangeDT;
	}

	@JsonProperty("statusChangeDT")
	public void setStatusChangeDT(String statusChangeDT) {
		this.statusChangeDT = statusChangeDT;
	}

	@JsonProperty("terminationDt")
	public String getTerminationDt() {
		return terminationDt;
	}

	@JsonProperty("terminationDt")
	public void setTerminationDt(String terminationDt) {
		this.terminationDt = terminationDt;
	}

	@JsonProperty("policyNO")
	public String getPolicyNO() {
		return policyNO;
	}

	@JsonProperty("policyNO")
	public void setPolicyNO(String policyNO) {
		this.policyNO = policyNO;
	}

	@JsonProperty("policyDueDt")
	public String getPolicyDueDt() {
		return policyDueDt;
	}

	@JsonProperty("policyDueDt")
	public void setPolicyDueDt(String policyDueDt) {
		this.policyDueDt = policyDueDt;
	}

	@JsonProperty("premiumAMT")
	public String getPremiumAMT() {
		return premiumAMT;
	}

	@JsonProperty("premiumAMT")
	public void setPremiumAMT(String premiumAMT) {
		this.premiumAMT = premiumAMT;
	}

	@JsonProperty("paymentModeCD")
	public String getPaymentModeCD() {
		return paymentModeCD;
	}

	@JsonProperty("paymentModeCD")
	public void setPaymentModeCD(String paymentModeCD) {
		this.paymentModeCD = paymentModeCD;
	}

	@JsonProperty("hasDetailsOfRisksIn")
	public List<HasDetailsOfRisksIn> getHasDetailsOfRisksIn() {
		return hasDetailsOfRisksIn;
	}

	@JsonProperty("hasDetailsOfRisksIn")
	public void setHasDetailsOfRisksIn(List<HasDetailsOfRisksIn> hasDetailsOfRisksIn) {
		this.hasDetailsOfRisksIn = hasDetailsOfRisksIn;
	}

	@JsonProperty("hasBilling")
	public HasBilling getHasBilling() {
		return hasBilling;
	}

	@JsonProperty("hasBilling")
	public void setHasBilling(HasBilling hasBilling) {
		this.hasBilling = hasBilling;
	}

	@JsonProperty("hasNameValue")
	public List<HasNameValue> getHasNameValue() {
		return hasNameValue;
	}

	@JsonProperty("hasNameValue")
	public void setHasNameValue(List<HasNameValue> hasNameValue) {
		this.hasNameValue = hasNameValue;
	}

	public String getPolicyStatusRk() {
		return policyStatusRk;
	}

	public void setPolicyStatusRk(String policyStatusRk) {
		this.policyStatusRk = policyStatusRk;
	}

	public List<HasAXAAsiaPolicyPaymentAccount> getHasAXAAsiaPolicyPaymentAccount() {
		return hasAXAAsiaPolicyPaymentAccount;
	}

	public void setHasAXAAsiaPolicyPaymentAccount(List<HasAXAAsiaPolicyPaymentAccount> hasAXAAsiaPolicyPaymentAccount) {
		this.hasAXAAsiaPolicyPaymentAccount = hasAXAAsiaPolicyPaymentAccount;
	}

}
