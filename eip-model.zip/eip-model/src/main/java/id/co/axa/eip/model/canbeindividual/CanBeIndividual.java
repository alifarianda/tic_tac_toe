/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.canbeindividual;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.hasaddressesin.HasAddressesIn;
import id.co.axa.eip.model.haspartyaccountdetailsin.HasPartyAccountDetailsIn;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "genderCD", "hasAddressesIn", "hasPartyAccountDetailsIn", "firstNM", "lastNM", "socialSecurityNO",
		"birthPlace", "birthDT" })

@Component
public class CanBeIndividual {

	@JsonProperty("genderCD")
	private String genderCD;

	@JsonProperty("hasAddressesIn")
	private List<HasAddressesIn> hasAddressesIn = null;

	@JsonProperty("hasPartyAccountDetailsIn")
	private HasPartyAccountDetailsIn hasPartyAccountDetailsIn;

	@JsonProperty("firstNM")
	private String firstNM;

	@JsonProperty("lastNM")
	private String lastNM;

	@JsonProperty("socialSecurityNO")
	private String socialSecurityNO;

	@JsonProperty("birthPlace")
	private String birthPlace;

	@JsonProperty("birthDT")
	private String birthDT;

	public CanBeIndividual() {

	}

	/**
	 * @param genderCD
	 * @param hasAddressesIn
	 * @param hasPartyAccountDetailsIn
	 * @param firstNM
	 * @param lastNM
	 * @param socialSecurityNO
	 * @param birthPlace
	 * @param birthDT
	 */
	public CanBeIndividual(String genderCD, List<HasAddressesIn> hasAddressesIn,
			HasPartyAccountDetailsIn hasPartyAccountDetailsIn, String firstNM, String lastNM, String socialSecurityNO,
			String birthPlace, String birthDT) {
		this.genderCD = genderCD;
		this.hasAddressesIn = hasAddressesIn;
		this.hasPartyAccountDetailsIn = hasPartyAccountDetailsIn;
		this.firstNM = firstNM;
		this.lastNM = lastNM;
		this.socialSecurityNO = socialSecurityNO;
		this.birthPlace = birthPlace;
		this.birthDT = birthDT;
	}

	@JsonProperty("genderCD")
	public String getGenderCD() {
		return genderCD;
	}

	@JsonProperty("genderCD")
	public void setGenderCD(String genderCD) {
		this.genderCD = genderCD;
	}

	@JsonProperty("hasAddressesIn")
	public List<HasAddressesIn> getHasAddressesIn() {
		return hasAddressesIn;
	}

	@JsonProperty("hasAddressesIn")
	public void setHasAddressesIn(List<HasAddressesIn> hasAddressesIn) {
		this.hasAddressesIn = hasAddressesIn;
	}

	@JsonProperty("hasPartyAccountDetailsIn")
	public HasPartyAccountDetailsIn getHasPartyAccountDetailsIn() {
		return hasPartyAccountDetailsIn;
	}

	@JsonProperty("hasPartyAccountDetailsIn")
	public void setHasPartyAccountDetailsIn(HasPartyAccountDetailsIn hasPartyAccountDetailsIn) {
		this.hasPartyAccountDetailsIn = hasPartyAccountDetailsIn;
	}

	@JsonProperty("firstNM")
	public String getFirstNM() {
		return firstNM;
	}

	@JsonProperty("firstNM")
	public void setFirstNM(String firstNM) {
		this.firstNM = firstNM;
	}

	@JsonProperty("lastNM")
	public String getLastNM() {
		return lastNM;
	}

	@JsonProperty("lastNM")
	public void setLastNM(String lastNM) {
		this.lastNM = lastNM;
	}

	@JsonProperty("socialSecurityNO")
	public String getSocialSecurityNO() {
		return socialSecurityNO;
	}

	@JsonProperty("socialSecurityNO")
	public void setSocialSecurityNO(String socialSecurityNO) {
		this.socialSecurityNO = socialSecurityNO;
	}

	@JsonProperty("birthPlace")
	public String getBirthPlace() {
		return birthPlace;
	}

	@JsonProperty("birthPlace")
	public void setBirthPlace(String birthPlace) {
		this.birthPlace = birthPlace;
	}

	@JsonProperty("birthDT")
	public String getBirthDT() {
		return birthDT;
	}

	@JsonProperty("birthDT")
	public void setBirthDT(String birthDT) {
		this.birthDT = birthDT;
	}
}
