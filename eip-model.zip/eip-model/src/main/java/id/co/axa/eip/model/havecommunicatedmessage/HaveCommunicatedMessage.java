/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.havecommunicatedmessage;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@Component
public class HaveCommunicatedMessage {

	@JsonProperty("sender")
	private String sender;

	@JsonProperty("bizDivisionX")
	private String bizDivisionX;

	@JsonProperty("target")
	private String target;

	@JsonProperty("message")
	private String message;

	@JsonProperty("batchName")
	private String batchName;

	@JsonProperty("triggeredBy")
	private String triggeredBy;

	@JsonProperty("channelID")
	private String channelID;

	@JsonProperty("messageID")
	private String messageID;

	@JsonProperty("deliveryStatusCD")
	private String deliveryStatusCD;

	@JsonProperty("replyTo")
	private String replyTo;

	@JsonProperty("deliveryDT")
	private String deliveryDT;

	@JsonProperty("chargeAmt")
	private String chargeAmt;

	@JsonProperty("additionalRk")
	private String additionalRk;

	@JsonProperty("deliveryStatusDesc")
	private String deliveryStatusDesc;

	public HaveCommunicatedMessage() {
	}

	public HaveCommunicatedMessage(String sender, String bizDivisionX, String target, String message, String batchName,
			String triggeredBy, String channelID) {
		this.sender = sender;
		this.bizDivisionX = bizDivisionX;
		this.target = target;
		this.message = message;
		this.batchName = batchName;
		this.triggeredBy = triggeredBy;
		this.channelID = channelID;
	}

	public HaveCommunicatedMessage(String target, String messageID, String deliveryStatusCD) {
		this.target = target;
		this.messageID = messageID;
		this.deliveryStatusCD = deliveryStatusCD;
	}

	/**
	 * @param sender
	 * @param bizDivisionX
	 * @param target
	 * @param message
	 * @param batchName
	 * @param triggeredBy
	 * @param channelID
	 * @param messageID
	 * @param deliveryStatusCD
	 * @param replyTo
	 * @param deliveryDT
	 * @param chargeAmt
	 * @param additionalRk
	 * @param deliveryStatusDesc
	 */
	public HaveCommunicatedMessage(String sender, String bizDivisionX, String target, String message, String batchName,
			String triggeredBy, String channelID, String messageID, String deliveryStatusCD, String replyTo,
			String deliveryDT, String chargeAmt, String additionalRk, String deliveryStatusDesc) {
		this.sender = sender;
		this.bizDivisionX = bizDivisionX;
		this.target = target;
		this.message = message;
		this.batchName = batchName;
		this.triggeredBy = triggeredBy;
		this.channelID = channelID;
		this.messageID = messageID;
		this.deliveryStatusCD = deliveryStatusCD;
		this.replyTo = replyTo;
		this.deliveryDT = deliveryDT;
		this.chargeAmt = chargeAmt;
		this.additionalRk = additionalRk;
		this.deliveryStatusDesc = deliveryStatusDesc;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public HaveCommunicatedMessage withSender(String sender) {
		this.sender = sender;
		return this;
	}

	public String getBizDivisionX() {
		return bizDivisionX;
	}

	public void setBizDivisionX(String bizDivisionX) {
		this.bizDivisionX = bizDivisionX;
	}

	public HaveCommunicatedMessage withBizDivisionX(String bizDivisionX) {
		this.bizDivisionX = bizDivisionX;
		return this;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public HaveCommunicatedMessage withTarget(String target) {
		this.target = target;
		return this;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public HaveCommunicatedMessage withMessage(String message) {
		this.message = message;
		return this;
	}

	public String getBatchName() {
		return batchName;
	}

	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}

	public HaveCommunicatedMessage withBatchName(String batchName) {
		this.batchName = batchName;
		return this;
	}

	public String getTriggeredBy() {
		return triggeredBy;
	}

	public void setTriggeredBy(String triggeredBy) {
		this.triggeredBy = triggeredBy;
	}

	public HaveCommunicatedMessage withTriggeredBy(String triggeredBy) {
		this.triggeredBy = triggeredBy;
		return this;
	}

	public String getChannelID() {
		return channelID;
	}

	public void setChannelID(String channelID) {
		this.channelID = channelID;
	}

	public HaveCommunicatedMessage withChannelID(String channelID) {
		this.channelID = channelID;
		return this;
	}

	public String getMessageID() {
		return messageID;
	}

	public void setMessageID(String messageID) {
		this.messageID = messageID;
	}

	public HaveCommunicatedMessage withMessageID(String messageID) {
		this.messageID = messageID;
		return this;
	}

	public String getDeliveryStatusCD() {
		return deliveryStatusCD;
	}

	public void setDeliveryStatusCD(String deliveryStatusCD) {
		this.deliveryStatusCD = deliveryStatusCD;
	}

	public HaveCommunicatedMessage withDeliveryStatusCD(String deliveryStatusCD) {
		this.deliveryStatusCD = deliveryStatusCD;
		return this;
	}

	public String getReplyTo() {
		return replyTo;
	}

	public void setReplyTo(String replyTo) {
		this.replyTo = replyTo;
	}

	public HaveCommunicatedMessage withReplyTo(String replyTo) {
		this.replyTo = replyTo;
		return this;
	}

	public String getDeliveryDT() {
		return deliveryDT;
	}

	public void setDeliveryDT(String deliveryDT) {
		this.deliveryDT = deliveryDT;
	}

	public HaveCommunicatedMessage withDeliveryDT(String deliveryDT) {
		this.deliveryDT = deliveryDT;
		return this;
	}

	public String getChargeAmt() {
		return chargeAmt;
	}

	public void setChargeAmt(String chargeAmt) {
		this.chargeAmt = chargeAmt;
	}

	public HaveCommunicatedMessage withChargeAmt(String chargeAmt) {
		this.chargeAmt = chargeAmt;
		return this;
	}

	public String getAdditionalRk() {
		return additionalRk;
	}

	public void setAdditionalRk(String additionalRk) {
		this.additionalRk = additionalRk;
	}

	public HaveCommunicatedMessage withAdditionalRk(String additionalRk) {
		this.additionalRk = additionalRk;
		return this;
	}

	public String getDeliveryStatusDesc() {
		return deliveryStatusDesc;
	}

	public void setDeliveryStatusDesc(String deliveryStatusDesc) {
		this.deliveryStatusDesc = deliveryStatusDesc;
	}

	public HaveCommunicatedMessage withDeliveryStatusDesc(String deliveryStatusDesc) {
		this.deliveryStatusDesc = deliveryStatusDesc;
		return this;
	}

}
