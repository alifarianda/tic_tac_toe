/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents Configuration class for request and response using RestTemplate to EIP Services.
 * 
 */

package id.co.axa.eip.model.configuration;

import java.nio.charset.StandardCharsets;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import id.co.axa.commons.core.exception.ApplicationException;
import id.co.axa.commons.core.exception.SystemsException;
import id.co.axa.commons.core.payload.Status;
import id.co.axa.eip.model.response.Response;

/**
 * 
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 *
 */

public class RestService {
	
	public  Response sendReq (String jsonMsg,String url) throws ApplicationException, SystemsException {
		RestTemplate restTemplate = new RestTemplate();
		Response response = new Response();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
			headers.add(HttpHeaders.ACCEPT_CHARSET, StandardCharsets.UTF_8.name());
			
		    HttpEntity<String> entity = new HttpEntity<>(jsonMsg,headers);
		    
		    response = restTemplate.postForObject(url, entity, Response.class);
		} catch(Exception e) {
            throw new ApplicationException(Status.ERROR_CODE, Status.ERROR_DESC, e.getLocalizedMessage());
		}
	    return response;
	}
}
