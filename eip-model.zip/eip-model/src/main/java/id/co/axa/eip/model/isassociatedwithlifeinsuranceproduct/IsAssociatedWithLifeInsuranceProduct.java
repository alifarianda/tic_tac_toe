/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.isassociatedwithlifeinsuranceproduct;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.hasplandetailsin.HasPlanDetailsIn;
import id.co.axa.eip.model.haspolicysegmentdetailsin.HasPolicySegmentDetailsIn;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "planCd", "insuranceProductRk", "hasPolicySegmentDetailsIn", "planNM", "insuranceProductCd",
		"hasPlanDetailsIn", "totalRecordCount", "productCategoryRk" })
@Component
public class IsAssociatedWithLifeInsuranceProduct {

	@JsonProperty("planCd")
	private String planCd;

	@JsonProperty("insuranceProductRk")
	private String insuranceProductRk;

	@JsonProperty("productCategoryRk")
	private String productCategoryRk;

	@JsonProperty("hasPolicySegmentDetailsIn")
	private List<HasPolicySegmentDetailsIn> hasPolicySegmentDetailsIn;

	@JsonProperty("hasPlanDetailsIn")
	private List<HasPlanDetailsIn> hasPlanDetailsIn;

	@JsonProperty("planNM")
	private String planNM;

	@JsonProperty("totalRecordCount")
	private String totalRecordCount;

	@JsonProperty("insuranceProductCd")
	private String insuranceProductCd;

	public IsAssociatedWithLifeInsuranceProduct() {

	}

	/**
	 * @param planCd
	 * @param insuranceProductRk
	 * @param productCategoryRk
	 * @param hasPolicySegmentDetailsIn
	 * @param hasPlanDetailsIn
	 * @param planNM
	 * @param totalRecordCount
	 * @param insuranceProductCd
	 */
	public IsAssociatedWithLifeInsuranceProduct(String planCd, String insuranceProductRk, String productCategoryRk,
			List<HasPolicySegmentDetailsIn> hasPolicySegmentDetailsIn, List<HasPlanDetailsIn> hasPlanDetailsIn,
			String planNM, String totalRecordCount, String insuranceProductCd) {
		this.planCd = planCd;
		this.insuranceProductRk = insuranceProductRk;
		this.productCategoryRk = productCategoryRk;
		this.hasPolicySegmentDetailsIn = hasPolicySegmentDetailsIn;
		this.hasPlanDetailsIn = hasPlanDetailsIn;
		this.planNM = planNM;
		this.totalRecordCount = totalRecordCount;
		this.insuranceProductCd = insuranceProductCd;
	}

	@JsonProperty("planCd")
	public String getPlanCd() {
		return planCd;
	}

	@JsonProperty("planCd")
	public void setPlanCd(String planCd) {
		this.planCd = planCd;
	}

	@JsonProperty("insuranceProductRk")
	public String getInsuranceProductRk() {
		return insuranceProductRk;
	}

	@JsonProperty("insuranceProductRk")
	public void setInsuranceProductRk(String insuranceProductRk) {
		this.insuranceProductRk = insuranceProductRk;
	}

	@JsonProperty("productCategoryRk")
	public String getProductCategoryRk() {
		return productCategoryRk;
	}

	@JsonProperty("productCategoryRk")
	public void setProductCategoryRk(String productCategoryRk) {
		this.productCategoryRk = productCategoryRk;
	}

	@JsonProperty("hasPolicySegmentDetailsIn")
	public List<HasPolicySegmentDetailsIn> getHasPolicySegmentDetailsIn() {
		return hasPolicySegmentDetailsIn;
	}

	@JsonProperty("hasPolicySegmentDetailsIn")
	public void setHasPolicySegmentDetailsIn(List<HasPolicySegmentDetailsIn> hasPolicySegmentDetailsIn) {
		this.hasPolicySegmentDetailsIn = hasPolicySegmentDetailsIn;
	}

	@JsonProperty("planNM")
	public String getPlanNM() {
		return planNM;
	}

	@JsonProperty("planNM")
	public void setPlanNM(String planNM) {
		this.planNM = planNM;
	}

	@JsonProperty("insuranceProductCd")
	public String getInsuranceProductCd() {
		return insuranceProductCd;
	}

	@JsonProperty("insuranceProductCd")
	public void setInsuranceProductCd(String insuranceProductCd) {
		this.insuranceProductCd = insuranceProductCd;
	}

	@JsonProperty("hasPlanDetailsIn")
	public List<HasPlanDetailsIn> getHasPlanDetailsIn() {
		return hasPlanDetailsIn;
	}

	@JsonProperty("hasPlanDetailsIn")
	public void setHasPlanDetailsIn(List<HasPlanDetailsIn> hasPlanDetailsIn) {
		this.hasPlanDetailsIn = hasPlanDetailsIn;
	}

	@JsonProperty("totalRecordCount")
	public String getTotalRecordCount() {
		return totalRecordCount;
	}

	@JsonProperty("totalRecordCount")
	public void setTotalRecordCount(String totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}
}
