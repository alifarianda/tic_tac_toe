/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */
package id.co.axa.eip.model.hasaxaasiapartyaccount;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "accountNO", "partyAccountNM" })
public class HasAXAAsiaPartyAccount {

	@JsonProperty("accountNO")
	private String accountNO;

	@JsonProperty("partyAccountNM")
	private String partyAccountNM;

	@JsonProperty("accountNO")
	public String getAccountNO() {
		return accountNO;
	}

	@JsonProperty("accountNO")
	public void setAccountNO(String accountNO) {
		this.accountNO = accountNO;
	}

	@JsonProperty("partyAccountNM")
	public String getPartyAccountNM() {
		return partyAccountNM;
	}

	@JsonProperty("partyAccountNM")
	public void setPartyAccountNM(String partyAccountNM) {
		this.partyAccountNM = partyAccountNM;
	}

}
