package id.co.axa.commons.core.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.springframework.stereotype.Component;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */
@Component
public class GeneratorUtils {
	public static String GenerateId(String prefix, Date date, int numdigit) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		Random rand = new Random();
		String dateFormat = "";
		if (date != null) {
			dateFormat = sdf.format(date);
		}

		String[] arr = new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f",
				"g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
		String randomkey = "";

		for (int i = 0; i < numdigit; ++i) {
			int random = rand.nextInt(36);
			randomkey = randomkey + arr[random];
		}

		return prefix + "-" + dateFormat + randomkey;
	}

	public static String uniqueRandom(String uniqueIdentifier) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		StringBuilder addRandomNum = new StringBuilder();
		Date date = new Date();
		String formatTrxid = sdf.format(date);
		addRandomNum.append(uniqueIdentifier);
		addRandomNum.append("-");
		addRandomNum.append(formatTrxid);
		return addRandomNum.toString();
	}

}
