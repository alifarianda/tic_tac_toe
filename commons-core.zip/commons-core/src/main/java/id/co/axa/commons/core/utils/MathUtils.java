package id.co.axa.commons.core.utils;

import java.math.BigInteger;

import id.co.axa.commons.core.base.BaseObject;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public class MathUtils extends BaseObject {

	private static final long serialVersionUID = -2675690030727685449L;
	public static final long DEFAULT_MOD_VALUE = 7L;

	public static long generateCheckDigit(BigInteger value) {
		return generateCheckDigit(value, 7L);
	}

	public static long generateCheckDigit(BigInteger value, long modValue) {
		return value.mod(BigInteger.valueOf(modValue)).longValue();
	}

}
