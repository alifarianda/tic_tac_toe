package id.co.axa.commons.core.repository;

import org.springframework.data.repository.NoRepositoryBean;

import id.co.axa.commons.core.model.Model;


/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */
@NoRepositoryBean
public interface BaseRepository<T extends Model, ID> extends BaseJpaRepository<T, ID> {
}