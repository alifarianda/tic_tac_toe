package id.co.axa.commons.core.utils;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

public class Constant {
	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_FAILED = "FAILED";
	public static final String EXPIRED_SESSION = "Session Expired / Session has been deleted";
	public static final String INVALID_ERROR = "Invalid Error";

	public static final String REQUIRED_USERNAME = "Required Username";
	public static final String LOGIN_FAILED = "Session Login Failed";
	public static final String WRONG_PASSWORD = "Wrong Password";
	public static final String INACTIVE_USER = "Inactive User";
	public static final String NOT_MATCH = "Matching Username & Password Not Found";
	public static final String REQUIRED_PASSWORD = "Required Password";
	public static final String DELETE_SESSION_FAILED = "Session delete failed";
	public static final String LOGIN_SUCCESS = "Login Success";

	public static final String REQUIRED_TOKEN = "Required Token ";
	public static final String TOKEN_ALREADY_DELETE = "Token Already Deleted";

	public static final String SESSION_GENERATE_FAILED = "Session Generate Failed ";

	public static final String DATA_ALREADY_EXIST = "Data already exist";
	public static final String DATA_NOT_FOUND = "Data not found ";
	public static final String DATA_INACTIVE = "Data inactive ";
	public static final String USERNAME_CANNOT_NULL = "Username cannot null ";
	public static final String PASSWORD_CANNOT_NULL = "Password cannot null ";
	public static final String PASSWORD_NOT_MATCH = "User and Password not match ";
	public static final String OLD_PASSWORD_REQUIRED = "Required Old Password ";
	public static final String NEW_PASSWORD_REQUIRED = "New Old Password ";
	public static final String TRY_ANOTHER_PASSWORD = "Try another password ";
	public static final String CLOSE_SESSION = "Close this session ";
	public static final String SESSION_EXPIRED = "Session Expired ";
	public static final String SUCCESS_CLOSE_SESSION = "Success Close Session ";
	public static final String SESSION_NOT_FOUND = "Session Not Found ";
	public static final String SESSION_ACTIVE = "Session Active ";



}
