package id.co.axa.commons.core.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import id.co.axa.commons.core.base.BaseObject;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseResponse<T> extends BaseObject implements Response<T> {

	private static final long serialVersionUID = -7743601608663534321L;

	@JsonProperty("status")
	protected Status status;

	@JsonProperty("result")
	protected T result;

	@Override
	public Status getStatus() {
		return this.status;
	}

	@Override
	public void setStatus(Status status) {
		this.status = status;
	}

	@Override
	public T getResult() {
		return this.result;
	}

	@Override
	public void setResult(T result) {
		this.result = result;
	}

}
